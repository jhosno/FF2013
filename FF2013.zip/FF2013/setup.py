from distutils.core import setup

setup(
    name='FF2013',
    version='0.1',
    packages=['', 'DB', 'View', 'temp', 'Model', 'Controller'],
    url='',
    license='',
    author='Jhosnoirlit Hernandez',
    author_email='jhosnoirlit@gmail.com',
    description='Componente para la gestion de almacen y facturacion'
)
