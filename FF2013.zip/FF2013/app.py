#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'
#

# This is an automatically generated file.
# Manual changes will be overwritten without warning!

import wx
import gettext
from View.Menu import Menu


if __name__ == "__main__":
 gettext.install("app") # replace with the appropriate catalog name

 app = wx.PySimpleApp(0)
 wx.InitAllImageHandlers()
 principal = Menu(None, wx.ID_ANY, "")
 app.SetTopWindow(principal)
 principal.Show()
 app.MainLoop()