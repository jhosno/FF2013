__author__ = 'saint'

num= str("287880")
mun= "04124373630"
new= '{:,}'.format(int(mun))
print new
if len(num)<= 8 and len(num) >= 6:
    text = '{:,}'.format(int(num))
    print text, "Valido"
else:
    print "No pasa"



