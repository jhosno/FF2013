        #definimos los valores del doc
        doc = SimpleDocTemplate("Inventario.pdf",pagesize=A4,
                                rightMargin=72,leftMargin=72,
                                topMargin=5,bottomMargin=18)
        #definimos los estilos
        self.styles.add(ParagraphStyle(name = "Titulo",  alignment=TA_CENTER, fontSize=20,
                   fontName="Helvetica-BoldOblique"))
        #iniciamos la historia
        story=[]
        #banner
        story.append(self.imagen_logo)
        #titulo
        story.append(Spacer(1, 40))
        tit = '<font size=12>Inventario</font>'
        story.append(Paragraph(tit, self.styles["Titulo"]))
        story.append(Spacer(1, 40))
        #datetime
        formatted_time = time.ctime()
        ptext = '<font size=12>%s</font>' % formatted_time
        self.styles.add(ParagraphStyle(name = "time",  alignment=TA_JUSTIFY, fontSize=12,
                   fontName="Helvetica"))
        story.append(Paragraph(ptext, self.styles["time"]))
        story.append(Spacer(1, 30))
        #tabla
        label = ("Código de Producto","Marca","Modelo","Descripción","Existencia", "Precio Unitario", "Valor")
        ar.insert(0,label)
        t = Table (ar, style=[('BOX',(0,0),(-1,-1),2,colors.black),
                               ('GRID',(0,0),(-1,-1),0.5,colors.black),
                               ('VALIGN',(3,0),(3,0),'BOTTOM'),
                               ('BACKGROUND',(0,0),(6,0),colors.lavender),
                                ('ALIGN',(0,0),(6,0),'CENTER')])
        story.append(t)
        #se genera el doc
        doc.build(story)
        #se abre el documento
        if sys.platform == 'linux2':
            os.system('xdg-open "Inventario.pdf"')
        else:
            os.startfile(file)
