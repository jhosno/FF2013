import hashlib

#prueba de encrypt

pwd = hashlib.md5()
pwd.update("4321")
pwd1 =pwd.hexdigest()


print pwd1