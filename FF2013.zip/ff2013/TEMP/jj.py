# -*- coding: UTF-8 -*-
__author__ = 'Jhosnoirllit Hernández'
import shutil, os, datetime, sys

    def onBrowse(self, event):
        """
        Browse for file
        """
        wildcard = "DB files (*.db)|*.db"
        dialog = wx.FileDialog(None, "Selecciona una Dase de Batos",
                               wildcard=wildcard,
                               style=wx.OPEN)
        if dialog.ShowModal() == wx.ID_OK:
            self.photoTxt.SetValue(dialog.GetPath())
        dialog.Destroy()
        self.onView()


directorioOriginal = os.getcwd()
directorio = os.path.join(os.pardir, 'miNuevoDir')
if not os.path.isdir(directorio):
    os.mkdir(directorio)
os.chdir(directorio)

os.chdir(directorioOriginal) # vuelve al directorio inicial
os.chdir(os.environ['HOME']) # cambia al directorio home
print directorioOriginal, directorio
'''
#nombre del archivo
dat = datetime.datetime.now()
name =dat.strftime("%m.%d.%Y-I:%M%p")


#Crea la carpeta
res =  os.path.exists('/home/saint/Documentos/Respaldo_FF2013')
if res == False:
    if sys.platform == 'linux2':
        dirpath = R'/home/saint/Documentos/Respaldo_FF2013'
        print "Hola?"
        os.mkdir(dirpath)

    else:
        dirpath = R'c: \ Respaldo_FF2013 '


else:
    source = os.path.abspath('../DB/ff2013.db')
    destiny = '/home/saint/Documentos/Respaldo_FF2013/backUp_'+name+'.db'
    shutil.copy2(source, destiny)




if sys.platform == 'linux2':
    DirectoryPath = R'/home/saint/Documentos/Respaldo_FF2013 '

    if os.mkdir (DirectoryPath) == False:
        print "Holis"
else:
    DirectoryPath = R'c: \ Respaldo_FF2013 '
    os.mkdir (DirectoryPath)
source = os.path.abspath('../DB/ff2013.db')
destiny = '/home/saint/Documentos/Respaldo_FF2013/backUp_'+name+'.db'
shutil.copy2(source, destiny)


for base, dirs, files in os.walk('/home/saint/Documentos/Respaldo_FF2013'):
    print dirs
    if dirs == "Respaldo_FF2013":
        print "Suprise"





#copia el archivo
source = os.path.abspath('../DB/ff2013.db')
destiny = '/home/saint/Documentos/Respaldo_FF2013/backUp_'+name+'.db'
shutil.copy2(source, destiny)

'''