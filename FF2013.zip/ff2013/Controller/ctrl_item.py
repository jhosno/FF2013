#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import Model.model_item as mitem


class Ctrl_item:
    def requisiciones(self):
        data = mitem.Item()
        res= data.inventario_requis()
        return res

    def actualizar_requis(self, ar):
        req = mitem.Item()
        req.actualizar_requis(ar)

    def inventario(self):
        data= mitem.Item()
        res =data.inventario_valorizado()
        return res

    def mov(self):
        data= mitem.Item()
        res =data.mov()
        return res

    def movid(self, dato):
        con = mitem.Item()
        res =con.buscar_item(str(dato))
        return  res

    def nuevo_item(self, descripcion, marca, modelo, p_unit, s_min, s_max, existencia):
        con = mitem.Item()
        res = con.nuevo_item(descripcion, marca, modelo, p_unit, s_min, s_max, existencia)

    def validar_item(self, descripcion, marca, modelo, p_unit, s_min, s_max, existencia):
        con = mitem.Item()
        res = con.validar_item(descripcion, marca, modelo, p_unit, s_min, s_max, existencia)

        return res

    def actualizar_item(self, descripcion, marca, modelo, p_unit, existencia, iditem):
        con = mitem.Item()
        con.actualizar_item(descripcion, marca, modelo, p_unit, existencia, iditem)

    def busqueda_date(self, ano, mes):
        con = mitem.Item()
        res = con.consulta_date(ano, mes)
        return res

    def eliminar_item(self, iditem):
        con = mitem.Item()
        con.eliminar_item(iditem)

    def busqueda_requis(self, dato):
        con = mitem.Item()
        res = con.busqueda_requis(dato)
        return res

    def ajust(self, cod, s_max,s_min,exist, post):
        con = mitem.Item()
        if exist < post:
            suma = int(post) - int(exist)
            movimiento = "Ajuste de inventario. Rectifiación"

            con.ajust(cod, s_max,s_min,exist, movimiento, suma)
        else:
            suma =  int(exist)- int(post)
            movimiento = "Entrada: Ajuste de inventario"

            con.ajust(cod, s_max,s_min,exist, movimiento, suma)
