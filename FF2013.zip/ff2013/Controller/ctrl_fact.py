#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import Model.model_factura as fact
import Model.model_cliente as client
import Model.model_item as item
import Model.model_iva as iva


class Ctrl_Fact:
    def add_fact(self,iva, idcliente ):
        nueva = fact.Factura()
        idF = nueva.nueva_factura(idcliente,"PAGADO", iva)
        return idF

    def facid(self):
        fid = fact.Factura()
        idf = fid.devuelve_id()
        return idf

        pass

    def search_client(self, ci):
        cliente = client.Cliente()
        res =cliente.buscar_cliente(ci)
        return res
        #print("ctrl", res)
        #pass

    def search_item(self, dato):
        self.i = item.Item()
        res =self.i.buscar_item(dato)
        return res

    def cant_item(self,dato):
        i = item.Item()
        res =i.cant_item(dato)
        descrip = str(res[1]) + ", "+ str(res[2])+ ", " + str(res[3])
        fitem =[]
        fitem.append(res[0])
        fitem.append(descrip)
        fitem.append(float(res[4]))
        return  fitem

    def add_item(self, arreglo):
        subir = fact.Factura()
        subir.subir_item(arreglo)

    def iva(self):
        last = iva.Iva()
        res = last.buscar_iva()
        return res

    def report(self, ano, mes):
        res = fact.Factura()
        ar = res.reporte(ano, mes)
        return ar

    def search_fact(self, idfact):
        busqueda = fact.Factura()
        res = busqueda.buscar_factura(idfact)
        return res

    def showFact1(self,idfact):
        sfact = fact.Factura()
        res = sfact.showFact1(int(idfact))

        return res

    def showFact2(self,idfact):
        sfact = fact.Factura()
        res = sfact.showFact2(idfact)
        rng = len(res)
        tlp = []
        for row in range(rng):
            descrip = str(res[row][1]) + ", "+ str(res[row][2])+ ", " + str(res[row][3])
            fitem =[]
            fitem.append(str(res[row][0]))
            fitem.append(descrip)
            fitem.append(str(res[row][4]))
            fitem.append(str(res[row][5]))
            fitem.append(str(res[row][6]))
            tlp.append(fitem)

        last = tuple(tlp)
        return  last

    def busqueda_date(self, ano, mes):
        con = item.Item()
        res = con.consulta_date(ano, mes)
        return res

    def print_fact(self, idfact, sub, iva, total):
        cli =self.showFact1(idfact)
        item = self.showFact2(idfact)
       # prt = pdf.PDF()
        #prt.print_fact(cli, item, sub, iva, total)