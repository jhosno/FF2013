#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'


import Model.model_user as Muser

class Ctrl_user:
    def sesion(self, user, pwd):
        entrar = Muser.User()
        respuesta = entrar.sesion(user, pwd)
        return respuesta

    def Show_user(self):
        muser = Muser.User()
        res = muser.mostrar_user()
        return res

    def update_user(self, user, passw, nombre, email, iduser,):
        muser = Muser.User()

        muser.modificar_user(user, passw, nombre, email, iduser)

    def loguot(self):
        muser = Muser.User()
        muser.cerrarsesion()

    def privilegios(self):
        muser = Muser.User()
        res = muser.privilegios()
        return res