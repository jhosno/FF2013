#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'
import Model.model_historial as mhist

class Ctrl_hist:
    def mostrar_historial(self):
        datos = mhist.Model_historial()
        return datos.mostrar_historial()

    def busqueda(self, ano,mes, cat):
        con = mhist.Model_historial()
        res = con.consulta(ano, mes, cat)
        return res

    def mov_item(self, id):
        con = mhist.Model_historial()
        res = con.mov_item(id, "item")
        return res

    def busqueda_item(self, mes, ano, mov):
        print mes, ano, mov