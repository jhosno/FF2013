#!/usr/bin/env python
# -*- coding: UTF-8 -*
__author__ = 'Jhosnoirlit Hernández'

import Model.model_cliente as mCli


class Ctrl_Cliente:
    def guardar_cliente(self, ci, nombre, email, tlf):
        self.guardar = mCli.Cliente()
        self.guardar.nuevo_cliente(ci, nombre, email, tlf)


    def devuelve_busqueda(self, ci):
        self.devuelve = mCli.Cliente()
        cliente = self.devuelve.resultado_cliente(ci)
        return cliente

    def mod_cliente(self,ci, nombre, email, tlf, id):
        self.devuelve = mCli.Cliente()
        res =self.devuelve.buscar_cliente(ci, nombre, email, tlf, id)
        return res

    def delete_cli(self, idcli):
        delcli=mCli.Cliente()
        delcli.eliminar_cliente(idcli)

    def save_mod(self, ci, nombre, email, tlf, id):
        modcli = mCli.Cliente()
        modcli.actualizar_cliente( ci, nombre, email, tlf, id)

    def list_cli(self):
        lis= mCli.Cliente()
        res = lis.listar_cliente()
        return res

    def buscar_client(self, dato):
        lis= mCli.Cliente()
        res = lis.bus_cli_list(dato)
        return res

