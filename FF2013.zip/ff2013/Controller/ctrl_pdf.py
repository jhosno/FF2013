#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'


import os,sys
import time
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (SimpleDocTemplate, PageBreak, Image, Spacer,
Paragraph, Table, TableStyle)

from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch
import Controller.ctrl_fact as cFact
import Model.model_validar as validar
from reportlab.platypus import (BaseDocTemplate, Frame, Paragraph,
                    NextPageTemplate, PageBreak, PageTemplate)
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import A4



class PDF:
    def __init__(self):
        self.fichero_imagen = "../View/img/banner.png"
        self.imagen_logo = Image(os.path.realpath(self.fichero_imagen),width=500,height=60)
        self.styles=getSampleStyleSheet()

    #Creamos los canvas para el pie de página y encabezado, que serán fijos


    def print_invent(self, ar):
        #definimos los valores del doc

        #definimos los estilos
        self.styles.add(ParagraphStyle(name = "Titulo",  alignment=TA_CENTER, fontSize=20,
                   fontName="Helvetica-BoldOblique"))
        #iniciamos la historia
        story=[]
        #banner
        story.append(self.imagen_logo)
        #titulo
        story.append(Spacer(1, 40))
        tit = '<font size=14>Inventario</font>'
        story.append(Paragraph(tit, self.styles["Titulo"]))
        story.append(Spacer(1, 40))
        #datetime
        val = validar.Validacion()
        formatted_time = val.fecha_print()
        ptext = '<font size=10>%s</font>' % formatted_time
        self.styles.add(ParagraphStyle(name = "time",  alignment=TA_JUSTIFY, fontSize=12,
                   fontName="Helvetica"))
        story.append(Paragraph(ptext, self.styles["time"]))
        story.append(Spacer(1, 30))
        #tabla
        label = ("Código de Producto","Marca","Modelo","Descripción","Existencia", "Precio Unitario", "Valor")
        ar.insert(0,label)
        t = Table (ar, style=[('BOX',(0,0),(-1,-1),2,colors.black),
                               ('GRID',(0,0),(-1,-1),0.5,colors.black),
                               ('VALIGN',(3,0),(3,0),'BOTTOM'),
                               ('BACKGROUND',(0,0),(6,0),colors.lavender),
                                ('ALIGN',(0,0),(6,0),'CENTER')])
        story.append(t)




        doc = SimpleDocTemplate("Inventario.pdf",pagesize=A4,
                                rightMargin=72,leftMargin=72,
                                topMargin=5,bottomMargin=18)

        #se genera el doc
        doc.build(story)
        #se abre el documento
        if sys.platform == 'linux2':
            os.system('xdg-open "Inventario.pdf"')
        else:
            os.startfile(file)

    def print_fact(self, factid, item, sub, iva, veriva, ttl ):
                #definimos los valores del doc
        doc = SimpleDocTemplate("Factura.pdf",pagesize=A4,
                                rightMargin=72,leftMargin=72,
                                topMargin=5,bottomMargin=18)
        #definimos los estilos
        self.styles.add(ParagraphStyle(name = "Titulo",  alignment=TA_CENTER, fontSize=20,
                   fontName="Helvetica-BoldOblique"))
        #iniciamos la historia
        story=[]
        #banner
        story.append(self.imagen_logo)
        #titulo
        story.append(Spacer(1, 40))
        tit = '<font size=14>Factura</font>'
        story.append(Paragraph(tit, self.styles["Titulo"]))
        story.append(Spacer(1, 40))
        #datetime
        val = validar.Validacion()
        formatted_time = val.fecha_print()
        ptext = '<font size=10>%s</font>' % formatted_time
        self.styles.add(ParagraphStyle(name = "time",  alignment=TA_JUSTIFY, fontSize=12,
                   fontName="Helvetica"))
        story.append(Paragraph(ptext, self.styles["time"]))
        story.append(Spacer(1, 30))
        #tabla
        con = cFact.Ctrl_Fact()
        fact = con.showFact1(factid[0])
        list(fact)
        litem=list(item)
        self.styles.add(ParagraphStyle(name = "tag", fontSize=12,
                   fontName="Helvetica_Bold"))
        num =('Nombre del cliente: ', fact[3],"", "Nº Factura: ", fact[0])
        fecha=("Cédula del Cliente: ", fact[4],"", "Fecha: ", fact[1])
        estado = ("Télefono del Cliente: ",fact[5],"", "Estado: ", fact[2])
        espacio1 = ("","","", "", "")
        espacio2 = ("","","", "", "")
        espacio3 = ("","","", "", "")

        label = ("Código de Producto","Descripción","Cantidad", "Precio Unitario", "Monto")
        litem.insert(0,num)
        litem.insert(1,fecha)
        litem.insert(2,estado)
        litem.insert(3,espacio1)
        litem.insert(4,espacio2)
        litem.insert(5,espacio3)
        litem.insert(6,label)
        ver= "Iva " + str(veriva)
        lasub = ("","","", "Sub-Total: ", sub)
        laiva=("","","", ver, iva)
        latotal = ("","","", "Total:", ttl)
        litem.append(lasub)
        litem.append(laiva)
        litem.append(latotal)
        t = Table (litem, style=[('BOX',(0,6),(-1,-4),2,colors.black),
                              ('BOX',(-2,-3),(5,-1),2,colors.black),
                               ('GRID',(0,6),(-1,-4),0.5,colors.black),
                               ('GRID',(-2,-3),(5,-1),0.5,colors.black),
                               ('VALIGN',(3,0),(3,0),'BOTTOM'),
                               ('BACKGROUND',(0,6),(6,6),colors.lavender)])
        story.append(t)
        #se genera el doc
        doc.build(story)
        #se abre el documento
        if sys.platform == 'linux2':
            os.system('xdg-open "Factura.pdf"')
        else:
            os.startfile(file)

    def print_requis(self,ar):
                #definimos los valores del doc
        doc = SimpleDocTemplate("Requis.pdf",pagesize=A4,
                                rightMargin=72,leftMargin=72,
                                topMargin=5,bottomMargin=18)
        #definimos los estilos
        self.styles.add(ParagraphStyle(name = "Titulo",  alignment=TA_CENTER, fontSize=20,
                   fontName="Helvetica-BoldOblique"))
        #iniciamos la historia
        story=[]
        #banner
        story.append(self.imagen_logo)
        #titulo
        story.append(Spacer(1, 40))
        tit = '<font size=14>Productos por debajo de Mínimo</font>'
        story.append(Paragraph(tit, self.styles["Titulo"]))
        story.append(Spacer(1, 40))
        #datetime
        val = validar.Validacion()
        formatted_time = val.fecha_print()
        ptext = '<font size=10>%s</font>' % formatted_time
        self.styles.add(ParagraphStyle(name = "time",  alignment=TA_JUSTIFY, fontSize=12,
                   fontName="Helvetica"))
        story.append(Paragraph(ptext, self.styles["time"]))
        story.append(Spacer(1, 30))
        #tabla
        label = ("Marca","Modelo","Descripción","Existencia", "Stock Mínimo")
        ar.insert(0,label)
        t = Table (ar, style=[('BOX',(0,0),(-1,-1),2,colors.black),
                               ('GRID',(0,0),(-1,-1),0.5,colors.black),
                               ('VALIGN',(3,0),(3,0),'BOTTOM'),
                               ('BACKGROUND',(0,0),(6,0),colors.lavender)])
        story.append(t)
        #se genera el doc
        doc.build(story)
        #se abre el documento
        if sys.platform == 'linux2':
            os.system('xdg-open "Requis.pdf"')
        else:
            os.startfile(file)

    def print_report(self, ar, ttl):
                #definimos los valores del doc
        doc = SimpleDocTemplate("Report.pdf",pagesize=A4,
                                rightMargin=72,leftMargin=72,
                                topMargin=5,bottomMargin=18)
        #definimos los estilos
        self.styles.add(ParagraphStyle(name = "Titulo",  alignment=TA_CENTER, fontSize=20,
                   fontName="Helvetica-BoldOblique"))
        #iniciamos la historia
        story=[]
        #banner
        story.append(self.imagen_logo)
        #titulo
        story.append(Spacer(1, 40))
        tit = '<font size=14>Reporte Mensual</font>'
        story.append(Paragraph(tit, self.styles["Titulo"]))
        story.append(Spacer(1, 40))
        #datetime
        val = validar.Validacion()
        formatted_time = val.fecha_print()
        ptext = '<font size=10>%s</font>' % formatted_time
        self.styles.add(ParagraphStyle(name = "time",  alignment=TA_JUSTIFY, fontSize=12,
                   fontName="Helvetica"))
        story.append(Paragraph(ptext, self.styles["time"]))
        story.append(Spacer(1, 30))
        #tabla
        label = ("Fecha","Nº Factura","Cédula de Cliente","Nombre del Cliente","Monto")
        ar.insert(0,label)
        total= ("","","","Total Mensual ", ttl)
        ar.append(total)

        t = Table (ar, style=[('BOX',(0,0),(-1,-2),2,colors.black),
                              ('BOX',(-2,-1),(5,-1),2,colors.black),
                               ('GRID',(0,0),(-1,-2),0.5,colors.black),
                               ('GRID',(-2,-1),(5,-1),0.5,colors.black),
                               ('VALIGN',(3,0),(3,0),'BOTTOM'),
                               ('BACKGROUND',(0,0),(6,0),colors.lavender)])
        story.append(t)
        #se genera el doc
        doc.build(story)
        #se abre el documento
        if sys.platform == 'linux2':
            os.system('xdg-open "Report.pdf"')
        else:
            os.startfile(file)
