#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'
import wx, shutil, os, datetime, sys
import Model.model_historial as Mhist
import  wx.lib.mixins.listctrl  as  listmix
from wx import ImageFromStream, BitmapFromImage

class MainPanel(wx.Panel):
    def __init__(self, parent):
        """Constructor"""
        self.img_searh = os.path.abspath('../View/img/icons/search_small.png')
        self.img_close_small = os.path.abspath('../View/img/icons/window-close_small.png')
        self.img_add_client = os.path.abspath('../View/img/icons/user_add_small.gif')
        self.img_edit_client = os.path.abspath('../View/img/icons/edit_user.gif')
        self.img_add_car = os.path.abspath('../View/img/icons/shopping_cart_add.gif')
        self.img_delete_car = os.path.abspath('../View/img/icons/shopping_cart_delete.gif')
        self.img_edit_car = os.path.abspath('../View/img/icons/shopping_cart_edit.gif')
        self.img_save = os.path.abspath('../View/img/icons/save_small.gif')
        self.img_print = os.path.abspath('../View/img/icons/print_small.png')
        #######################
        ######### MENU ########
        #######################
        self.menu_fact = os.path.abspath('../View/img/icons/new_fact.png')
        self.menu_report = os.path.abspath('../View/img/icons/report.gif')
        self.menu_searh = os.path.abspath('../View/img/icons/buscar.gif')
        self.menu_iva = os.path.abspath('../View/img/icons/iva.gif')
        self.menu_invent = os.path.abspath('../View/img/icons/inventario.gif')
        self.menu_requis = os.path.abspath('../View/img/icons/requis.gif')
        self.menu_add_item = os.path.abspath('../View/img/icons/nuevo_item.gif')
        self.menu_client = os.path.abspath('../View/img/icons/clientes.gif')
        self.menu_add_client = os.path.abspath('../View/img/icons/new_client.gif')
        self.menu_perfil = os.path.abspath('../View/img/icons/perfil.gif')
        self.menu_logout = os.path.abspath('../View/img/icons/logout.gif')
        self.menu_salir = os.path.abspath('../View/img/icons/salir.gif')
        self.menu_hist = os.path.abspath('../View/img/icons/hist.gif')
        self.menu_export_db = os.path.abspath('../View/img/icons/export_db.gif')
        self.menu_import_db = os.path.abspath('../View/img/icons/import_db.gif')
        self.menu_about = os.path.abspath('../View/img/icons/about.gif')
        self.menu_help = os.path.abspath('../View/img/icons/ayuda.gif')


        wx.Panel.__init__(self, parent=parent)
        self.SetBackgroundStyle(wx.BG_STYLE_CUSTOM)
        self.frame = parent

        sizer = wx.BoxSizer(wx.VERTICAL)
        hSizer = wx.BoxSizer(wx.HORIZONTAL)
        hSizer.Add((1,1), 1, wx.ALIGN_BOTTOM)
        hSizer.Add(sizer, 0, wx.DOWN, 100)
        hSizer.Add((1,1), 0, wx.ALL, 75)
        self.SetSizer(hSizer)
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBackground)

    def OnEraseBackground(self, evt):
        dc = evt.GetDC()
        dc.Clear()
        dir_img = os.path.abspath('../View/img/bgFF2013.png')
        bmp = wx.Bitmap(dir_img)
        dc.DrawBitmap(bmp, 0, 0)


class Formulas:
    def __init__(self):
        self.restore = ''
    def total(self, subt, iva):
        trans = float(iva)/100
        base = subt * trans
        total = subt + base
        siva= "(" + str(iva) + "%): "
        res = []
        res.append(base)
        res.append(siva)
        res.append(total)
        return  res

    def backup_db(self):
        #generá nombre del archivo
        dat = datetime.datetime.now()
        name =dat.strftime("%m.%d.%Y-I:%M%p")
        #Crea la carpeta
        current = os.path.abspath('../../../Documentos/Respaldo_FF2013')

        res =  os.path.exists('../../../Documentos/Respaldo_FF2013')
        print "| res ->", res , "| current ->", current
        if res == False:
            if sys.platform == 'linux2':
                dirpath = R'../../../Documentos/Respaldo_FF2013'
                print  dirpath
                os.mkdir(dirpath)
                source = os.path.abspath('../DB/ff2013.db')
                destiny = '../../../Documentos/Respaldo_FF2013/backUp_'+name+'.db'
                shutil.copy2(source, destiny)
            else:
                dirpath = R'c: \ Respaldo_FF2013 '
        else:
            source = os.path.abspath('../DB/ff2013.db')
            destiny = '../../../Documentos/Respaldo_FF2013/backUp_'+name+'.db'
            shutil.copy2(source, destiny)

        hist = Mhist.Model_historial()
        hist.export_db()

    def restore_db(self):
        '''
        hist = Mhist.Model_historial()
        hist.import_db()
        '''
        if self.restore != '':
            destiny = os.path.abspath('../DB/ff2013.db')
            shutil.copy2(self.restore, destiny)


        pass


    def onBrowse(self, event):
        # Búsca el archivo
        wildcard = "DB files (*.db)|*.db"
        dialog = wx.FileDialog(None, "Selecciona una Dase de Batos",
                               wildcard=wildcard,
                               style=wx.OPEN)
        if dialog.ShowModal() == wx.ID_OK:
            self.restore = dialog.GetPath()
        dialog.Destroy()
        self.restore_db()





#####################################################
    #############################################
    ############### THE HARD PART ###############
    #############################################
####################################################
