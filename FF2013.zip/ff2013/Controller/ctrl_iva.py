#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import Model.model_iva as iva

class Ctrl_iva:
    def mostrar_iva(self):
        dato = iva.Iva()
        res = dato.buscar_iva()

        return int(res[0])

    def actualizar_iva(self, valor):
        actualizar = iva.Iva()
        actualizar.nuevo_iva(valor)

    def last_iva(self):
        dato = iva.Iva()
        res = dato.mostrar_last()
        return res