#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import hashlib
import Model.model_user as mlog

class Inicio:
    def __init__(self):
        self.iduser = 0
    def validacion(self, user, pwd):
        self.entrar = mlog.User()
        crypt = hashlib.md5()
        crypt.update(pwd)
        pwdcrypt= crypt.hexdigest()
        respuesta = self.entrar.sesion(user, pwdcrypt)

        return respuesta

    def retorna(self, id):
        ideuser = id

        return ideuser




