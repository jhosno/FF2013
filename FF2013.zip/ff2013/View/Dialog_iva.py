#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import wx, os
import Controller.ctrl_iva as iva
import Model.model_validar as validar
# begin wxGlade: dependencies
# end wxGlade

# begin wxGlade: extracode
# end wxGlade


class Dialog_iva(wx.Dialog):
    def __init__(self, *args, **kwds):
        res = iva.Ctrl_iva()
        dato = res.last_iva()
        # begin wxGlade: Dialog_iva.__init__
        kwds["style"] = wx.DEFAULT_DIALOG_STYLE
        wx.Dialog.__init__(self, None, **kwds)
        self.label_23 = wx.StaticText(self, wx.ID_ANY, _("Actualizar I.V.A."), style=wx.ALIGN_CENTRE)
        self.static_line_15 = wx.StaticLine(self, wx.ID_ANY)
        self.label_33 = wx.StaticText(self, wx.ID_ANY, _("I.V.A. en curso:"))
        self.label_26 = wx.StaticText(self, wx.ID_ANY, _("Fecha de Vigencia: "))
        self.text_ctrl_1 = wx.TextCtrl(self, wx.ID_ANY, str(dato[1]))
        self.label_27 = wx.StaticText(self, wx.ID_ANY, _("Valor: "))
        self.text_ctrl_2 = wx.TextCtrl(self, wx.ID_ANY, str(dato[0]))
        self.label_28 = wx.StaticText(self, wx.ID_ANY, _("%"))
        self.static_line_15_copy = wx.StaticLine(self, wx.ID_ANY)
        self.label_34 = wx.StaticText(self, wx.ID_ANY, _("Nuevo I.V.A.: "))
        self.label_32 = wx.StaticText(self, wx.ID_ANY, _("vigente a partir de: "))
        self.text_ctrl_3 =self.datepicker_ctrl_1 = wx.DatePickerCtrl(self, wx.ID_ANY)
#wx.(self, wx.ID_ANY, "")
        self.label_31 = wx.StaticText(self, wx.ID_ANY, _("Nuevo Valor: "))
        self.text_ctrl_4 = wx.TextCtrl(self, wx.ID_ANY, "")
        self.label_29 = wx.StaticText(self, wx.ID_ANY, _("%"))
        self.static_line_16 = wx.StaticLine(self, wx.ID_ANY)
        button_13 = os.path.abspath("../View/img/icons/close_circle_big.png")
        button_14 = os.path.abspath("../View/img/icons/save_big.png")
        self.bitmap_button_13 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_13, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_14 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_14, wx.BITMAP_TYPE_ANY))

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_BUTTON, self.onClose, self.bitmap_button_13)
        self.Bind(wx.EVT_BUTTON, self.onSaveIva, self.bitmap_button_14)
        # end wxGlade

    def __set_properties(self):
        # begin wxGlade: Dialog_iva.__set_properties
        self.SetTitle(_("Actualizar I.V.A."))
        favicon = os.path.abspath('../View/img/logotipo_tini.png')
        _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap(favicon, wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.SetSize((240, 282))
        self.label_23.SetFont(wx.Font(11, wx.DEFAULT, wx.ITALIC, wx.BOLD, 0, ""))
        self.static_line_15.SetMinSize((241, 20))
        self.label_33.SetFont(wx.Font(9, wx.DEFAULT, wx.NORMAL, wx.BOLD, 0, ""))
        self.text_ctrl_1.SetMinSize((100, 27))
        self.text_ctrl_1.SetToolTipString(_("Fecha de vigencia del I.V.A. actual"))
        self.text_ctrl_2.SetMinSize((50, 27))
        self.text_ctrl_2.SetToolTipString(_("Valor actual del I.V.A."))
        self.static_line_15_copy.SetMinSize((241, 20))
        self.label_34.SetFont(wx.Font(9, wx.DEFAULT, wx.NORMAL, wx.BOLD, 0, ""))
        self.text_ctrl_3.SetMinSize((100, 27))
        self.text_ctrl_3.SetToolTipString(_("Fecha de vigencia del nuevo I.V.A."))
        self.text_ctrl_4.SetMinSize((50, 27))
        self.text_ctrl_4.SetToolTipString(_("Nuevo valor de I.V.A."))
        self.static_line_16.SetMinSize((240, 10))
        self.bitmap_button_13.SetToolTipString(_("Cancelar"))
        self.bitmap_button_13.SetSize(self.bitmap_button_13.GetBestSize())
        self.bitmap_button_14.SetMinSize((40, 42))
        self.bitmap_button_14.SetToolTipString(_("Guardar"))
        # end wxGlade

    def __do_layout(self):
        # begin wxGlade: Dialog_iva.__do_layout
        grid_sizer_22 = wx.FlexGridSizer(13, 1, 0, 0)
        grid_sizer_25 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_24_copy = wx.FlexGridSizer(1, 4, 0, 0)
        grid_sizer_24_copy_1 = wx.FlexGridSizer(1, 3, 0, 0)
        grid_sizer_27 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_24 = wx.FlexGridSizer(1, 4, 0, 0)
        grid_sizer_23 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_26 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_22.Add((20, 20), 0, 0, 0)
        grid_sizer_22.Add(self.label_23, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_22.Add(self.static_line_15, 0, wx.EXPAND, 0)
        grid_sizer_26.Add((20, 20), 0, 0, 0)
        grid_sizer_26.Add(self.label_33, 0, 0, 0)
        grid_sizer_22.Add(grid_sizer_26, 1, wx.EXPAND, 0)
        grid_sizer_23.Add(self.label_26, 0, 0, 0)
        grid_sizer_23.Add(self.text_ctrl_1, 0, 0, 0)
        grid_sizer_22.Add(grid_sizer_23, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_24.Add((30, 20), 0, 0, 0)
        grid_sizer_24.Add(self.label_27, 0, 0, 0)
        grid_sizer_24.Add(self.text_ctrl_2, 0, 0, 0)
        grid_sizer_24.Add(self.label_28, 0, 0, 0)
        grid_sizer_22.Add(grid_sizer_24, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_22.Add(self.static_line_15_copy, 0, wx.EXPAND, 0)
        grid_sizer_27.Add((20, 20), 0, 0, 0)
        grid_sizer_27.Add(self.label_34, 0, 0, 0)
        grid_sizer_22.Add(grid_sizer_27, 1, wx.EXPAND, 0)
        grid_sizer_24_copy_1.Add(self.label_32, 0, 0, 0)
        grid_sizer_24_copy_1.Add(self.text_ctrl_3, 0, 0, 0)
        grid_sizer_22.Add(grid_sizer_24_copy_1, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_24_copy.Add(self.label_31, 0, 0, 0)
        grid_sizer_24_copy.Add(self.text_ctrl_4, 0, 0, 0)
        grid_sizer_24_copy.Add(self.label_29, 0, 0, 0)
        grid_sizer_22.Add(grid_sizer_24_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_22.Add(self.static_line_16, 0, wx.EXPAND, 0)
        grid_sizer_25.Add(self.bitmap_button_13, 0, 0, 0)
        grid_sizer_25.Add(self.bitmap_button_14, 0, 0, 0)
        grid_sizer_22.Add(grid_sizer_25, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.SetSizer(grid_sizer_22)
        self.Layout()
        # end wxGlade

    def onClose(self, event):  # wxGlade: Dialog_iva.<event_handler>
        self.Destroy()
        event.Skip()

    def onSaveIva(self, event):  # wxGlade: Dialog_iva.<event_handler>
        val = validar.Validacion()
        valor = val.numerico(self.text_ctrl_4.GetValue(), "Nuevo IVA")
        fecha = self.text_ctrl_3.GetValue()
        date = val.wxdate2pydate(fecha)
        nuevo = iva.Ctrl_iva()
        #nuevo.actualizar_iva(valor)
        self.Destroy()
        dlg = wx.MessageDialog(self, "I.V.A. actualizado", "Notificación", wx.OK)
        dlg.ShowModal()
        dlg.Close()

# end of class Dialog_iva
