#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import wx,os
import Model.model_validar as validar
import Controller.ctrl_item as cItem
import Dialog_modItem as dItem
# begin wxGlade: dependencies
# end wxGlade

# begin wxGlade: extracode
# end wxGlade


class Dialog_search_item(wx.Dialog):
	def __init__(self, *args, **kwds):
		# begin wxGlade: Dialog_search_item.__init__
		kwds["style"] = wx.DEFAULT_DIALOG_STYLE
		wx.Dialog.__init__(self, None, **kwds)
		self.label_57 = wx.StaticText(self, wx.ID_ANY, _(u"Busqueda de \xcdtem"))
		self.label_58 = wx.StaticText(self, wx.ID_ANY, _(u"C\xf3digo o Modelo: "))
		self.text_ctrl_35 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB)
		button_7 = os.path.abspath('../View/img/icons/close_circle_big.png')
		button_6 = os.path.abspath('..//View/img/icons/search_big.png')
		self.bitmap_button_7 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_7, wx.BITMAP_TYPE_ANY))
		self.bitmap_button_6 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_6, wx.BITMAP_TYPE_ANY))

		self.__set_properties()
		self.__do_layout()

		self.Bind(wx.EVT_BUTTON, self.onClose, self.bitmap_button_7)
		self.Bind(wx.EVT_BUTTON, self.onBuscar, self.bitmap_button_6)
		# end wxGlade

	def __set_properties(self):
		# begin wxGlade: Dialog_search_item.__set_properties
		self.SetTitle(_(u"Buscar \xcdtem"))
		favicon = os.path.abspath('../View/img/logotipo_tini.png')
		_icon = wx.EmptyIcon()
		_icon.CopyFromBitmap(wx.Bitmap(favicon, wx.BITMAP_TYPE_ANY))
		self.SetSize((238, 155))
		self.label_57.SetMinSize((150, 21))
		self.label_57.SetFont(wx.Font(10, wx.DEFAULT, wx.ITALIC, wx.NORMAL, 0, ""))
		self.text_ctrl_35.SetMinSize((100, 27))
		self.text_ctrl_35.SetToolTipString(_(u"Ingrese c\xf3digo o moledo del \xedtem para iniciar busqueda"))
		self.text_ctrl_35.SetFocus()
		self.bitmap_button_7.SetMinSize((40, 44))
		self.bitmap_button_7.SetToolTipString(_("Cerrar esta ventana"))
		self.bitmap_button_6.SetToolTipString(_("Buscar"))
		self.bitmap_button_6.SetSize(self.bitmap_button_6.GetBestSize())
		# end wxGlade

	def __do_layout(self):
		# begin wxGlade: Dialog_search_item.__do_layout
		grid_sizer_34 = wx.FlexGridSizer(5, 1, 0, 0)
		grid_sizer_35 = wx.FlexGridSizer(1, 2, 0, 0)
		grid_sizer_36 = wx.FlexGridSizer(1, 4, 0, 0)
		grid_sizer_34.Add(self.label_57, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_34.Add((17, 20), 0, 0, 0)
		grid_sizer_36.Add((20, 20), 0, 0, 0)
		grid_sizer_36.Add(self.label_58, 0, 0, 0)
		grid_sizer_36.Add(self.text_ctrl_35, 0, 0, 0)
		grid_sizer_34.Add(grid_sizer_36, 1, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_34.Add((20, 20), 0, 0, 0)
		grid_sizer_35.Add(self.bitmap_button_7, 0, 0, 0)
		grid_sizer_35.Add(self.bitmap_button_6, 0, 0, 0)
		grid_sizer_34.Add(grid_sizer_35, 1, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
		self.SetSizer(grid_sizer_34)
		self.Layout()
		# end wxGlade

	def onClose(self, event):  # wxGlade: Dialog_search_item.<event_handler>
		self.Destroy()
		event.Skip()

	def onBuscar(self, event):  # wxGlade: Dialog_search_item.<event_handler>
		val = validar.Validacion()
		dato = val.vacio(self.text_ctrl_35.GetValue(),"Dato del ítem")
		item = cItem.Ctrl_item()
		res = item.movid(dato)
		llamar = dItem.Dialog_modItem()
		llamar.mod_item(res)
		self.Destroy()

# end of class Dialog_search_item
