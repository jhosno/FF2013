#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import Dialog_client as Dcli
import Dialog_Login as login
import Dialog_item as Ditem
import Dialog_iva as Diva
import Dialog_search_client as DsClie
import Dialog_search_fact as DsFact
import Dialog_search_item as DsItem
import Dialog_user as duser
import Controller.ctrl_fact as cFact
import Controller.ctrl_historial as chist
import Controller.ctrl_item as citem
import Controller.ctrl_pdf as cPdf
import Controller.ctrl_cliente as ccli
import Controller.ctrl_user as user
import Model.model_validar as validar
import wx
import time


# begin wxGlade: dependencies
import wx.grid
# end wxGlade

# begin wxGlade: extracode
# end wxGlade


class Menu(wx.Frame):
    def __init__(self, *args, **kwds):
        # begin wxGlade: Menu.__init__
        kwds["style"] = wx.DEFAULT_FRAME_STYLE
        wx.Frame.__init__(self, *args, **kwds)
        #dlg = login.Dialog_Login()
        #dlg.Show()
        panel = MainPanel(self)
        self.Center()
        self.fila = 0
        self.sub =0
        self.req =0
        self.rep =0
        self.inv =0
        # Menu Bar
        self.Menu_menubar = wx.MenuBar()
        self.Arch = wx.Menu()
        self.arch_hist = wx.MenuItem(self.Arch, wx.ID_ANY, _("Historial "), _(u"Bit\xe1cora del sistema "), wx.ITEM_NORMAL)
        self.Arch.AppendItem(self.arch_hist)
        #self.ar_res = wx.MenuItem(self.Arch, wx.ID_ANY, _("Respaldo de DB"), _("Realiza una copia de la Base de Datos actual"), wx.ITEM_NORMAL)
        #self.Arch.AppendItem(self.ar_res)
        #self.ar_import = wx.MenuItem(self.Arch, wx.ID_ANY, _("Importar DB"), _("Importa Base de Datos"), wx.ITEM_NORMAL)
        #self.Arch.AppendItem(self.ar_import)
        self.Menu_menubar.Append(self.Arch, _("Historial"))
        self.fact = wx.Menu()
        self.f_addFact = wx.MenuItem(self.fact, wx.ID_ANY, _("Nueva Factura "), _(u"Emitir una nueva facturaci\xf3n"), wx.ITEM_NORMAL)
        self.fact.AppendItem(self.f_addFact)
        self.f_report = wx.MenuItem(self.fact, wx.ID_ANY, _("Reporte mensual"), _(u"Reporte de facturaci\xf3n mensual"), wx.ITEM_NORMAL)
        self.fact.AppendItem(self.f_report)
        self.f_searchFact = wx.MenuItem(self.fact, wx.ID_ANY, _(u"B\xfascar Factura "), _("Busqueda de factura"), wx.ITEM_NORMAL)
        self.fact.AppendItem(self.f_searchFact)
        self.fact.AppendSeparator()
        self.f_iva = wx.MenuItem(self.fact, wx.ID_ANY, _("I.V.A."), _("Actualizar valor del IVA"), wx.ITEM_NORMAL)
        self.fact.AppendItem(self.f_iva)
        self.Menu_menubar.Append(self.fact, _("Factura"))
        self.al = wx.Menu()
        self.al_invent = wx.MenuItem(self.al, wx.ID_ANY, _("Inventario"), _("Inventario de productos "), wx.ITEM_NORMAL)
        self.al.AppendItem(self.al_invent)
        self.al_requis = wx.MenuItem(self.al, wx.ID_ANY, _(u"Productos por debajo del m\xednimo"), _(u"Muestra todos los productos que han alcanzado la existencia m\xednima"), wx.ITEM_NORMAL)
        self.al.AppendItem(self.al_requis)
        self.al.AppendSeparator()
        self.al_additem = wx.MenuItem(self.al, wx.ID_ANY, _("Nuevo producto"), _("Formulario para agregar un nuevo producto"), wx.ITEM_NORMAL)
        self.al.AppendItem(self.al_additem)
        self.al_searchItem = wx.MenuItem(self.al, wx.ID_ANY, _(u"B\xfascar Producto"), _(u"Filtro de b\xfasqueda de uno o varios productos "), wx.ITEM_NORMAL)
        self.al.AppendItem(self.al_searchItem)
        self.Menu_menubar.Append(self.al, _(u"Almac\xe9n "))
        self.client = wx.Menu()
        self.cliente_list = wx.MenuItem(self.client, wx.ID_ANY, _("Clientes"), _("Muesta todos los clientes"), wx.ITEM_NORMAL)
        self.client.AppendItem(self.cliente_list)
        self.cliente_search = wx.MenuItem(self.client, wx.ID_ANY, _(u"B\xfascar Clientes "), _("Filtro de Busquedas de Clientes "), wx.ITEM_NORMAL)
        self.client.AppendItem(self.cliente_search)
        self.cliente_add = wx.MenuItem(self.client, wx.ID_ANY, _("Nuevo Cliente "), _(u"F\xf3rmulario para agregar un nuevo cliente "), wx.ITEM_NORMAL)
        self.client.AppendItem(self.cliente_add)
        self.Menu_menubar.Append(self.client, _("Cliente"))
        self.user = wx.Menu()
        self.user_perfil = wx.MenuItem(self.user, wx.ID_ANY, _("Perfil"), _("Muestra el perfil de Usuario Actual"), wx.ITEM_NORMAL)
        self.user.AppendItem(self.user_perfil)
        self.user_close = wx.MenuItem(self.user, wx.ID_ANY, _(u"Cerrar Sesi\xf3n"), _(u"Cerrar la sesi\xf3n actual"), wx.ITEM_NORMAL)
        self.user.AppendItem(self.user_close)
        self.user.AppendSeparator()
        self.user_exit = wx.MenuItem(self.user, wx.ID_ANY, _("Salir"), _("Salir del sistema "), wx.ITEM_NORMAL)
        self.user.AppendItem(self.user_exit)
        self.Menu_menubar.Append(self.user, _("Usuario"))
        self.help = wx.Menu()
        self.help_about = wx.MenuItem(self.help, wx.ID_ANY, _("Acerca de..."), _("Acerca del sistema"), wx.ITEM_NORMAL)
        self.help.AppendItem(self.help_about)
        self.help.AppendSeparator()
        self.help_help = wx.MenuItem(self.help, wx.ID_ANY, _("Ayuda"), _("Manual de ayuda"), wx.ITEM_NORMAL)
        self.help.AppendItem(self.help_help)
        self.Menu_menubar.Append(self.help, _("Ayuda"))
        self.SetMenuBar(self.Menu_menubar)
        # Menu Bar end
        self.Menu_statusbar = self.CreateStatusBar(1, 0)
        self.notebook_1 = wx.Notebook(self, wx.ID_ANY, style=0)
        self.notebook_hist = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_7 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _("Historial"))
        self.label_6 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _(u"Filtro de B\xfasqueda"))
        self.label_8 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _("Mes: "))
        self.combo_box_H_mes = wx.ComboBox(self.notebook_hist, wx.ID_ANY, choices=["", _("Enero"), _("Febrero"), _("Marzo"), _("Abril"), _("Mayo"), _("Junio"), _("Julio"), _("Agosto"), _("Septiembre"), _("Octubre"), _("Noviembre"), _("Diciembre")], style=wx.CB_DROPDOWN)
        self.label_9 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _(u"A\xf1o: "))
        self.spin_ctrl_H_ano = wx.SpinCtrl(self.notebook_hist, wx.ID_ANY, "", min=2015, max=3000)
        self.label_10 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _(u"Categor\xeda: "))
        self.combo_box_H_cat = wx.ComboBox(self.notebook_hist, wx.ID_ANY, choices=[_("Cliente"), _("Factura"), _("Iva"), _("Usuario"), _("Item")], style=wx.CB_DROPDOWN)
        self.bitmap_button_H_search = wx.BitmapButton(self.notebook_hist, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/search_small.png", wx.BITMAP_TYPE_ANY))
        self.static_line_1 = wx.StaticLine(self.notebook_hist, wx.ID_ANY)
        self.grid_Hist = wx.grid.Grid(self.notebook_hist, wx.ID_ANY, size=(1, 1))
        self.static_line_2 = wx.StaticLine(self.notebook_hist, wx.ID_ANY)
        self.bitmap_button_H_close = wx.BitmapButton(self.notebook_hist, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/window-close_small.png", wx.BITMAP_TYPE_ANY))
        self.notebook_addFact = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_1 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Nueva Factura "))
        self.static_line_3 = wx.StaticLine(self.notebook_addFact, wx.ID_ANY)
        self.label_2 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Cliente"))
        self.label_3 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"C\xe9dula: "))
        self.text_ctrl_AF_ci = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB)
        self.bitmap_button_3 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/user_add_small.gif", wx.BITMAP_TYPE_ANY))
        self.label_4 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Nombre y Apellido: "))
        self.text_ctrl_AF_name = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB | wx.TE_READONLY)
        self.label_5 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"T\xe9lefono: "))
        self.text_ctrl_AF_tlf = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB | wx.TE_READONLY)
        self.static_line_4 = wx.StaticLine(self.notebook_addFact, wx.ID_ANY)
        self.label_11 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Producto"))
        self.label_12 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"B\xfascar: "))
        self.text_ctrl_AF_Sitem = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB)
        self.bitmap_button_4 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/search_small.png", wx.BITMAP_TYPE_ANY))
        self.label_13 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"C\xf2digo de producto: "))
        self.text_ctrl_AF_cod = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY)
        self.label_15 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Marca: "))
        self.text_ctrl_AF_brand = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY)
        self.label_14 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"Descripci\xf3n: "))
        self.text_ctrl_AF_descrip = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY)
        self.label_16 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Modelo: "))
        self.text_ctrl_AF_model = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY)
        self.label_17 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Cantidad: "))
        self.text_ctrl_AF_cant = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "")
        self.bitmap_button_5 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/shopping_cart_add.gif", wx.BITMAP_TYPE_ANY))
        self.label_18 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Existencia: "))
        self.text_ctrl_AF_exist = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY)
        self.static_line_5 = wx.StaticLine(self.notebook_addFact, wx.ID_ANY)
        self.grid_Fact = wx.grid.Grid(self.notebook_addFact, wx.ID_ANY, size=(1, 1))
        self.label_19 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Sub-Total: "))
        self.text_ctrl_AF_subt = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY | wx.TE_RIGHT)
        self.label_20 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("I.V.A. "))
        self.text_ctrl_AF_iva = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY | wx.TE_CENTRE)
        self.text_ctrl_AF_addiva = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_RIGHT)
        self.label_21 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Total: "))
        self.text_ctrl_AF_item = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_RIGHT)
        self.static_line_6 = wx.StaticLine(self.notebook_addFact, wx.ID_ANY)
        self.bitmap_button_6 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/print_small.png", wx.BITMAP_TYPE_ANY))
        self.bitmap_button_7 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/window-close_small.png", wx.BITMAP_TYPE_ANY))
        self.notebook_invet = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_40 = wx.StaticText(self.notebook_invet, wx.ID_ANY, _("Inventario Valorizado"))
        self.label_6_copy_copy_copy = wx.StaticText(self.notebook_invet, wx.ID_ANY, _(u"Filtro de B\xfasqueda"))
        self.label_22_copy = wx.StaticText(self.notebook_invet, wx.ID_ANY, _(u"Datos del \xedtem: "))
        self.text_ctrl_I_dato = wx.TextCtrl(self.notebook_invet, wx.ID_ANY, "")
        self.bitmap_button_1_copy = wx.BitmapButton(self.notebook_invet, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/search_small.png", wx.BITMAP_TYPE_ANY))
        self.static_line_9 = wx.StaticLine(self.notebook_invet, wx.ID_ANY)
        self.grid_invent = wx.grid.Grid(self.notebook_invet, wx.ID_ANY, size=(1, 1))
        self.grid_invent.SetRowLabelAlignment(wx.ALIGN_RIGHT, wx.ALIGN_RIGHT)
        self.static_line_10 = wx.StaticLine(self.notebook_invet, wx.ID_ANY)
        self.bitmap_button_61 = wx.BitmapButton(self.notebook_invet, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/print_small.png", wx.BITMAP_TYPE_ANY))
        self.bitmap_button_71 = wx.BitmapButton(self.notebook_invet, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/window-close_small.png", wx.BITMAP_TYPE_ANY))
        self.notebook_requis = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_40_copy = wx.StaticText(self.notebook_requis, wx.ID_ANY, _(u"Productos por debajo de M\xednimo"))
        self.static_line_11 = wx.StaticLine(self.notebook_requis, wx.ID_ANY)
        self.grid_requis = wx.grid.Grid(self.notebook_requis, wx.ID_ANY, size=(1, 1))
        self.static_line_12 = wx.StaticLine(self.notebook_requis, wx.ID_ANY)
        self.bitmap_button_60 = wx.BitmapButton(self.notebook_requis, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/print_small.png", wx.BITMAP_TYPE_ANY))
        self.bitmap_button_8 = wx.BitmapButton(self.notebook_requis, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/save_small.gif", wx.BITMAP_TYPE_ANY))
        self.bitmap_button_70 = wx.BitmapButton(self.notebook_requis, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/window-close_small.png", wx.BITMAP_TYPE_ANY))
        self.notebook_report = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_30 = wx.StaticText(self.notebook_report, wx.ID_ANY, _("Reporte Mensual"))
        self.label_6_copy = wx.StaticText(self.notebook_report, wx.ID_ANY, _(u"Filtro de B\xfasqueda"))
        self.label_8_copy = wx.StaticText(self.notebook_report, wx.ID_ANY, _("Mes: "))
        self.combo_box_R_mes = wx.ComboBox(self.notebook_report, wx.ID_ANY, choices=["", _("Enero"), _("Febrero"), _("Marzo"), _("Abril"), _("Mayo"), _("Junio"), _("Julio"), _("Agosto"), _("Septiembre"), _("Octubre"), _("Noviembre"), _("Diciembre")], style=wx.CB_DROPDOWN)
        self.label_9_copy = wx.StaticText(self.notebook_report, wx.ID_ANY, _(u"A\xf1o: "))
        self.spin_ctrl_R_ano = wx.SpinCtrl(self.notebook_report, wx.ID_ANY, "", min=2015, max=3000)
        self.bitmap_button_R_search = wx.BitmapButton(self.notebook_report, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/search_small.png", wx.BITMAP_TYPE_ANY))
        self.static_line_7 = wx.StaticLine(self.notebook_report, wx.ID_ANY)
        self.grid_report = wx.grid.Grid(self.notebook_report, wx.ID_ANY, size=(1, 1))
        self.label_21_copy = wx.StaticText(self.notebook_report, wx.ID_ANY, _("Total Mensual: "))
        self.text_ctrl_R_total = wx.TextCtrl(self.notebook_report, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_RIGHT)
        self.static_line_8 = wx.StaticLine(self.notebook_report, wx.ID_ANY)
        self.bitmap_button_62 = wx.BitmapButton(self.notebook_report, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/print_small.png", wx.BITMAP_TYPE_ANY))
        self.bitmap_button_71_copy = wx.BitmapButton(self.notebook_report, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/window-close_small.png", wx.BITMAP_TYPE_ANY))
        self.notebook_client = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_30_copy = wx.StaticText(self.notebook_client, wx.ID_ANY, _("Clientes"))
        self.label_6_copy_copy = wx.StaticText(self.notebook_client, wx.ID_ANY, _(u"Filtro de B\xfasqueda"))
        self.label_22 = wx.StaticText(self.notebook_client, wx.ID_ANY, _("Datos del Cliente: "))
        self.text_ctrl_C_Dato = wx.TextCtrl(self.notebook_client, wx.ID_ANY, "")
        self.bitmap_button_1 = wx.BitmapButton(self.notebook_client, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/search_small.png", wx.BITMAP_TYPE_ANY))
        self.static_line_13 = wx.StaticLine(self.notebook_client, wx.ID_ANY)
        self.grid_client = wx.grid.Grid(self.notebook_client, wx.ID_ANY, size=(1, 1))
        self.static_line_14 = wx.StaticLine(self.notebook_client, wx.ID_ANY)
        self.bitmap_button_2 = wx.BitmapButton(self.notebook_client, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/window-close_small.png", wx.BITMAP_TYPE_ANY))

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_MENU, self.onHist, self.arch_hist)
#        self.Bind(wx.EVT_MENU, self.onSaveDB, self.ar_res)
#        self.Bind(wx.EVT_MENU, self.onImport, self.ar_import)
        self.Bind(wx.EVT_MENU, self.onAddFact, self.f_addFact)
        self.Bind(wx.EVT_MENU, self.onReport, self.f_report)
        self.Bind(wx.EVT_MENU, self.onSearchFact, self.f_searchFact)
        self.Bind(wx.EVT_MENU, self.onIva, self.f_iva)
        self.Bind(wx.EVT_MENU, self.onInvent, self.al_invent)
        self.Bind(wx.EVT_MENU, self.onRequis, self.al_requis)
        self.Bind(wx.EVT_MENU, self.onAddItem, self.al_additem)
        self.Bind(wx.EVT_MENU, self.onSearchItem, self.al_searchItem)
        self.Bind(wx.EVT_MENU, self.onClients, self.cliente_list)
        self.Bind(wx.EVT_MENU, self.onSearchClient, self.cliente_search)
        self.Bind(wx.EVT_MENU, self.onAddClient, self.cliente_add)
        self.Bind(wx.EVT_MENU, self.onPerfil, self.user_perfil)
        self.Bind(wx.EVT_MENU, self.onClose, self.user_close)
        self.Bind(wx.EVT_MENU, self.onExit, self.user_exit)
        self.Bind(wx.EVT_MENU, self.onAbout, self.help_about)
        self.Bind(wx.EVT_MENU, self.onHelp, self.help_help)
        self.Bind(wx.EVT_BUTTON, self.onHistASearch, self.bitmap_button_H_search)
        self.Bind(wx.EVT_BUTTON, self.onHistClose, self.bitmap_button_H_close)
        self.Bind(wx.EVT_BUTTON, self.onFactCliente, self.bitmap_button_3)
        self.Bind(wx.EVT_BUTTON, self.onFactItem, self.bitmap_button_4)
        self.Bind(wx.EVT_BUTTON, self.onFactAdd, self.bitmap_button_5)
        self.Bind(wx.EVT_BUTTON, self.onFactPrint, self.bitmap_button_6)
        self.Bind(wx.EVT_BUTTON, self.onFactClose, self.bitmap_button_7)
        self.Bind(wx.EVT_BUTTON, self.onInventSearch, self.bitmap_button_1_copy)
        self.Bind(wx.EVT_BUTTON, self.onInventPrint, self.bitmap_button_61)
        self.Bind(wx.EVT_BUTTON, self.onInventClose, self.bitmap_button_71)
        self.Bind(wx.EVT_BUTTON, self.onRequisPrint, self.bitmap_button_60)
        self.Bind(wx.EVT_BUTTON, self.onRequisSave, self.bitmap_button_8)
        self.Bind(wx.EVT_BUTTON, self.onRequisClose, self.bitmap_button_70)
        self.Bind(wx.EVT_BUTTON, self.onReportSearch, self.bitmap_button_R_search)
        self.Bind(wx.EVT_BUTTON, self.onReporPrint, self.bitmap_button_62)
        self.Bind(wx.EVT_BUTTON, self.onReportClose, self.bitmap_button_71_copy)
        self.Bind(wx.EVT_BUTTON, self.onClientSearch, self.bitmap_button_1)
        self.Bind(wx.EVT_BUTTON, self.onClientClose, self.bitmap_button_2)
        self.Bind(wx.EVT_CLOSE, self.onExit)
        # end wxGlade

    def __set_properties(self):
        # begin wxGlade: Menu.__set_properties
        self.SetTitle(_("AUTOMOTRIZ FULL FRIO 2013 C.A."))
        _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap("/home/saint/Documentos/FF2013/View/img/logotipo_tini.png", wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.SetSize((720, 688))
        self.Menu_statusbar.SetStatusWidths([-1])
        # statusbar fields
        Menu_statusbar_fields = [""]
        for i in range(len(Menu_statusbar_fields)):
            self.Menu_statusbar.SetStatusText(Menu_statusbar_fields[i], i)
        self.label_7.SetFont(wx.Font(15, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.label_6.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.combo_box_H_mes.SetMinSize((100, 29))
        self.combo_box_H_mes.SetSelection(0)
        self.spin_ctrl_H_ano.SetMinSize((60, 27))
        self.combo_box_H_cat.SetMinSize((80, 29))
        self.combo_box_H_cat.SetSelection(-1)
        self.bitmap_button_H_search.SetToolTipString(_(u"B\xfascar"))
        self.bitmap_button_H_search.SetSize(self.bitmap_button_H_search.GetBestSize())
        self.static_line_1.SetMinSize((712, 15))
        self.grid_Hist.CreateGrid(100, 3)
        self.grid_Hist.SetRowLabelSize(20)
        self.grid_Hist.EnableEditing(0)
        self.grid_Hist.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.grid_Hist.SetColLabelValue(0, _("Fecha"))
        self.grid_Hist.SetColSize(0, 180)
        self.grid_Hist.SetColLabelValue(1, _(u"Categor\xeda"))
        self.grid_Hist.SetColSize(1, 300)
        self.grid_Hist.SetColLabelValue(2, _("Movimiento"))
        self.grid_Hist.SetColSize(2, 200)
        self.grid_Hist.SetMinSize((712, 450))
        self.static_line_2.SetMinSize((712, 20))
        self.bitmap_button_H_close.SetToolTipString(_("Cerrar Historial "))
        self.bitmap_button_H_close.SetSize(self.bitmap_button_H_close.GetBestSize())
        self.notebook_hist.Hide()
        self.label_1.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.static_line_3.SetMinSize((700, 10))
        self.label_2.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.text_ctrl_AF_ci.SetFocus()
        self.bitmap_button_3.SetToolTipString(_("Agregar cliente a la factura"))
        self.bitmap_button_3.SetSize(self.bitmap_button_3.GetBestSize())
        self.text_ctrl_AF_name.SetMinSize((150, 27))
        self.text_ctrl_AF_tlf.SetMinSize((100, 27))
        self.static_line_4.SetMinSize((700, 10))
        self.label_11.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.text_ctrl_AF_Sitem.SetMinSize((100, 27))
        self.bitmap_button_4.SetToolTipString(_(u"B\xfascar \xedtem por marca, modelo o descripci\xf3n"))
        self.bitmap_button_4.SetSize(self.bitmap_button_4.GetBestSize())
        self.text_ctrl_AF_cod.SetMinSize((150, 27))
        self.text_ctrl_AF_brand.SetMinSize((120, 27))
        self.text_ctrl_AF_descrip.SetMinSize((150, 27))
        self.text_ctrl_AF_model.SetMinSize((120, 27))
        self.text_ctrl_AF_cant.SetMinSize((80, 27))
        self.bitmap_button_5.SetToolTipString(_("Agregar producto"))
        self.bitmap_button_5.SetSize(self.bitmap_button_5.GetBestSize())
        self.grid_Fact.CreateGrid(100, 5)
        self.grid_Fact.SetRowLabelAlignment(wx.ALIGN_RIGHT, wx.ALIGN_RIGHT)
        self.grid_Fact.EnableEditing(0)
        self.grid_Fact.SetRowLabelSize(30)
        self.grid_Fact.SetColLabelValue(0, _(u"C\xf3digo"))
        self.grid_Fact.SetColSize(0, 100)
        self.grid_Fact.SetColLabelValue(1, _(u"Descripci\xf3n"))
        self.grid_Fact.SetColSize(1, 250)
        self.grid_Fact.SetColLabelValue(2, _("Cantidad"))
        self.grid_Fact.SetColSize(2, 100)
        self.grid_Fact.SetColLabelValue(3, _("Precio Unitario"))
        self.grid_Fact.SetColSize(3, 100)
        self.grid_Fact.SetColLabelValue(4, _("Monto"))
        self.grid_Fact.SetColSize(4, 100)
        self.grid_Fact.SetMinSize((700, 225))
        self.text_ctrl_AF_subt.SetMinSize((100, 27))
        self.text_ctrl_AF_iva.Enable(False)
        self.text_ctrl_AF_addiva.SetMinSize((100, 27))
        self.text_ctrl_AF_item.SetMinSize((100, 27))
        self.bitmap_button_6.SetToolTipString(_("Guardar e Imprimir"))
        self.bitmap_button_6.SetSize(self.bitmap_button_6.GetBestSize())
        self.bitmap_button_7.SetToolTipString(_("Cancelar Factura"))
        self.bitmap_button_7.SetSize(self.bitmap_button_7.GetBestSize())
        self.notebook_addFact.Hide()
        self.label_40.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.label_6_copy_copy_copy.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.text_ctrl_I_dato.SetMinSize((120, 27))
        self.text_ctrl_I_dato.SetToolTipString(_("Busqueda de cliente por CI, Nombre o Apellido"))
        self.bitmap_button_1_copy.SetSize(self.bitmap_button_1_copy.GetBestSize())
        self.static_line_9.SetMinSize((700, 10))
        self.grid_invent.CreateGrid(100, 7)
        self.grid_invent.SetRowLabelSize(30)
        self.grid_invent.EnableEditing(0)
        self.grid_invent.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.grid_invent.SetColLabelValue(0, _(u"C\xf3digo"))
        self.grid_invent.SetColSize(0, 80)
        self.grid_invent.SetColLabelValue(1, _("Marca"))
        self.grid_invent.SetColSize(1, 100)
        self.grid_invent.SetColLabelValue(2, _("Modelo"))
        self.grid_invent.SetColSize(2, 100)
        self.grid_invent.SetColLabelValue(3, _(u"Descripci\xf3n"))
        self.grid_invent.SetColSize(3, 100)
        self.grid_invent.SetColLabelValue(4, _("Precio Unitario"))
        self.grid_invent.SetColSize(4, 100)
        self.grid_invent.SetColLabelValue(5, _("Existencia"))
        self.grid_invent.SetColSize(5, 80)
        self.grid_invent.SetColLabelValue(6, _("Valor"))
        self.grid_invent.SetColSize(6, 80)
        self.grid_invent.SetMinSize((700, 450))
        self.static_line_10.SetMinSize((700, 10))
        self.bitmap_button_61.SetToolTipString(_("Imprimir"))
        self.bitmap_button_61.SetSize(self.bitmap_button_61.GetBestSize())
        self.bitmap_button_71.SetToolTipString(_("Cerrar Reporte Mensual"))
        self.bitmap_button_71.SetSize(self.bitmap_button_71.GetBestSize())
        self.notebook_invet.Hide()
        self.label_40_copy.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.static_line_11.SetMinSize((700,15))
        self.grid_requis.CreateGrid(100, 6)
        self.grid_requis.SetRowLabelSize(30)

        self.grid_requis.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.grid_requis.SetColLabelValue(0, _("Marca "))
        self.grid_requis.SetColSize(0, 130)
        self.grid_requis.SetColLabelValue(1, _("Modelo"))
        self.grid_requis.SetColSize(1, 130)
        self.grid_requis.SetColLabelValue(2, _(u"Descripci\xf3n"))
        self.grid_requis.SetColSize(2, 130)
        self.grid_requis.SetColLabelValue(3, _("Existencia "))
        self.grid_requis.SetColSize(3, 130)
        self.grid_requis.SetColLabelValue(4, _(u"Stock M\xednimo"))
        self.grid_requis.SetColSize(4, 135)
        self.grid_requis.SetColLabelValue(5, _(u""))
        self.grid_requis.SetColSize(5, -100)
        self.grid_requis.SetMinSize((700, 500))
        self.static_line_12.SetMinSize((700, 15))
        self.bitmap_button_60.SetToolTipString(_("Imprimir"))
        self.bitmap_button_60.SetSize(self.bitmap_button_60.GetBestSize())
        self.bitmap_button_8.SetToolTipString(_(u"Guardar las modificaciones de \xcdtems"))
        self.bitmap_button_8.SetSize(self.bitmap_button_8.GetBestSize())
        self.bitmap_button_70.SetToolTipString(_("Cerrar Reporte Mensual"))
        self.bitmap_button_70.SetSize(self.bitmap_button_70.GetBestSize())
        self.notebook_requis.Hide()
        self.label_30.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.label_6_copy.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.combo_box_R_mes.SetMinSize((100, 29))
        self.combo_box_R_mes.SetSelection(0)
        self.spin_ctrl_R_ano.SetMinSize((60, 27))
        self.bitmap_button_R_search.SetToolTipString(_(u"B\xfascar"))
        self.bitmap_button_R_search.SetSize(self.bitmap_button_R_search.GetBestSize())
        self.static_line_7.SetMinSize((700, 10))
        self.grid_report.CreateGrid(100, 5)
        self.grid_report.SetRowLabelSize(30)
        self.grid_report.EnableEditing(0)
        self.grid_report.SetColLabelValue(0, _("Fecha"))
        self.grid_report.SetColSize(0, 130)
        self.grid_report.SetColLabelValue(1, _("Factura"))
        self.grid_report.SetColSize(1, 130)
        self.grid_report.SetColLabelValue(2, _(u"C\xe9dula"))
        self.grid_report.SetColSize(2, 130)
        self.grid_report.SetColLabelValue(3, _("Cliente"))
        self.grid_report.SetColSize(3, 140)
        self.grid_report.SetColLabelValue(4, _("Monto"))
        self.grid_report.SetColSize(4, 130)
        self.grid_report.SetMinSize((700,420))
        self.text_ctrl_R_total.SetMinSize((100, 27))
        self.static_line_8.SetMinSize((700, 10))
        self.bitmap_button_62.SetToolTipString(_("Imprimir"))
        self.bitmap_button_62.SetSize(self.bitmap_button_62.GetBestSize())
        self.bitmap_button_71_copy.SetToolTipString(_("Cerrar Reporte Mensual"))
        self.bitmap_button_71_copy.SetSize(self.bitmap_button_71_copy.GetBestSize())
        self.notebook_report.Hide()
        self.label_30_copy.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.label_6_copy_copy.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.text_ctrl_C_Dato.SetMinSize((120, 27))
        self.text_ctrl_C_Dato.SetToolTipString(_("Busqueda de cliente por CI, Nombre o Apellido"))
        self.bitmap_button_1.SetSize(self.bitmap_button_1.GetBestSize())
        self.static_line_13.SetMinSize((700,15))
        self.grid_client.CreateGrid(100, 4)
        self.grid_client.SetRowLabelSize(30)
        self.grid_client.EnableEditing(0)
        self.grid_client.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.grid_client.SetColLabelValue(0, _(u"C\xe9dula"))
        self.grid_client.SetColSize(0, 160)
        self.grid_client.SetColLabelValue(1, _("Nombre"))
        self.grid_client.SetColSize(1, 164)
        self.grid_client.SetColLabelValue(2, _(u"T\xe9lefono"))
        self.grid_client.SetColSize(2, 164)
        self.grid_client.SetColLabelValue(3, _("E- mail"))
        self.grid_client.SetColSize(3, 164)
        self.grid_client.SetMinSize((700, 420))
        self.static_line_14.SetMinSize((700, 15))
        self.bitmap_button_2.SetSize(self.bitmap_button_2.GetBestSize())
        self.notebook_client.SetMinSize((714, 613))
        self.notebook_client.Hide()
        self.notebook_1.SetMinSize((720, 420))
        # end wxGlade

    def __do_layout(self):
        # begin wxGlade: Menu.__do_layout
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        grid_sizer_20 = wx.FlexGridSizer(7, 1, 0, 0)
        grid_sizer_21 = wx.FlexGridSizer(1, 4, 0, 0)
        grid_sizer_3_copy_copy = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_6_copy_copy_1 = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_17 = wx.FlexGridSizer(8, 1, 0, 0)
        grid_sizer_80 = wx.FlexGridSizer(1, 3, 0, 0)
        grid_sizer_14_copy = wx.FlexGridSizer(3, 3, 0, 0)
        grid_sizer_5_copy = wx.FlexGridSizer(1, 11, 0, 0)
        grid_sizer_3_copy = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_6_copy = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_19 = wx.FlexGridSizer(5, 1, 0, 0)
        grid_sizer_40 = wx.FlexGridSizer(1, 3, 0, 0)
        grid_sizer_6_copy_copy_copy = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_18 = wx.FlexGridSizer(8, 1, 0, 0)
        grid_sizer_50 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_21_copy = wx.FlexGridSizer(1, 4, 0, 0)
        grid_sizer_3_copy_copy_copy = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_6_copy_copy = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_2 = wx.FlexGridSizer(15, 1, 0, 0)
        grid_sizer_16 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_14 = wx.FlexGridSizer(3, 3, 0, 0)
        grid_sizer_15 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_13 = wx.FlexGridSizer(1, 8, 0, 0)
        grid_sizer_12 = wx.FlexGridSizer(2, 6, 0, 0)
        grid_sizer_11 = wx.FlexGridSizer(1, 5, 0, 0)
        grid_sizer_10 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_9 = wx.FlexGridSizer(1, 6, 0, 0)
        grid_sizer_8 = wx.FlexGridSizer(1, 6, 0, 0)
        grid_sizer_7 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_6 = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_1 = wx.FlexGridSizer(7, 1, 0, 0)
        grid_sizer_5 = wx.FlexGridSizer(1, 11, 0, 0)
        grid_sizer_3 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_4 = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_4.Add((20, 5), 0, 0, 0)
        grid_sizer_4.Add(self.label_7, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_1.Add(grid_sizer_4, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_3.Add((20, 20), 0, 0, 0)
        grid_sizer_3.Add(self.label_6, 0, 0, 0)
        grid_sizer_1.Add(grid_sizer_3, 1, wx.EXPAND, 0)
        grid_sizer_5.Add((20, 20), 0, 0, 0)
        grid_sizer_5.Add(self.label_8, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5.Add(self.combo_box_H_mes, 0, 0, 0)
        grid_sizer_5.Add((20, 20), 0, 0, 0)
        grid_sizer_5.Add(self.label_9, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5.Add(self.spin_ctrl_H_ano, 0, 0, 0)
        grid_sizer_5.Add((20, 20), 0, 0, 0)
        grid_sizer_5.Add(self.label_10, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5.Add(self.combo_box_H_cat, 0, 0, 0)
        grid_sizer_5.Add((20, 20), 0, 0, 0)
        grid_sizer_5.Add(self.bitmap_button_H_search, 0, 0, 0)
        grid_sizer_1.Add(grid_sizer_5, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_1.Add(self.static_line_1, 0, wx.EXPAND, 0)
        grid_sizer_1.Add(self.grid_Hist, 1, wx.EXPAND, 0)
        grid_sizer_1.Add(self.static_line_2, 0, wx.EXPAND, 0)
        grid_sizer_1.Add(self.bitmap_button_H_close, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_hist.SetSizer(grid_sizer_1)
        grid_sizer_6.Add((11, 5), 0, 0, 0)
        grid_sizer_6.Add(self.label_1, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_6, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_2.Add(self.static_line_3, 0, wx.EXPAND, 0)
        grid_sizer_7.Add((20, 20), 0, 0, 0)
        grid_sizer_7.Add(self.label_2, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_7, 1, wx.EXPAND, 0)
        grid_sizer_8.Add((50, 20), 0, 0, 0)
        grid_sizer_8.Add(self.label_3, 0, 0, 0)
        grid_sizer_8.Add((67, 20), 0, 0, 0)
        grid_sizer_8.Add(self.text_ctrl_AF_ci, 0, 0, 0)
        grid_sizer_8.Add(self.bitmap_button_3, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_8, 1, wx.EXPAND, 0)
        grid_sizer_9.Add((50, 20), 0, 0, 0)
        grid_sizer_9.Add(self.label_4, 0, 0, 0)
        grid_sizer_9.Add(self.text_ctrl_AF_name, 0, 0, 0)
        grid_sizer_9.Add((20, 20), 0, 0, 0)
        grid_sizer_9.Add(self.label_5, 0, 0, 0)
        grid_sizer_9.Add(self.text_ctrl_AF_tlf, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_9, 1, wx.EXPAND, 0)
        grid_sizer_2.Add(self.static_line_4, 0, wx.EXPAND, 0)
        grid_sizer_10.Add((20, 20), 0, 0, 0)
        grid_sizer_10.Add(self.label_11, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_10, 1, wx.EXPAND, 0)
        grid_sizer_11.Add((50, 20), 0, 0, 0)
        grid_sizer_11.Add(self.label_12, 0, 0, 0)
        grid_sizer_11.Add((70, 20), 0, 0, 0)
        grid_sizer_11.Add(self.text_ctrl_AF_Sitem, 0, 0, 0)
        grid_sizer_11.Add(self.bitmap_button_4, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_11, 1, wx.EXPAND, 0)
        grid_sizer_12.Add((50, 20), 0, 0, 0)
        grid_sizer_12.Add(self.label_13, 0, 0, 0)
        grid_sizer_12.Add(self.text_ctrl_AF_cod, 0, 0, 0)
        grid_sizer_12.Add((20, 20), 0, 0, 0)
        grid_sizer_12.Add(self.label_15, 0, 0, 0)
        grid_sizer_12.Add(self.text_ctrl_AF_brand, 0, 0, 0)
        grid_sizer_12.Add((50, 20), 0, 0, 0)
        grid_sizer_12.Add(self.label_14, 0, 0, 0)
        grid_sizer_12.Add(self.text_ctrl_AF_descrip, 0, 0, 0)
        grid_sizer_12.Add((20, 20), 0, 0, 0)
        grid_sizer_12.Add(self.label_16, 0, 0, 0)
        grid_sizer_12.Add(self.text_ctrl_AF_model, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_12, 1, wx.EXPAND, 0)
        grid_sizer_13.Add((50, 20), 0, 0, 0)
        grid_sizer_13.Add(self.label_17, 0, 0, 0)
        grid_sizer_13.Add((60, 20), 0, 0, 0)
        grid_sizer_13.Add(self.text_ctrl_AF_cant, 0, 0, 0)
        grid_sizer_13.Add(self.bitmap_button_5, 0, 0, 0)
        grid_sizer_13.Add((50, 20), 0, 0, 0)
        grid_sizer_13.Add(self.label_18, 0, 0, 0)
        grid_sizer_13.Add(self.text_ctrl_AF_exist, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_13, 1, wx.EXPAND, 0)
        grid_sizer_2.Add(self.static_line_5, 0, wx.EXPAND, 0)
        grid_sizer_2.Add(self.grid_Fact, 1, wx.EXPAND, 0)
        grid_sizer_14.Add(self.label_19, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_14.Add(self.text_ctrl_AF_subt, 0, 0, 0)
        grid_sizer_14.Add((20, 20), 0, 0, 0)
        grid_sizer_15.Add(self.label_20, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_15.Add(self.text_ctrl_AF_iva, 0, 0, 0)
        grid_sizer_14.Add(grid_sizer_15, 1, wx.EXPAND, 0)
        grid_sizer_14.Add(self.text_ctrl_AF_addiva, 0, 0, 0)
        grid_sizer_14.Add((20, 20), 0, 0, 0)
        grid_sizer_14.Add(self.label_21, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_14.Add(self.text_ctrl_AF_item, 0, 0, 0)
        grid_sizer_14.Add((20, 20), 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_14, 1, wx.ALIGN_RIGHT, 0)
        grid_sizer_2.Add(self.static_line_6, 0, wx.EXPAND, 0)
        grid_sizer_16.Add(self.bitmap_button_6, 0, 0, 0)
        grid_sizer_16.Add(self.bitmap_button_7, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_16, 1, wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_addFact.SetSizer(grid_sizer_2)
        grid_sizer_6_copy_copy.Add((11, 5), 0, 0, 0)
        grid_sizer_6_copy_copy.Add(self.label_40, 0, 0, 0)
        grid_sizer_18.Add(grid_sizer_6_copy_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_3_copy_copy_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_3_copy_copy_copy.Add(self.label_6_copy_copy_copy, 0, 0, 0)
        grid_sizer_18.Add(grid_sizer_3_copy_copy_copy, 1, wx.EXPAND, 0)
        grid_sizer_21_copy.Add(self.label_22_copy, 0, 0, 0)
        grid_sizer_21_copy.Add(self.text_ctrl_I_dato, 0, 0, 0)
        grid_sizer_21_copy.Add(self.bitmap_button_1_copy, 0, 0, 0)
        grid_sizer_18.Add(grid_sizer_21_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_18.Add(self.static_line_9, 0, wx.EXPAND, 0)
        grid_sizer_18.Add(self.grid_invent, 1, wx.EXPAND, 0)
        grid_sizer_18.Add(self.static_line_10, 0, wx.EXPAND, 0)
        grid_sizer_50.Add(self.bitmap_button_61, 0, 0, 0)
        grid_sizer_50.Add(self.bitmap_button_71, 0, 0, 0)
        grid_sizer_18.Add(grid_sizer_50, 1, wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_invet.SetSizer(grid_sizer_18)
        grid_sizer_6_copy_copy_copy.Add((11, 5), 0, 0, 0)
        grid_sizer_6_copy_copy_copy.Add(self.label_40_copy, 0, 0, 0)
        grid_sizer_19.Add(grid_sizer_6_copy_copy_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_19.Add(self.static_line_11, 0, wx.EXPAND, 0)
        grid_sizer_19.Add(self.grid_requis, 1, wx.EXPAND, 0)
        grid_sizer_19.Add(self.static_line_12, 0, wx.EXPAND, 0)
        grid_sizer_40.Add(self.bitmap_button_60, 0, 0, 0)
        grid_sizer_40.Add(self.bitmap_button_8, 0, 0, 0)
        grid_sizer_40.Add(self.bitmap_button_70, 0, 0, 0)
        grid_sizer_19.Add(grid_sizer_40, 1, wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_requis.SetSizer(grid_sizer_19)
        grid_sizer_6_copy.Add((11, 5), 0, 0, 0)
        grid_sizer_6_copy.Add(self.label_30, 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_6_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_3_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_3_copy.Add(self.label_6_copy, 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_3_copy, 1, wx.EXPAND, 0)
        grid_sizer_5_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_5_copy.Add(self.label_8_copy, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5_copy.Add(self.combo_box_R_mes, 0, 0, 0)
        grid_sizer_5_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_5_copy.Add(self.label_9_copy, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5_copy.Add(self.spin_ctrl_R_ano, 0, 0, 0)
        grid_sizer_5_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_5_copy.Add(self.bitmap_button_R_search, 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_5_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_17.Add(self.static_line_7, 0, wx.EXPAND, 0)
        grid_sizer_17.Add(self.grid_report, 1, wx.EXPAND, 0)
        grid_sizer_14_copy.Add(self.label_21_copy, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_14_copy.Add(self.text_ctrl_R_total, 0, 0, 0)
        grid_sizer_14_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_14_copy, 1, wx.ALIGN_RIGHT, 0)
        grid_sizer_17.Add(self.static_line_8, 0, wx.EXPAND, 0)
        grid_sizer_80.Add(self.bitmap_button_62, 0, 0, 0)
        grid_sizer_80.Add(self.bitmap_button_71_copy, 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_80, 1, wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_report.SetSizer(grid_sizer_17)
        grid_sizer_6_copy_copy_1.Add((11, 5), 0, 0, 0)
        grid_sizer_6_copy_copy_1.Add(self.label_30_copy, 0, 0, 0)
        grid_sizer_20.Add(grid_sizer_6_copy_copy_1, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_3_copy_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_3_copy_copy.Add(self.label_6_copy_copy, 0, 0, 0)
        grid_sizer_20.Add(grid_sizer_3_copy_copy, 1, wx.EXPAND, 0)
        grid_sizer_21.Add(self.label_22, 0, 0, 0)
        grid_sizer_21.Add(self.text_ctrl_C_Dato, 0, 0, 0)
        grid_sizer_21.Add(self.bitmap_button_1, 0, 0, 0)
        grid_sizer_20.Add(grid_sizer_21, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_20.Add(self.static_line_13, 0, wx.EXPAND, 0)
        grid_sizer_20.Add(self.grid_client, 1, wx.EXPAND, 0)
        grid_sizer_20.Add(self.static_line_14, 0, wx.EXPAND, 0)
        grid_sizer_20.Add(self.bitmap_button_2, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        self.notebook_client.SetSizer(grid_sizer_20)
        self.notebook_1.AddPage(self.notebook_hist, _("Historial"))
        self.notebook_1.AddPage(self.notebook_addFact, _("Nueva Factura"))
        self.notebook_1.AddPage(self.notebook_invet, _("Inventario"))
        self.notebook_1.AddPage(self.notebook_requis, _(u"Productos por debajo del M\xednimo"))
        self.notebook_1.AddPage(self.notebook_report, _("Reporte Mensual "))
        self.notebook_1.AddPage(self.notebook_client, _("Clientes "))
        sizer_1.Add(self.notebook_1, 1, wx.EXPAND, 0)
        self.SetSizer(sizer_1)
        self.Layout()
        # end wxGlade

    def onHist(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_hist.Show()
        datos = chist.Ctrl_hist()
        ar =datos.mostrar_historial()
        ext =len(ar)
        for t in range(ext):
            for r in range(3):
                self.grid_Hist.SetCellValue(t, r, str(ar[t][r]))
        event.Skip()

    def onExit(self, event):  # wxGlade: Menu.<event_handler>
        dlg = wx.MessageDialog(self,
                               "¿Realmente quiere cerrar la Aplicación?",
                               "Confirmar Sálida", wx.OK|wx.CANCEL|wx.ICON_QUESTION)
        result = dlg.ShowModal()

        dlg.Destroy()
        if result == wx.ID_OK:
            self.Destroy()

        def onSearch_factura(self, event):  # wxGlade: Menu.<event_handler>
            dlg = DsFact.Dialog_search_fact()
            dlg.Show()
        event.Skip()

    def onSaveDB(self, event):  # wxGlade: Menu.<event_handler>
        print "Event handler 'onSaveDB' not implemented!"
        event.Skip()

    def onImport(self, event):  # wxGlade: Menu.<event_handler>
        print "Event handler 'onImport' not implemented!"
        event.Skip()

    def onAddFact(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_addFact.Show()

    def onReport(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        year = time.strftime("%Y")
        mon = time.strftime("%m")
        self.notebook_report.Show()
        self.notebook_report.AcceptsFocus()
        res = cFact.Ctrl_Fact()
        ar = res.report(year,mon)
        self.rep =len(ar)
        for t in range(self.rep):
            for r in range(5):
                self.grid_report.SetCellValue(t, r, str(ar[t][r]))
                if ar[t][r] == ar[t][4]:
                        new = val.monetario(float(ar[t][r]))
                        self.grid_report.SetCellValue(t, r, str(new))
                        self.sub = self.sub + float(ar[t][4])
                        self.text_ctrl_R_total.SetValue(str(val.monetario(self.sub)))

        event.Skip()

    def onSearchFact(self, event):  # wxGlade: Menu.<event_handler>
        dlg = DsFact.Dialog_search_fact()
        dlg.Show()
        event.Skip()

    def onIva(self, event):  # wxGlade: Menu.<event_handler>
        dlg = Diva.Dialog_iva()
        dlg.Show()

    def onInvent(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        self.notebook_invet.Show()
        res = citem.Ctrl_item()
        ar = res.inventario()
        self.inv =len(ar)
        for t in range(self.inv):
            for r in range(7):
                self.grid_invent.SetCellValue(t, r, str(ar[t][r]))
                if ar[t][r] == ar[t][4] or ar[t][r] == ar[t][6]:
                    new = val.monetario(float(ar[t][r]))
                    self.grid_invent.SetCellValue(t, r, str(new))
        event.Skip()

    def onRequis(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_requis.Show()
        res = citem.Ctrl_item()
        ar = res.requisiciones()
        ext =len(ar)
        self.req = ext
        for t in range(ext):
            for r in range(6):
                self.grid_requis.SetCellValue(t, r, str(ar[t][r]))
        event.Skip()

    def onAddItem(self, event):  # wxGlade: Menu.<event_handler>
        dlg = Ditem.Dialog_item()
        dlg.Show()
        event.Skip()

    def onSearchItem(self, event):  # wxGlade: Menu.<event_handler>
        dlg = DsItem.Dialog_search_item()
        dlg.Show()

    def onClients(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_client.Show()
        res =ccli.Ctrl_Cliente()
        ar = res.list_cli()
        ext =len(ar)
        for t in range(ext):
            for r in range(4):
                self.grid_client.SetCellValue(t, r, str(ar[t][r]))
        event.Skip()

    def onSearchClient(self, event):  # wxGlade: Menu.<event_handler>
        dlg = DsClie.Dialog_search_client()
        dlg.Show()
        event.Skip()

    def onAddClient(self, event):  # wxGlade: Menu.<event_handler>
        dlg = Dcli.Dialog_client()
        dlg.Show()
        event.Skip()

    def onPerfil(self, event):  # wxGlade: Menu.<event_handler>
        dlg =duser.Dialog_User()
        dlg.Mostrar()

    def onClose(self, event):  # wxGlade: Menu.<event_handler>
        self.Refresh()
        dlg = login.Dialog_Login()
        dlg.Show()
        log = user.Ctrl_user()
        log.loguot()
        event.Skip()

    def onAbout(self, event):  # wxGlade: Menu.<event_handler>
        dlg = wx.MessageDialog(self, "Jhosnoirlit Hernández\njhosnoirlit@gmail.com\n\nPython2.7 - WxGlade2.8 \n\n           2015", "Acerca de",wx.CLOSE_BOX) # wx.OK)
        dlg.ShowModal()
        #dlg.Destroy()
        event.Skip()

    def onHelp(self, event):  # wxGlade: Menu.<event_handler>
        print "Event handler 'onHelp' not implemented!"
        event.Skip()

    def onHistASearch(self, event):  # wxGlade: Menu.<event_handler>
        self.grid_Hist.ClearGrid()
        mon = self.combo_box_H_mes.GetCurrentSelection()
        val = validar.Validacion()
        mes = val.meses(mon)
        ano = self.spin_ctrl_H_ano.GetValue()
        cat = self.combo_box_H_cat.GetValue()
        res = chist.Ctrl_hist()
        bus = res.busqueda(ano, mes, cat)
        ext =len(bus)
        for t in range(ext):
            for r in range(3):
                self.grid_Hist.SetCellValue(t, r, str(bus[t][r]))

        event.Skip()

    def onHistClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_hist.Hide()
        event.Skip()

    def onFactCliente(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        ci = self.text_ctrl_AF_ci.GetValue()
        if ci == "":
            dlg = wx.MessageDialog(self, "Para continuar debe ingresar una cédula de cliente", "Notificación", wx.ICON_WARNING| wx.OK)
            dlg.ShowModal()
            dlg.Destroy()
        else:
            cliente = cFact.Ctrl_Fact()
            res = cliente.search_client(ci)

            if res == None:
                dlg = wx.MessageDialog(self, "No se ha encontrado ese cliente, pero puede registrarlo", "Notificación", wx.OK)
                dlg.ShowModal()
                dlg.Destroy()
                razon = 1
                nuevocli = Dcli.Dialog_client(razon)
                nuevocli.nuevo_cliente(self.text_ctrl_AF_ci.GetValue())
            else:
                self.text_ctrl_AF_name.SetValue(res[0])
                self.text_ctrl_AF_tlf.SetValue(res[1])
                self.text_ctrl_AF_ci.Enable(False)
        event.Skip()

    def onFactItem(self, event):  # wxGlade: Menu.<event_handler>
        dato = self.text_ctrl_AF_Sitem.GetValue()
        item = cFact.Ctrl_Fact()
        res = item.search_item(dato)
        for row in range(int(self.fila)):
            if dato == self.grid_Fact.GetCellValue(row,0):
                dlg = wx.MessageDialog(self, "Ya has ingresado este producto, intenta modificarlo", "Notificación", wx.OK)
                self.text_ctrl_AF_Sitem.Clear()
                dlg.ShowModal()
                dlg.Destroy()


        if res == None:
            dlg = wx.MessageDialog(self, u"Este ítem no esta en existencia", "Notificación", wx.OK)
            dlg.ShowModal()
            dlg.Destroy()
            self.text_ctrl_AF_Sitem.Clear()

        else:
            self.text_ctrl_AF_cod.SetValue(str(res[0]))
            self.text_ctrl_AF_model.SetValue(res[1])
            self.text_ctrl_AF_brand.SetValue(res[2])
            self.text_ctrl_AF_descrip.SetValue(res[3])
            self.text_ctrl_AF_exist.SetValue(str(res[5]))

    def onFactAdd(self, event):  # wxGlade: Menu.<event_handler>
        iditem = self.text_ctrl_AF_cod.GetValue()
        cant = self.text_ctrl_AF_cant.GetValue()
        exist = self.text_ctrl_AF_exist.GetValue()
        if cant > exist:
                dlg = wx.MessageDialog(self, "No existe esa cantidad en existencia", "Notificación", wx.OK)
                self.text_ctrl_AF_cant.Clear()
                dlg.ShowModal()
                dlg.Destroy()
        elif cant == "":
                dlg = wx.MessageDialog(self, "Debe agregar una cantidad para proceder", "Notificación", wx.OK)
                self.text_ctrl_AF_cant.Clear()
                dlg.ShowModal()
                dlg.Destroy()
        else:
                con= cFact.Ctrl_Fact()
                res = con.cant_item(iditem)
                val = validar.Validacion()
                punit = float(res[2])
                monto = punit * float(cant)
                subt =self.sub = self.sub + monto
                self.grid_Fact.SetCellValue(self.fila, 0, str(res[0]))
                self.grid_Fact.SetCellValue(self.fila, 1, res[1])
                self.grid_Fact.SetCellValue(self.fila, 2, str(cant))
                self.grid_Fact.SetCellValue(self.fila, 3, str(val.monetario(punit)))
                self.grid_Fact.SetCellValue(self.fila, 4, str(val.monetario(monto)))
                self.text_ctrl_AF_subt.SetValue(str(val.monetario(subt)))
                self.text_ctrl_AF_Sitem.Clear()
                self.text_ctrl_AF_model.Clear()
                self.text_ctrl_AF_exist.Clear()
                self.text_ctrl_AF_descrip.Clear()
                self.text_ctrl_AF_brand.Clear()
                self.text_ctrl_AF_cod.Clear()
                self.text_ctrl_AF_cant.Clear()
                self.fila += 1
                iva = con.iva()
                siva= "(" + str(iva[0]) + "%): "
                self.text_ctrl_AF_iva.SetValue(siva)
                valor = int(iva[0])
                #self.text_ctrl_21.SetValue(str(valor))
                trans = float(valor)/100
                base = subt * trans
                total = subt + base
                self.text_ctrl_AF_addiva.SetValue(str(val.monetario(base)))
                self.text_ctrl_AF_item.SetValue(str(val.monetario(total)))

    def onFactPrint(self, event):  # wxGlade: Menu.<event_handler>
        dato =self.text_ctrl_AF_ci.GetValue()
        confir = self.grid_Fact.GetCellValue(0,0)
        ## valida que existan campos
        if confir == "":
            dlg = wx.MessageDialog(self, "Debe haber algun item para procesar la facturación", "Notificación", wx.OK)
            dlg.ShowModal()
            dlg.Destroy()

        if dato =="":
            dlg = wx.MessageDialog(self, "No has ingresado ningún cliente", "Notificación", wx.OK)
            dlg.ShowModal()
            dlg.Destroy()
        ##busca el cliente
        con = cFact.Ctrl_Fact()
        res = con.search_client(dato)
        idcli=res[2]
        iva = con.iva()
        valor = iva [0]
        ##crea la factura con los datos de iva y cliente
        con.add_fact(valor, idcli)
        fid = cFact.Ctrl_Fact()
        facid=fid.facid()
        val = validar.Validacion()
        ## llena factura_has_item
        for fil in range(int(self.fila)):
            row = []
            row.append(facid[0])
            for cell in [0,2,3]:
                if cell == 3:
                    celda = val.monedadb(self.grid_Fact.GetCellValue(fil, cell))
                    row.append(celda)
                else:
                    celda = self.grid_Fact.GetCellValue(fil, cell)
                    row.append(celda)


            tpl = tuple(row)
            newite = cFact.Ctrl_Fact()
            newite.add_item(tpl)
        ##llama a la funsion para imprimir
        total = val.monedadb(self.text_ctrl_AF_item.GetValue())
        sub = val.monedadb(self.text_ctrl_AF_subt.GetValue())
        iva = val.monedadb(self.text_ctrl_AF_addiva.GetValue())
        con.print_fact(facid[0], sub, iva, total)
        ##se limpia la pestaña
        self.notebook_addFact.Hide()
        self.grid_Fact.ClearGrid()
        self.text_ctrl_AF_descrip.Clear()
        self.text_ctrl_AF_ci.Enable(True)
        self.text_ctrl_AF_ci.Clear()
        self.text_ctrl_AF_addiva.Clear()
        self.text_ctrl_AF_brand.Clear()
        self.text_ctrl_AF_cant.Clear()
        self.text_ctrl_AF_cod.Clear()
        self.text_ctrl_AF_exist.Clear()
        self.text_ctrl_AF_item.Clear()
        self.text_ctrl_AF_iva.Clear()
        self.text_ctrl_AF_model.Clear()
        self.text_ctrl_AF_name.Clear()
        self.text_ctrl_AF_Sitem.Clear()
        self.text_ctrl_AF_subt.Clear()
        self.text_ctrl_AF_tlf.Clear()
        self.fila =0
        self.sub =0

    def onFactClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_addFact.Hide()
        self.grid_Fact.ClearGrid()
        self.text_ctrl_AF_descrip.Clear()
        self.text_ctrl_AF_ci.Enable(True)
        self.text_ctrl_AF_ci.Clear()
        self.text_ctrl_AF_addiva.Clear()
        self.text_ctrl_AF_brand.Clear()
        self.text_ctrl_AF_cant.Clear()
        self.text_ctrl_AF_cod.Clear()
        self.text_ctrl_AF_exist.Clear()
        self.text_ctrl_AF_item.Clear()
        self.text_ctrl_AF_iva.Clear()
        self.text_ctrl_AF_model.Clear()
        self.text_ctrl_AF_name.Clear()
        self.text_ctrl_AF_Sitem.Clear()
        self.text_ctrl_AF_subt.Clear()
        self.text_ctrl_AF_tlf.Clear()
        self.fila =0
        self.sub =0

        event.Skip()

    def onInventSearch(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        self.grid_invent.ClearGrid()
        dato = self.text_ctrl_I_dato.GetValue()
        invet = citem.Ctrl_item()
        ar = invet.busqueda_requis(dato)
        t =len(ar)
        for t in range(t):
            for r in range(7):
                self.grid_invent.SetCellValue(t, r, str(ar[t][r]))
                if ar[t][r] == ar[t][4] or ar[t][r] == ar[t][6]:
                        self.grid_invent.SetCellAlignment(wx.ALIGN_RIGHT, wx.ALIGN_CENTRE)
                        new = val.monetario(float(ar[t][r]))
                        self.grid_invent.SetCellValue(t, r, str(new))


        event.Skip()

    def onInventPrint(self, event):  # wxGlade: Menu.<event_handler>
        tlp=[]
        for t in range(self.inv):
            row = []
            for r in range(7):
                row.append(self.grid_invent.GetCellValue(t, r))

            tlp.append(row)
        event.Skip()
        pdf = cPdf.PDF()
        pdf.Inventario(tlp)
        self.grid_invent.ClearGrid()
        self.inv=0
        self.Hide()
        event.Skip()

    def onInventClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_invet.Hide()
        self.notebook_invet.Refresh()
        event.Skip()

    def onRequisPrint(self, event):  # wxGlade: Menu.<event_handler>
        tlp=[]
        for fil in range(self.req):
            row = []
            for cell in range(5):
                row.append(self.grid_requis.GetCellValue(fil, cell))
            tlp.append(row)
        pdf = cPdf.PDF()
        pdf.print_requis(tlp)

    def onRequisSave(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        for fil in range(self.req):
            row = []
            for cell in [0,1,2,3,5]:
                if cell ==0 or cell == 1:
                    val.vacio(self.grid_requis.GetCellValue(fil, cell), "Marca o Modelo")

                if cell == 2:
                    val.alfabetico(self.grid_requis.GetCellValue(fil, cell), "Descripción")

                if cell == 3:
                   val.numerico(self.grid_requis.GetCellValue(fil, cell), "Existencia ")

                row.append(self.grid_requis.GetCellValue(fil, cell))

            tpl = tuple(row)
            newreq = citem.Ctrl_item()
            newreq.actualizar_requis(tpl)
        self.grid_requis.ClearGrid()
        self.fila =0

    def onRequisClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_requis.Hide()
        self.notebook_requis.Refresh()
        event.Skip()

    def onReportSearch(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        year = self.spin_ctrl_R_ano.GetValue()
        mon = self.combo_box_R_mes.GetCurrentSelection()
        self.notebook_report.Show()
        self.notebook_report.AcceptsFocus()
        res = cFact.Ctrl_Fact()
        ar = res.report(year,mon)
        ext =len(ar)
        for t in range(ext):
            for r in range(5):
                self.grid_report.SetCellValue(t, r, str(ar[t][r]))
                if ar[t][r] == ar[t][4]:
                        new = val.monetario(float(ar[t][r]))
                        self.grid_report.SetCellValue(t, r, str(new))
                        self.sub = self.sub + float(ar[t][4])
                        self.text_ctrl_R_total.SetValue(str(val.monetario(self.sub)))

    def onReporPrint(self, event):  # wxGlade: Menu.<event_handler>
        tlp=[]
        for fil in range(self.rep):
            row = []
            for cell in range(5):
                row.append(self.grid_report.GetCellValue(fil, cell))
            tlp.append(row)
        ttl = self.text_ctrl_R_total.GetValue()
        pdf = cPdf.PDF()
        pdf.print_report(tlp, ttl)

    def onReportClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_report.Hide()
        self.notebook_report.Refresh()
        self.grid_report.ClearGrid()
        self.combo_box_R_mes.SetValue("")
        self.sub = 0
        self.rep = 0
        self.text_ctrl_R_total.Clear()
        event.Skip()

    def onClientSearch(self, event):  # wxGlade: Menu.<event_handler>
        val =validar.Validacion()
        dato = val.vacio(self.text_ctrl_C_Dato.GetValue(),"Búsqueda de cliente")
        bus = ccli.Ctrl_Cliente()
        ar = bus.buscar_client(dato)
        self.grid_client.ClearGrid()
        ext =len(ar)
        for t in range(ext):
            for r in range(4):
                self.grid_client.SetCellValue(t, r, str(ar[t][r]))

    def onClientClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_client.Hide()
        self.notebook_client.Refresh()
        event.Skip()

