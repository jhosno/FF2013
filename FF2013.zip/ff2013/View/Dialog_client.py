#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import wx
import Controller.ctrl_cliente as cCli
import Model.model_validar as val
import os
# begin wxGlade: dependencies
# end wxGlade

# begin wxGlade: extracode
# end wxGlade


class Dialog_client(wx.Dialog):
    def __init__(self, *args, **kwds):
        # begin wxGlade: Dialog_Client.__init__
        kwds["style"] = wx.DEFAULT_DIALOG_STYLE
        wx.Dialog.__init__(self, None, **kwds)
        self.label_24 = wx.StaticText(self, wx.ID_ANY, _("Cliente"))
        self.static_line_17 = wx.StaticLine(self, wx.ID_ANY)
        self.label_25 = wx.StaticText(self, wx.ID_ANY, _(u"C\xe9dula: "))
        self.choice_ci = wx.Choice(self, wx.ID_ANY, choices=[_("V-"), _("E-"), _("J-")])
        self.text_ctrl_ci = wx.TextCtrl(self, wx.ID_ANY, "")
        self.label_35 = wx.StaticText(self, wx.ID_ANY, _("Nombre: "))
        self.text_ctrl_name = wx.TextCtrl(self, wx.ID_ANY, "")
        self.label_36 = wx.StaticText(self, wx.ID_ANY, _(u"T\xe9lefono: "))
        self.text_ctrl_tlf = wx.TextCtrl(self, wx.ID_ANY, "")
        self.label_37 = wx.StaticText(self, wx.ID_ANY, _("E- Mail: "))
        self.text_ctrl_mail = wx.TextCtrl(self, wx.ID_ANY, "")
        self.static_line_18 = wx.StaticLine(self, wx.ID_ANY)
        button_15 =os.path.abspath('../View/img/icons/close_circle_big.png')
        button_16 =os.path.abspath('../View/img/icons/save_big.png')
        self.bitmap_button_10 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_15, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_15 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_16, wx.BITMAP_TYPE_ANY))

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_BUTTON, self.onClose, self.bitmap_button_10)
        self.Bind(wx.EVT_BUTTON, self.onSave, self.bitmap_button_15)
        # end wxGlade

    def __set_properties(self):
        # begin wxGlade: Dialog_Client.__set_properties
        self.SetTitle(_("Cliente"))
        favicon = os.path.abspath('../View/img/logotipo_tini.png')
        _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap(favicon, wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.SetSize((350, 233))
        self.SetToolTipString(_(u"Nombre o Raz\xf3n Social"))
        self.label_24.SetFont(wx.Font(11, wx.DEFAULT, wx.NORMAL, wx.BOLD, 0, ""))
        self.static_line_17.SetMinSize((350, 10))
        self.choice_ci.SetToolTipString(_(u"C\xe9dula o R.I.F."))
        self.choice_ci.SetSelection(0)
        self.text_ctrl_ci.SetMinSize((100, 27))
        self.text_ctrl_ci.SetToolTipString(_(u"C\xe9dula o R.I.F."))
        self.text_ctrl_name.SetMinSize((180, 27))
        self.text_ctrl_name.SetToolTipString(_(u"Nombre o Raz\xf3n Social"))
        self.text_ctrl_tlf.SetMinSize((100, 27))
        self.text_ctrl_tlf.SetToolTipString(_(u"T\xe9lefono de Contacto"))
        self.text_ctrl_mail.SetMinSize((180, 27))
        self.text_ctrl_mail.SetToolTipString(_(u"Direcci\xf3n de Correo Electron\xedco"))
        self.static_line_18.SetMinSize((340, 10))
        self.bitmap_button_10.SetMinSize((40, 42))
        self.bitmap_button_10.SetToolTipString(_("Cancelar"))
        self.bitmap_button_15.SetMinSize((40, 42))
        self.bitmap_button_15.SetToolTipString(_("Guardar"))
        # end wxGlade

    def __do_layout(self):
        # begin wxGlade: Dialog_Client.__do_layout
        grid_sizer_28 = wx.FlexGridSizer(6, 1, 0, 0)
        grid_sizer_31 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_29 = wx.FlexGridSizer(4, 2, 0, 0)
        grid_sizer_30 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_28.Add((20, 20), 0, 0, 0)
        grid_sizer_28.Add(self.label_24, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_28.Add(self.static_line_17, 0, wx.EXPAND, 0)
        grid_sizer_29.Add(self.label_25, 0, 0, 0)
        grid_sizer_30.Add(self.choice_ci, 0, 0, 0)
        grid_sizer_30.Add(self.text_ctrl_ci, 0, 0, 0)
        grid_sizer_29.Add(grid_sizer_30, 1, wx.EXPAND, 0)
        grid_sizer_29.Add(self.label_35, 0, 0, 0)
        grid_sizer_29.Add(self.text_ctrl_name, 0, 0, 0)
        grid_sizer_29.Add(self.label_36, 0, 0, 0)
        grid_sizer_29.Add(self.text_ctrl_tlf, 0, 0, 0)
        grid_sizer_29.Add(self.label_37, 0, 0, 0)
        grid_sizer_29.Add(self.text_ctrl_mail, 0, 0, 0)
        grid_sizer_28.Add(grid_sizer_29, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_28.Add(self.static_line_18, 0, wx.EXPAND, 0)
        grid_sizer_31.Add(self.bitmap_button_10, 0, 0, 0)
        grid_sizer_31.Add(self.bitmap_button_15, 0, 0, 0)
        grid_sizer_28.Add(grid_sizer_31, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.SetSizer(grid_sizer_28)
        self.Layout()
        # end wxGlade

    def onClose(self, event):  # wxGlade: Dialog_client.<event_handler>
        self.Destroy()
        event.Skip()

    def onSave(self, event):  # wxGlade: Dialog_client.<event_handler>
        validar = val.Validacion()
        ci = validar.tra_per(self.choice_ci.GetCurrentSelection()) + validar.cedula(self.text_ctrl_ci.GetValue(), "Cédula")
        nombre = validar.vacio(self.text_ctrl_name.GetValue(), "Nombre")
        email = validar.email(self.text_ctrl_mail.GetValue(), "E-mail")
        tlf = validar.numerico(self.text_ctrl_tlf.GetValue(), "Telefono")
        cliente = cCli.Ctrl_Cliente()
        cliente.guardar_cliente(ci,nombre,email,tlf) #nuevo cliente
        self.Destroy()
        dlg = wx.MessageDialog(self,"El cliente ha sido guardo éxitosamente", "Notificación",wx.CLOSE_BOX)
        dlg.ShowModal()

    def nuevo_cliente(self, ci, per):
        self.text_ctrl_ci.SetValue(str(ci))
        self.choice_ci.SetSelection(per)
        self.Show()
# end of class Dialog_client
