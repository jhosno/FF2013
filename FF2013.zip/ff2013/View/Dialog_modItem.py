#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import wx, os
import Controller.ctrl_item as citem
import Model.model_validar as validar
# begin wxGlade: dependencies
# end wxGlade

# begin wxGlade: extracode
# end wxGlade


class Dialog_modItem(wx.Dialog):
	def __init__(self, res , *args, **kwds):
		# begin wxGlade: Dialog_modItem.__init__
		kwds["style"] = wx.DEFAULT_DIALOG_STYLE
		wx.Dialog.__init__(self, None, **kwds)
		self.label_ttl = wx.StaticText(self, wx.ID_ANY, _(u"Modificar \xcdtem"))
		self.static_line_13 = wx.StaticLine(self, wx.ID_ANY)
		self.label_72 = wx.StaticText(self, wx.ID_ANY, _("Marca: "))
		self.text_ctrl_52 = wx.TextCtrl(self, wx.ID_ANY, res [1], style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB)
		self.label_73 = wx.StaticText(self, wx.ID_ANY, _("Modelo: "))
		self.text_ctrl_51 = wx.TextCtrl(self, wx.ID_ANY, res[2], style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB)
		self.label_74 = wx.StaticText(self, wx.ID_ANY, _(u"Descripci\xf3n: "))
		self.text_ctrl_50 = wx.TextCtrl(self, wx.ID_ANY, res[3], style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB)
		self.label_75 = wx.StaticText(self, wx.ID_ANY, _("Precio Unitario: "))
		self.text_ctrl_49 = wx.TextCtrl(self, wx.ID_ANY, res[4], style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB)
		self.label_76 = wx.StaticText(self, wx.ID_ANY, _("Existencia: "))
		self.text_ctrl_53 = wx.TextCtrl(self, wx.ID_ANY, res[5], style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB)

		self.text_ctrl_56 = wx.TextCtrl(self, wx.ID_ANY, res[0])
		button_15 = os.path.abspath('../View/img/icons/trashcan_full_big.png')
		button_16 = os.path.abspath('../View/img/icons/save_big.png')
		button_17 = os.path.abspath('../View/img/icons/Valid_big.png')
		self.bitmap_button_15 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_15, wx.BITMAP_TYPE_ANY))
		self.bitmap_button_16 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_16, wx.BITMAP_TYPE_ANY))
		self.bitmap_button_17 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_17, wx.BITMAP_TYPE_ANY))

		self.__set_properties()
		self.__do_layout()

		self.Bind(wx.EVT_BUTTON, self.onDelete, self.bitmap_button_15)
		self.Bind(wx.EVT_BUTTON, self.onSave, self.bitmap_button_16)
		self.Bind(wx.EVT_BUTTON, self.onAcept, self.bitmap_button_17)
		# end wxGlade

	def __set_properties(self):
		# begin wxGlade: Dialog_modItem.__set_properties
		self.SetTitle(_(u"Modificar \xcdtem"))
		favicon = os.path.abspath('../View/img/logotipo_tini.png')
		_icon = wx.EmptyIcon()
		_icon.CopyFromBitmap(wx.Bitmap(favicon, wx.BITMAP_TYPE_ANY))
		self.SetIcon(_icon)
		self.label_ttl.SetMinSize((111, 21))
		self.label_ttl.SetFont(wx.Font(10, wx.DEFAULT, wx.ITALIC, wx.NORMAL, 0, ""))
		self.static_line_13.SetMinSize((240, 15))
		self.text_ctrl_52.SetMinSize((120, 27))
		self.text_ctrl_52.SetFocus()
		self.text_ctrl_51.SetMinSize((120, 27))
		self.text_ctrl_50.SetMinSize((180, 27))
		self.text_ctrl_49.SetMinSize((100, 27))
		self.text_ctrl_53.SetMinSize((80, 27))

		self.text_ctrl_56.Enable(False)
		self.text_ctrl_56.Hide()
		self.bitmap_button_15.SetMinSize((42, 44))
		self.bitmap_button_15.SetToolTipString(_("Eliminar"))
		self.bitmap_button_16.SetMinSize((40, 42))
		self.bitmap_button_16.SetToolTipString(_("Guardar"))
		self.bitmap_button_17.SetToolTipString(_("Aceptar"))
		self.bitmap_button_17.SetSize(self.bitmap_button_17.GetBestSize())
		# end wxGlade

	def __do_layout(self):
		# begin wxGlade: Dialog_modItem.__do_layout
		grid_sizer_50 = wx.FlexGridSizer(5, 1, 0, 0)
		grid_sizer_54 = wx.FlexGridSizer(2, 3, 0, 0)
		grid_sizer_53 = wx.FlexGridSizer(8, 3, 0, 0)
		grid_sizer_50.Add(self.label_ttl, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
		grid_sizer_50.Add(self.static_line_13, 0, wx.EXPAND, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)
		grid_sizer_53.Add(self.label_72, 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_53.Add(self.text_ctrl_52, 0, 0, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)
		grid_sizer_53.Add(self.label_73, 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_53.Add(self.text_ctrl_51, 0, 0, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)
		grid_sizer_53.Add(self.label_74, 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_53.Add(self.text_ctrl_50, 0, 0, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)
		grid_sizer_53.Add(self.label_75, 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_53.Add(self.text_ctrl_49, 0, 0, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)
		grid_sizer_53.Add(self.label_76, 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_53.Add(self.text_ctrl_53, 0, 0, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)

		grid_sizer_53.Add((20, 20), 0, 0, 0)

		grid_sizer_53.Add(self.text_ctrl_56, 0, 0, 0)
		grid_sizer_50.Add(grid_sizer_53, 1, wx.EXPAND, 0)
		grid_sizer_50.Add((20, 20), 0, 0, 0)
		grid_sizer_54.Add(self.bitmap_button_15, 0, 0, 0)
		grid_sizer_54.Add(self.bitmap_button_16, 0, 0, 0)
		grid_sizer_54.Add(self.bitmap_button_17, 0, 0, 0)
		grid_sizer_54.Add((20, 20), 0, 0, 0)
		grid_sizer_50.Add(grid_sizer_54, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
		self.SetSizer(grid_sizer_50)
		grid_sizer_50.Fit(self)
		self.Layout()
		# end wxGlade

	def onDelete(self, event):  # wxGlade: Dialog_modItem.<event_handler>
		dlg = wx.MessageDialog(self,"¿Realmente quiere eliminar este item?", "Advertencia",wx.YES_NO | wx.ICON_QUESTION)
		res = dlg.ShowModal() == wx.ID_YES
		if res == True:
			iditem = self.text_ctrl_56.GetValue()
			delete = citem.Ctrl_item()
			delete.eliminar_item(iditem)
			dlg = wx.MessageDialog(self,"El item ha sido eliminado", "Notificación",wx.OK | wx.ICON_INFORMATION)
			dlg.ShowModal()
		self.Destroy()

	def onSave(self, event):  # wxGlade: Dialog_modItem.<event_handler>
		val = validar.Validacion()
		descripcion = val.vacio(self.text_ctrl_50.GetValue(), "Descripcion")
		marca =val.vacio(self.text_ctrl_52.GetValue(), "Marca")
		modelo = val.vacio(self.text_ctrl_51.GetValue(), "Modelo")
		p_unit = val.vacio(self.text_ctrl_49.GetValue(), "Precio Unitario")

		existencia = val.numerico(self.text_ctrl_53.GetValue(), "Existencia")
		iditem = self.text_ctrl_56.GetValue()
		con = citem.Ctrl_item()
		con.actualizar_item(descripcion, marca, modelo, p_unit, existencia, iditem )
		self.Destroy()
		dlg = wx.MessageDialog(self,"El ítem ha sido guardo éxitosamente", "Notificación",wx.CLOSE_BOX)
		dlg.ShowModal()

	def onAcept(self, event):  # wxGlade: Dialog_modItem.<event_handler>
		self.Destroy()
		event.Skip()

	def mod_item(self, res ):
		self.text_ctrl_56.SetValue(str(res[0]))
		self.text_ctrl_52.SetValue(res[1])
		self.text_ctrl_51.SetValue(res[2])
		self.text_ctrl_50.SetValue(res[3])
		self.text_ctrl_49.SetValue(str(res[4]))
		self.text_ctrl_53.SetValue(str(res[5]))
		self.text_ctrl_54.SetValue(str(res[6]))
		self.text_ctrl_55.SetValue(str(res[7]))
		self.Show()


# end of class Dialog_modItem
