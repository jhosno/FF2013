#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'


import wx, os
import wx.grid
import Controller.ctrl_fact as cFact
import Model.model_validar as validar
import Controller.ctrl_pdf as pdf
# end wxGlade

# begin wxGlade: extracode
# end wxGlade


class Dialog_Fact(wx.Dialog):
	def __init__(self, *args, **kwds):
		# begin wxGlade: Dialog_Fact.__init__
		kwds["style"] = wx.DEFAULT_DIALOG_STYLE
		wx.Dialog.__init__(self, None, **kwds)
		self.fila = 0
		self.sub =0
		self.label_6 = wx.StaticText(self, wx.ID_ANY, _("Factura"))
		self.static_line_2 = wx.StaticLine(self, wx.ID_ANY)
		self.label_53 = wx.StaticText(self, wx.ID_ANY, _("N. Factura: "))
		self.text_ctrl_23 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_READONLY)
		self.label_50 = wx.StaticText(self, wx.ID_ANY, _("Fecha:"))
		self.text_ctrl_21 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_READONLY)
		self.label_51 = wx.StaticText(self, wx.ID_ANY, _("Estado: "))
		self.text_ctrl_22 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_READONLY)
		self.static_line_3 = wx.StaticLine(self, wx.ID_ANY)
		self.label_52 = wx.StaticText(self, wx.ID_ANY, _("Cliente"))
		self.label_54 = wx.StaticText(self, wx.ID_ANY, _(u"C\xe9dula: "))
		self.text_ctrl_30 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_READONLY)
		self.label_55 = wx.StaticText(self, wx.ID_ANY, _("Nombre: "))
		self.text_ctrl_33 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_READONLY)
		self.label_56 = wx.StaticText(self, wx.ID_ANY, _(u"T\xe9lefono: "))
		self.text_ctrl_34 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_READONLY)
		self.static_line_4 = wx.StaticLine(self, wx.ID_ANY)
		self.static_line_5 = wx.StaticLine(self, wx.ID_ANY)
		self.grid_2 = wx.grid.Grid(self, wx.ID_ANY, size=(1, 1))
		self.label_38 = wx.StaticText(self, wx.ID_ANY, _("Sub - Total: "))
		self.text_ctrl_7 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_RIGHT)
		self.label_47 = wx.StaticText(self, wx.ID_ANY, _("I.V.A. "))
		self.text_valoriva = wx.TextCtrl(self, wx.ID_ANY, "",style=wx.TE_READONLY| wx.TE_RIGHT)
		self.text_valoriva.Enable(False)
		self.text_ctrl_18 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_RIGHT)
		self.label_48 = wx.StaticText(self, wx.ID_ANY, _("Total: "))
		self.text_ctrl_19 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_RIGHT)
		self.static_line_6 = wx.StaticLine(self, wx.ID_ANY)
		button_print = os.path.abspath('../View/img/icons/print_small.png')
		button_close = os.path.abspath('../View/img/icons/window-close_small.png')
		self.bitmap_button_F_print = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_print, wx.BITMAP_TYPE_ANY))
		self.bitmap_button_F_close = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_close, wx.BITMAP_TYPE_ANY))
		#self.button_5 = wx.Button(self, wx.ID_ANY, _("Cerrar"))

		self.__set_properties()
		self.__do_layout()

		self.Bind(wx.grid.EVT_GRID_CMD_CELL_LEFT_DCLICK, self.onFactDeleteItem, self.grid_2)
		self.Bind(wx.EVT_BUTTON, self.onPrintFact, self.bitmap_button_F_print)
		self.Bind(wx.EVT_BUTTON, self.onCerrarFact, self.bitmap_button_F_close)
		# end wxGlade

	def __set_properties(self):
		# begin wxGlade: Dialog_Fact.__set_properties
		self.SetTitle(_("Factura"))
		favicon = os.path.abspath('../View/img/logotipo_tini.png')
		_icon = wx.EmptyIcon()
		_icon.CopyFromBitmap(wx.Bitmap(favicon, wx.BITMAP_TYPE_ANY))
		self.SetIcon(_icon)
		self.SetSize((610, 651))
		self.label_6.SetMinSize((118, 30))
		self.label_6.SetFont(wx.Font(11, wx.DEFAULT, wx.ITALIC, wx.BOLD, 0, ""))
		self.static_line_2.SetMinSize((700, 10))
		self.static_line_3.SetMinSize((700, 10))
		self.label_52.SetMinSize((55, 21))
		self.label_52.SetFont(wx.Font(10, wx.DEFAULT, wx.ITALIC, wx.NORMAL, 0, ""))
		self.text_ctrl_33.SetMinSize((180, 27))
		self.text_valoriva.SetMinSize((50, 27))
		self.static_line_4.SetMinSize((700, 10))
		self.static_line_5.SetMinSize((118, 5))
		self.grid_2.CreateGrid(20, 5)
		self.grid_2.SetRowLabelSize(20)
		self.grid_2.EnableEditing(0)
		self.grid_2.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
		self.grid_2.SetColLabelValue(0, _(u"C\xf3digo"))
		self.grid_2.SetColSize(0, 70)
		self.grid_2.SetColLabelValue(1, _(u"Descripci\xf3n"))
		self.grid_2.SetColSize(1, 200)
		self.grid_2.SetColLabelValue(2, _("Cantidad"))
		self.grid_2.SetColSize(2, 80)
		self.grid_2.SetColLabelValue(3, _("Precio Unitario"))
		self.grid_2.SetColSize(3, 120)
		self.grid_2.SetColLabelValue(4, _("Monto"))
		self.grid_2.SetColSize(4, 80)
		self.grid_2.SetMinSize((600,230))
		self.bitmap_button_F_print.SetToolTipString(_("Imprimir "))
		self.bitmap_button_F_print.SetSize(self.bitmap_button_F_print.GetBestSize())
		self.static_line_6.SetMinSize((700, 10))
		self.bitmap_button_F_close.SetToolTipString(_("Cancelar y cerrar"))
		self.bitmap_button_F_print.SetSize(self.bitmap_button_F_close.GetBestSize())
		# end wxGlade

	def __do_layout(self):
		# begin wxGlade: Dialog_Fact.__do_layout
		grid_sizer_16 = wx.FlexGridSizer(17, 1, 0, 0)
		grid_sizer_23 = wx.FlexGridSizer(3, 3, 0, 0)
		grid_sizer_24 = wx.FlexGridSizer(1, 2, 0, 0)
		grid_sizer_32 = wx.FlexGridSizer(1, 3, 0, 0)
		grid_sizer_31 = wx.FlexGridSizer(1, 3, 0, 0)
		grid_sizer_30 = wx.FlexGridSizer(1, 3, 0, 0)
		grid_sizer_27 = wx.FlexGridSizer(1, 3, 0, 0)
		grid_sizer_26 = wx.FlexGridSizer(1, 3, 0, 0)
		grid_sizer_33 = wx.FlexGridSizer(1, 3, 0, 0)
		grid_sizer_16.Add(self.label_6, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_16.Add(self.static_line_2, 0, wx.EXPAND, 0)
		grid_sizer_33.Add(self.label_53, 0, 0, 0)
		grid_sizer_33.Add(self.text_ctrl_23, 0, 0, 0)
		grid_sizer_33.Add((20, 20), 0, 0, 0)
		grid_sizer_16.Add(grid_sizer_33, 1, wx.ALIGN_RIGHT, 0)
		grid_sizer_26.Add(self.label_50, 0, 0, 0)
		grid_sizer_26.Add(self.text_ctrl_21, 0, 0, 0)
		grid_sizer_26.Add((20, 20), 0, 0, 0)
		grid_sizer_16.Add(grid_sizer_26, 1, wx.ALIGN_RIGHT, 0)
		grid_sizer_27.Add(self.label_51, 0, 0, 0)
		grid_sizer_27.Add(self.text_ctrl_22, 0, 0, 0)
		grid_sizer_27.Add((20, 20), 0, 0, 0)
		grid_sizer_16.Add(grid_sizer_27, 1, wx.ALIGN_RIGHT, 0)
		grid_sizer_16.Add(self.static_line_3, 0, wx.EXPAND, 0)
		grid_sizer_16.Add(self.label_52, 0, 0, 0)
		grid_sizer_30.Add((20, 20), 0, 0, 0)
		grid_sizer_30.Add(self.label_54, 0, 0, 0)
		grid_sizer_30.Add(self.text_ctrl_30, 0, 0, 0)
		grid_sizer_16.Add(grid_sizer_30, 1, wx.EXPAND, 0)
		grid_sizer_31.Add((20, 20), 0, 0, 0)
		grid_sizer_31.Add(self.label_55, 0, 0, 0)
		grid_sizer_31.Add(self.text_ctrl_33, 0, 0, 0)
		grid_sizer_16.Add(grid_sizer_31, 1, wx.EXPAND, 0)
		grid_sizer_32.Add((20, 20), 0, 0, 0)
		grid_sizer_32.Add(self.label_56, 0, 0, 0)
		grid_sizer_32.Add(self.text_ctrl_34, 0, 0, 0)
		grid_sizer_16.Add(grid_sizer_32, 1, wx.EXPAND, 0)
		grid_sizer_16.Add(self.static_line_4, 0, wx.EXPAND, 0)
		grid_sizer_16.Add(self.static_line_5, 0, wx.EXPAND, 0)
		grid_sizer_16.Add(self.grid_2, 1, wx.EXPAND, 0)
		grid_sizer_23.Add(self.label_38, 0, wx.ALIGN_RIGHT, 0)
		grid_sizer_23.Add(self.text_ctrl_7, 0, 0, 0)
		grid_sizer_23.Add((20, 20), 0, 0, 0)
		grid_sizer_24.Add(self.label_47, 0, wx.ALIGN_RIGHT, 0)
		grid_sizer_24.Add(self.text_valoriva, 0, 0, 0)
		grid_sizer_23.Add(grid_sizer_24, 1, wx.EXPAND, 0)
		grid_sizer_23.Add(self.text_ctrl_18, 0, 0, 0)
		grid_sizer_23.Add((20, 20), 0, 0, 0)
		grid_sizer_23.Add(self.label_48, 0, wx.ALIGN_RIGHT, 0)
		grid_sizer_23.Add(self.text_ctrl_19, 0, 0, 0)
		grid_sizer_23.Add((20, 20), 0, 0, 0)
		grid_sizer_16.Add(grid_sizer_23, 1, wx.ALIGN_RIGHT, 0)
		grid_sizer_16.Add(self.static_line_6, 0, wx.EXPAND, 0)
		grid_sizer_16.Add(self.bitmap_button_F_print, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_16.Add(self.bitmap_button_F_close, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
		self.SetSizer(grid_sizer_16)
		self.Layout()
		# end wxGlade

	def onFactDeleteItem(self, event):  # wxGlade: Dialog_Fact.<event_handler>
		print "Event handler 'onFactDeleteItem' not implemented!"
		event.Skip()

	def onPrintFact(self, event):  # wxGlade: Dialog_Fact.<event_handler>
		tpl= []

		for fil in range(self.fila):
			row = []
			for cel in range(5):
				algo = self.grid_2.GetCellValue(fil, cel)
				row.append(algo)
			tpl.append(row)
		ttal = self.text_ctrl_19.GetValue()
		sub = self.text_ctrl_7.GetValue()
		iva = self.text_ctrl_18.GetValue()
		veriva = self.text_valoriva.GetValue()
		factid = self.text_ctrl_23.GetValue()
		fact = pdf.PDF()
		fact.print_fact(factid,tpl,sub, iva, veriva, ttal)
		self.Destroy()

	def onCerrarFact(self, event):  # wxGlade: Dialog_Fact.<event_handler>
		self.Destroy()
		event.Skip()

	def showFact(self, idfact):
		val = validar.Validacion()
		fact = cFact.Ctrl_Fact()
		cli = fact.showFact1(idfact)
		fact2 = cFact.Ctrl_Fact()
		item = fact2.showFact2(idfact)
		if cli == "None" or item == "None":
			dlg = wx.MessageDialog(self, u"Este factura no existe, intente de nuevo", "Notificación", wx.OK)
			dlg.ShowModal()
			dlg.Destroy()
			self.Destroy()
		else:
			iva = int(cli[6])
			self.text_ctrl_23.SetValue(str(cli[0]))
			self.text_ctrl_21.SetValue(str(cli[1]))
			self.text_ctrl_22.SetValue(str(cli[2]))
			self.text_ctrl_33.SetValue(str(cli[3]))
			self.text_ctrl_30.SetValue(str(cli[4]))
			self.text_ctrl_34.SetValue(str(cli[5]))
			siva= "(" + str(iva) + "%): "
			self.text_valoriva.SetValue(siva)
			self.fila = len(item)
			for row in range(self.fila):
				for cel in range(5):
					self.grid_2.SetCellValue(row, cel, str(item[row][cel]))
					if item[row][cel] == item[row][3] or item[row][cel] == item[row][4]:
						new = val.monetario(float(item[row][cel]))
						self.grid_2.SetCellValue(row, cel, str(new))
					if item[row][cel] == item[row][4]:
						self.sub = self.sub + float(item[row][4])
						self.text_ctrl_7.SetValue(str(val.monetario(self.sub)))

			trans = float(iva)/100
			base = self.sub * trans
			total = self.sub + base
			self.text_ctrl_18.SetValue(str(val.monetario(base)))
			self.text_ctrl_19.SetValue(str(val.monetario(total)))
			self.Show()