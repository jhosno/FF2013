#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import wx
import Controller.ctrl_login as login
import os

# begin wxGlade: dependencies
# end wxGlade

# begin wxGlade: extracode
# end wxGlade


class Dialog_Login(wx.Dialog):
	def __init__(self, *args, **kwds):
		# begin wxGlade: Dialog_Login.__init__
		kwds["style"] = wx.DEFAULT_DIALOG_STYLE

		wx.Dialog.__init__(self, None, **kwds)
		self.userid  = 0
		self.label_59 = wx.StaticText(self, wx.ID_ANY, _(u"Inicio de Sesi\xf3n"))
		self.static_line_8 = wx.StaticLine(self, wx.ID_ANY)
		self.label_60 = wx.StaticText(self, wx.ID_ANY, _("Usuario: "))
		self.text_ctrl_36 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB)
		self.label_61 = wx.StaticText(self, wx.ID_ANY, _("Clave: "))
		self.text_ctrl_37 = wx.TextCtrl(self, wx.ID_ANY, "", style=wx.TE_PROCESS_ENTER | wx.TE_PROCESS_TAB | wx.TE_PASSWORD)
		button_8 = os.path.abspath('../View/img/icons/close_circle_big.png')
		button_9 = os.path.abspath('../View/img/icons/Valid_big.png')
		self.bitmap_button_8 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_8, wx.BITMAP_TYPE_ANY))
		self.bitmap_button_9 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_9, wx.BITMAP_TYPE_ANY))

		self.__set_properties()
		self.__do_layout()

		self.Bind(wx.EVT_BUTTON, self.onSalir, self.bitmap_button_8)
		self.Bind(wx.EVT_BUTTON, self.onEntrar, self.bitmap_button_9)
		# end wxGlade

	def __set_properties(self):
		# begin wxGlade: Dialog_Login.__set_properties
		self.SetTitle(_("Entrar"))
		favicon = os.path.abspath('../View/img/logotipo_tini.png')
		_icon = wx.EmptyIcon()
		_icon.CopyFromBitmap(wx.Bitmap(favicon, wx.BITMAP_TYPE_ANY))
		self.SetIcon(_icon)
		self.SetSize((250, 176))
		self.label_59.SetMinSize((130, 18))
		self.label_59.SetFont(wx.Font(11, wx.DEFAULT, wx.ITALIC, wx.BOLD, 0, ""))
		self.static_line_8.SetMinSize((250, 10))
		self.text_ctrl_36.SetMinSize((100, 27))
		self.text_ctrl_36.SetFocus()
		self.text_ctrl_37.SetMinSize((100, 27))
		self.bitmap_button_8.SetToolTipString(_("Salir"))
		self.bitmap_button_8.SetSize(self.bitmap_button_8.GetBestSize())
		self.bitmap_button_9.SetToolTipString(_("Entrar"))
		self.bitmap_button_9.SetSize(self.bitmap_button_9.GetBestSize())
		# end wxGlade

	def __do_layout(self):
		# begin wxGlade: Dialog_Login.__do_layout
		grid_sizer_37 = wx.FlexGridSizer(4, 1, 0, 0)
		grid_sizer_39 = wx.FlexGridSizer(2, 2, 0, 0)
		grid_sizer_38 = wx.FlexGridSizer(2, 2, 0, 0)
		grid_sizer_37.Add(self.label_59, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_37.Add(self.static_line_8, 0, wx.EXPAND, 0)
		grid_sizer_38.Add(self.label_60, 0, 0, 0)
		grid_sizer_38.Add(self.text_ctrl_36, 0, 0, 0)
		grid_sizer_38.Add(self.label_61, 0, 0, 0)
		grid_sizer_38.Add(self.text_ctrl_37, 0, 0, 0)
		grid_sizer_37.Add(grid_sizer_38, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
		grid_sizer_39.Add((20, 20), 0, 0, 0)
		grid_sizer_39.Add((20, 20), 0, 0, 0)
		grid_sizer_39.Add(self.bitmap_button_8, 0, 0, 0)
		grid_sizer_39.Add(self.bitmap_button_9, 0, 0, 0)
		grid_sizer_37.Add(grid_sizer_39, 1, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
		self.SetSizer(grid_sizer_37)
		self.Layout()
		# end wxGlade

	def onSalir(self, event):  # wxGlade: Dialog_Login.<event_handler>
		dlg = wx.MessageDialog(self,
		"¿Realmente quiere cerrar la Aplicación?",
 		"Confirmar Sálida", wx.OK|wx.CANCEL|wx.ICON_QUESTION)
		result = dlg.ShowModal()
		dlg.Destroy()
		if result == wx.ID_OK:
			event.Destroy()

	def onEntrar(self, event):  # wxGlade: Dialog_Login.<event_handler>
		entrar = login.Inicio()
		pwd = self.text_ctrl_37.GetValue()
		user = self.text_ctrl_36.GetValue()
		res = entrar.validacion(user, pwd)
		if res == None:
			dlg = wx.MessageDialog(self,
			"La contraseña y el usuario no coinciden",
			"Atención", wx.OK|wx.ICON_EXCLAMATION)
			dlg.ShowModal()
			self.text_ctrl_37.Clear()

		else:
			self.Close()
			self.userid = res[0]



#		return iduser

# end of class Dialog_Login
