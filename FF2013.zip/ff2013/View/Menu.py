#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import Dialog_client as Dcli
import Dialog_Login as login
import Dialog_modClient as modcli
import Dialog_modItem as moditem
import Dialog_item as Ditem
import Dialog_iva as Diva
import Dialog_ajuste as Dajust
import Dialog_search_client as DsClie
import Dialog_search_fact as DsFact
import Dialog_search_item as DsItem
import Dialog_user as duser
import Controller.ctrl_menu as cmenu
import Controller.ctrl_fact as cFact
import Controller.ctrl_historial as chist
import Controller.ctrl_item as citem
import Controller.ctrl_pdf as cPdf
import Controller.ctrl_cliente as ccli
import Controller.ctrl_user as user
import Model.model_validar as validar
import wx, os, sys
import time
import locale,sys, cStringIO
import wx.grid
# end wxGlade

# begin wxGlade: extracode
# end wxGlade


class Menu(wx.Frame):
    def __init__(self, *args, **kwds):
        # begin wxGlade: Menu.__init__
        kwds["style"] = wx.DEFAULT_FRAME_STYLE
        wx.Frame.__init__(self, *args, size=(750,700))
        dlg = login.Dialog_Login()
        #dlg.Show()
        menu = cmenu.MainPanel(self)
        self.Center()
        self.coord = ()
        self.fila = 0
        self.iva = 0
        self.sub =0
        self.req =0
        self.rep =0
        self.inv =0

        # Menu Bar
        self.Menu_menubar = wx.MenuBar()
        self.fact = wx.Menu()###################################'&Quit\tCtrl+Q'
        self.f_addFact = wx.MenuItem(self.fact, wx.ID_ANY, _("Nueva &Factura\tCtrl+F "), _(u"Emitir una nueva facturaci\xf3n"), wx.ITEM_NORMAL)
        self.f_addFact.SetBitmap(wx.Bitmap(menu.menu_fact, wx.BITMAP_TYPE_ANY))
        self.fact.AppendItem(self.f_addFact)
        self.f_report = wx.MenuItem(self.fact, wx.ID_ANY, _("Reporte &Mensual\tCtrl+M "), _(u"Reporte de facturaci\xf3n mensual"), wx.ITEM_NORMAL)
        self.f_report.SetBitmap(wx.Bitmap(menu.menu_report, wx.BITMAP_TYPE_ANY))
        self.fact.AppendItem(self.f_report)
        self.f_searchFact = wx.MenuItem(self.fact, wx.ID_ANY, _(u"B\xfascar Factura "), _("Busqueda de factura"), wx.ITEM_NORMAL)
        self.f_searchFact.SetBitmap(wx.Bitmap(menu.menu_searh, wx.BITMAP_TYPE_ANY))
        self.fact.AppendItem(self.f_searchFact)
        self.fact.AppendSeparator()
        self.f_iva = wx.MenuItem(self.fact, wx.ID_ANY, _("I.V.&A.\tCtrl+A "), _("Actualizar valor del IVA"), wx.ITEM_NORMAL)
        self.f_iva.SetBitmap(wx.Bitmap(menu.menu_iva, wx.BITMAP_TYPE_ANY))
        self.fact.AppendItem(self.f_iva)
        self.Menu_menubar.Append(self.fact, _("Factura"))
        self.al = wx.Menu()
        self.al_invent = wx.MenuItem(self.al, wx.ID_ANY, _("&Inventario\tCtrl+I "), _("Inventario de productos "), wx.ITEM_NORMAL)
        self.al_invent.SetBitmap(wx.Bitmap(menu.menu_invent, wx.BITMAP_TYPE_ANY))
        self.al.AppendItem(self.al_invent)
        self.al_requis = wx.MenuItem(self.al, wx.ID_ANY, _(u"Productos por &debajo del m\xednimo\tCtrl+D "), _(u"Muestra todos los productos que han alcanzado la existencia m\xednima"), wx.ITEM_NORMAL)
        self.al_requis.SetBitmap(wx.Bitmap(menu.menu_requis, wx.BITMAP_TYPE_ANY))
        self.al.AppendItem(self.al_requis)
        self.al.AppendSeparator()
        self.al_additem = wx.MenuItem(self.al, wx.ID_ANY, _("Nuevo &producto\tCtrl+P "), _("Formulario para agregar un nuevo producto"), wx.ITEM_NORMAL)
        self.al_additem.SetBitmap(wx.Bitmap(menu.menu_add_item, wx.BITMAP_TYPE_ANY))
        self.al.AppendItem(self.al_additem)
        # self.al_searchItem = wx.MenuItem(self.al, wx.ID_ANY, _(u"B\xfascar Producto"), _(u"Filtro de b\xfasqueda de uno o varios productos "), wx.ITEM_NORMAL)
        # self.al_searchItem.SetBitmap(wx.Bitmap(menu.menu_searh, wx.BITMAP_TYPE_ANY))
        # self.al.AppendItem(self.al_searchItem)
        self.Menu_menubar.Append(self.al, _(u"Almac\xe9n "))
        self.client = wx.Menu()
        self.cliente_list = wx.MenuItem(self.client, wx.ID_ANY, _("Clien&tes\tCtrl+T "), _("Muesta todos los clientes"), wx.ITEM_NORMAL)
        self.cliente_list.SetBitmap(wx.Bitmap(menu.menu_client, wx.BITMAP_TYPE_ANY))
        self.client.AppendItem(self.cliente_list)
        # self.cliente_search = wx.MenuItem(self.client, wx.ID_ANY, _(u"B\xfascar Clientes "), _("Filtro de Busquedas de Clientes "), wx.ITEM_NORMAL)
        # self.cliente_search.SetBitmap(wx.Bitmap(menu.menu_searh, wx.BITMAP_TYPE_ANY))
        # self.client.AppendItem(self.cliente_search)
        self.cliente_add = wx.MenuItem(self.client, wx.ID_ANY, _("Nuevo Cliente "), _(u"F\xf3rmulario para agregar un nuevo cliente "), wx.ITEM_NORMAL)
        self.cliente_add.SetBitmap(wx.Bitmap(menu.menu_add_client, wx.BITMAP_TYPE_ANY))
        self.client.AppendItem(self.cliente_add)
        self.Menu_menubar.Append(self.client, _("Cliente"))
        self.user = wx.Menu()
        self.user_perfil = wx.MenuItem(self.user, wx.ID_ANY, _("Perfil\tCtrl+L "), _("Muestra el perfil de Usuario Actual"), wx.ITEM_NORMAL)
        self.user_perfil.SetBitmap(wx.Bitmap(menu.menu_perfil, wx.BITMAP_TYPE_ANY))
        self.user.AppendItem(self.user_perfil)
        self.user_close = wx.MenuItem(self.user, wx.ID_ANY, _(u"Cerrar &Sesi\xf3n\tCtrl+S "), _(u"Cerrar la sesi\xf3n actual"), wx.ITEM_NORMAL)
        self.user_close.SetBitmap(wx.Bitmap(menu.menu_logout, wx.BITMAP_TYPE_ANY))
        self.user.AppendItem(self.user_close)
        self.user.AppendSeparator()
        self.user_exit = wx.MenuItem(self.user, wx.ID_ANY, _("Salir\tCtrl+Q "), _("Salir del sistema "), wx.ITEM_NORMAL)
        self.user_exit.SetBitmap(wx.Bitmap(menu.menu_salir, wx.BITMAP_TYPE_ANY))
        self.user.AppendItem(self.user_exit)
        self.Menu_menubar.Append(self.user, _("Usuario"))
        self.Arch = wx.Menu()
        self.arch_hist = wx.MenuItem(self.Arch, wx.ID_ANY, _("&Historial\tCtrl+H  "), _(u"Bit\xe1cora del sistema "), wx.ITEM_NORMAL)
        self.arch_hist.SetBitmap(wx.Bitmap(menu.menu_hist, wx.BITMAP_TYPE_ANY))
        self.Arch.AppendItem(self.arch_hist)
        self.Arch.AppendSeparator()
        self.ar_res = wx.MenuItem(self.Arch, wx.ID_ANY, _("&Exportar DB\tCtrl+E "), _("Realiza una copia de la Base de Datos actual"), wx.ITEM_NORMAL)
        self.ar_res.SetBitmap(wx.Bitmap(menu.menu_export_db, wx.BITMAP_TYPE_ANY))
        self.Arch.AppendItem(self.ar_res)
        self.ar_import = wx.MenuItem(self.Arch, wx.ID_ANY, _("&Importar DB\tCtrl+B "), _("Importa Base de Datos"), wx.ITEM_NORMAL)
        self.ar_import.SetBitmap(wx.Bitmap(menu.menu_import_db, wx.BITMAP_TYPE_ANY))
        self.Arch.AppendItem(self.ar_import)
        self.Menu_menubar.Append(self.Arch, _("Seguridad"))
        self.help = wx.Menu()
        self.help_about = wx.MenuItem(self.help, wx.ID_ANY, _("Acerca de..."), _("Acerca del sistema"), wx.ITEM_NORMAL)
        self.help_about.SetBitmap(wx.Bitmap(menu.menu_about, wx.BITMAP_TYPE_ANY))
        self.help.AppendItem(self.help_about)
        self.help.AppendSeparator()
        self.help_help = wx.MenuItem(self.help, wx.ID_ANY, _("Ayuda\tF11 "), _("Manual de ayuda"), wx.ITEM_NORMAL)
        self.help_help.SetBitmap(wx.Bitmap(menu.menu_help, wx.BITMAP_TYPE_ANY))
        self.help.AppendItem(self.help_help)
        self.Menu_menubar.Append(self.help, _("Ayuda"))
        self.SetMenuBar(self.Menu_menubar)
        # Menu Bar end
        self.Menu_statusbar = self.CreateStatusBar(1, 0)
        self.notebook_1 = wx.Notebook(self, wx.ID_ANY, style=0)
        self.notebook_hist = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_7 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _("Historial"))
        self.label_6 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _(u"Filtro de B\xfasqueda"))
        self.label_8 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _("Mes: "))
        self.combo_box_H_mes = wx.ComboBox(self.notebook_hist, wx.ID_ANY, choices=["", _("Enero"), _("Febrero"), _("Marzo"), _("Abril"), _("Mayo"), _("Junio"), _("Julio"), _("Agosto"), _("Septiembre"), _("Octubre"), _("Noviembre"), _("Diciembre")], style=wx.CB_DROPDOWN)
        self.label_9 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _(u"A\xf1o: "))
        self.spin_ctrl_H_ano = wx.SpinCtrl(self.notebook_hist, wx.ID_ANY, "", min=2015, max=3000)
        self.label_10 = wx.StaticText(self.notebook_hist, wx.ID_ANY, _(u"Categor\xeda: "))
        self.combo_box_H_cat = wx.ComboBox(self.notebook_hist, wx.ID_ANY, choices=[_("Cliente"), _("Factura"), _("Iva"), _("Usuario"), _("Item")], style=wx.CB_DROPDOWN)
        self.bitmap_button_H_search = wx.BitmapButton(self.notebook_hist, wx.ID_ANY, wx.Bitmap(menu.img_searh, wx.BITMAP_TYPE_ANY))
        self.static_line_1 = wx.StaticLine(self.notebook_hist, wx.ID_ANY)
        self.grid_Hist = wx.grid.Grid(self.notebook_hist, wx.ID_ANY, size=(1, 1))
        self.static_line_2 = wx.StaticLine(self.notebook_hist, wx.ID_ANY)
        self.bitmap_button_H_close = wx.BitmapButton(self.notebook_hist, wx.ID_ANY, wx.Bitmap(menu.img_close_small, wx.BITMAP_TYPE_ANY))
        self.notebook_addFact = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_1 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Nueva Factura "))
        self.static_line_3 = wx.StaticLine(self.notebook_addFact, wx.ID_ANY)
        self.label_2 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Cliente"))
        self.label_3 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"C\xe9dula: "))
        self.choice_persona = wx.Choice(self.notebook_addFact, wx.ID_ANY, choices=[_("V- "), _("E- "), _("J- ")])
        self.text_ctrl_AF_ci = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", )
        self.bitmap_button_3 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap(menu.img_add_client, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_9 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap(menu.img_edit_client, wx.BITMAP_TYPE_ANY))
        self.label_4 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Nombre y Apellido: "))
        self.text_ctrl_AF_name = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=  wx.TE_READONLY )
        self.label_5 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"T\xe9lefono: "))
        self.text_ctrl_AF_tlf = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style= wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB|wx.TE_READONLY)
        self.static_line_4 = wx.StaticLine(self.notebook_addFact, wx.ID_ANY)
        self.label_11 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Producto"))
        self.label_12 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"B\xfascar: "))
        ###############################
        ## ¡Que comience el juego! ####
        ###############################

        self.text_ctrl_AF_Sitem = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "")
        self.bitmap_button_4 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap(menu.img_searh, wx.BITMAP_TYPE_ANY))
        self.label_13 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"C\xf2digo de producto: "))
        self.text_ctrl_AF_cod = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.label_15 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Marca: "))
        self.text_ctrl_AF_brand = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.label_14 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _(u"Descripci\xf3n: "))
        self.text_ctrl_AF_descrip = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.label_16 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Modelo: "))
        self.text_ctrl_AF_model = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.label_18 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Existencia: "))
        self.text_ctrl_AF_exist = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.label_17 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Cantidad: "))
        self.choice_cant = wx.SpinCtrl(self.notebook_addFact, wx.ID_ANY, "1", min=1, max=500)
        self.bitmap_button_5 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap(menu.img_add_car, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_12 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap(menu.img_delete_car, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_11 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap(menu.img_edit_car, wx.BITMAP_TYPE_ANY))
        self.static_line_5 = wx.StaticLine(self.notebook_addFact, wx.ID_ANY)
        self.grid_Fact = wx.grid.Grid(self.notebook_addFact, wx.ID_ANY, size=(1, 1))
        self.grid_Fact.EnableEditing(0)
        self.label_19 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Sub-Total: "))
        self.text_ctrl_AF_subt = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY | wx.TE_RIGHT| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.label_20 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("I.V.A. "))
        self.text_ctrl_AF_iva = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY | wx.TE_CENTRE| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.text_ctrl_AF_addiva = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_RIGHT| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.label_21 = wx.StaticText(self.notebook_addFact, wx.ID_ANY, _("Total: "))
        self.text_ctrl_AF_item = wx.TextCtrl(self.notebook_addFact, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_RIGHT| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.static_line_6 = wx.StaticLine(self.notebook_addFact, wx.ID_ANY)
        self.bitmap_button_6 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap(menu.img_print, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_7 = wx.BitmapButton(self.notebook_addFact, wx.ID_ANY, wx.Bitmap(menu.img_close_small, wx.BITMAP_TYPE_ANY))
        self.notebook_invet = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_40 = wx.StaticText(self.notebook_invet, wx.ID_ANY, _("Inventario Valorizado"))
        self.label_6_copy_copy_copy = wx.StaticText(self.notebook_invet, wx.ID_ANY, _(u"Filtro de B\xfasqueda"))
        self.label_22_copy = wx.StaticText(self.notebook_invet, wx.ID_ANY, _(u"Datos del \xedtem: "))
        self.text_ctrl_I_dato = wx.TextCtrl(self.notebook_invet, wx.ID_ANY, "")
        self.bitmap_button_1_copy = wx.BitmapButton(self.notebook_invet, wx.ID_ANY, wx.Bitmap(menu.img_searh, wx.BITMAP_TYPE_ANY))
        self.static_line_9 = wx.StaticLine(self.notebook_invet, wx.ID_ANY)
        self.grid_invent = wx.grid.Grid(self.notebook_invet, wx.ID_ANY, size=(1, 1))
        self.grid_invent.SetRowLabelAlignment(wx.ALIGN_RIGHT, wx.ALIGN_RIGHT)
        self.static_line_10 = wx.StaticLine(self.notebook_invet, wx.ID_ANY)
        self.bitmap_button_61 = wx.BitmapButton(self.notebook_invet, wx.ID_ANY, wx.Bitmap(menu.img_print, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_71 = wx.BitmapButton(self.notebook_invet, wx.ID_ANY, wx.Bitmap(menu.img_close_small, wx.BITMAP_TYPE_ANY))
        self.notebook_requis = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_40_copy = wx.StaticText(self.notebook_requis, wx.ID_ANY, _(u"Productos por debajo del Valor M\xednimo"))
        self.static_line_11 = wx.StaticLine(self.notebook_requis, wx.ID_ANY)
        self.grid_requis = wx.grid.Grid(self.notebook_requis, wx.ID_ANY, size=(1, 1))
        self.static_line_12 = wx.StaticLine(self.notebook_requis, wx.ID_ANY)
        self.bitmap_button_60 = wx.BitmapButton(self.notebook_requis, wx.ID_ANY, wx.Bitmap(menu.img_print, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_8 = wx.BitmapButton(self.notebook_requis, wx.ID_ANY, wx.Bitmap(menu.img_save, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_70 = wx.BitmapButton(self.notebook_requis, wx.ID_ANY, wx.Bitmap(menu.img_close_small, wx.BITMAP_TYPE_ANY))
        self.notebook_report = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_30 = wx.StaticText(self.notebook_report, wx.ID_ANY, _("Reporte Mensual"))
        self.label_6_copy = wx.StaticText(self.notebook_report, wx.ID_ANY, _(u"Filtro de B\xfasqueda"))
        self.label_8_copy = wx.StaticText(self.notebook_report, wx.ID_ANY, _("Mes: "))
        self.combo_box_R_mes = wx.ComboBox(self.notebook_report, wx.ID_ANY, choices=["", _("Enero"), _("Febrero"), _("Marzo"), _("Abril"), _("Mayo"), _("Junio"), _("Julio"), _("Agosto"), _("Septiembre"), _("Octubre"), _("Noviembre"), _("Diciembre")], style=wx.CB_DROPDOWN)
        self.label_9_copy = wx.StaticText(self.notebook_report, wx.ID_ANY, _(u"A\xf1o: "))
        self.spin_ctrl_R_ano = wx.SpinCtrl(self.notebook_report, wx.ID_ANY, "", min=2015, max=3000)
        self.bitmap_button_R_search = wx.BitmapButton(self.notebook_report, wx.ID_ANY, wx.Bitmap(menu.img_searh, wx.BITMAP_TYPE_ANY))
        self.static_line_7 = wx.StaticLine(self.notebook_report, wx.ID_ANY)
        self.grid_report = wx.grid.Grid(self.notebook_report, wx.ID_ANY, size=(1, 1))
        self.label_21_copy = wx.StaticText(self.notebook_report, wx.ID_ANY, _("Total Mensual: "))
        self.text_ctrl_R_total = wx.TextCtrl(self.notebook_report, wx.ID_ANY, "", style=wx.TE_READONLY| wx.TE_RIGHT| wx.TE_PROCESS_ENTER| wx.TE_PROCESS_TAB)
        self.static_line_8 = wx.StaticLine(self.notebook_report, wx.ID_ANY)
        self.bitmap_button_62 = wx.BitmapButton(self.notebook_report, wx.ID_ANY, wx.Bitmap(menu.img_print, wx.BITMAP_TYPE_ANY))
        self.bitmap_button_71_copy = wx.BitmapButton(self.notebook_report, wx.ID_ANY, wx.Bitmap(menu.img_close_small, wx.BITMAP_TYPE_ANY))
        self.notebook_client = wx.Panel(self.notebook_1, wx.ID_ANY)
        self.label_30_copy = wx.StaticText(self.notebook_client, wx.ID_ANY, _("Clientes"))
        self.label_6_copy_copy = wx.StaticText(self.notebook_client, wx.ID_ANY, _(u"Filtro de B\xfasqueda"))
        self.label_22 = wx.StaticText(self.notebook_client, wx.ID_ANY, _("Datos del Cliente: "))
        self.text_ctrl_C_Dato = wx.TextCtrl(self.notebook_client, wx.ID_ANY, "")
        self.bitmap_button_1 = wx.BitmapButton(self.notebook_client, wx.ID_ANY, wx.Bitmap(menu.img_searh, wx.BITMAP_TYPE_ANY))
        self.static_line_13 = wx.StaticLine(self.notebook_client, wx.ID_ANY)
        self.grid_client = wx.grid.Grid(self.notebook_client, wx.ID_ANY, size=(1, 1))
        self.static_line_14 = wx.StaticLine(self.notebook_client, wx.ID_ANY)
        self.bitmap_button_2 = wx.BitmapButton(self.notebook_client, wx.ID_ANY, wx.Bitmap(menu.img_close_small, wx.BITMAP_TYPE_ANY))

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_MENU, self.onAddFact, self.f_addFact)
        self.Bind(wx.EVT_MENU, self.onReport, self.f_report)
        self.Bind(wx.EVT_MENU, self.onSearchFact, self.f_searchFact)
        self.Bind(wx.EVT_MENU, self.onIva, self.f_iva)
        self.Bind(wx.EVT_MENU, self.onInvent, self.al_invent)
        self.Bind(wx.EVT_MENU, self.onRequis, self.al_requis)
        self.Bind(wx.EVT_MENU, self.onAddItem, self.al_additem)
        # self.Bind(wx.EVT_MENU, self.onSearchItem, self.al_searchItem)
        self.Bind(wx.EVT_MENU, self.onClients, self.cliente_list)
        #self.Bind(wx.EVT_MENU, self.onSearchClient, self.cliente_search)
        self.Bind(wx.EVT_MENU, self.onAddClient, self.cliente_add)
        self.Bind(wx.EVT_MENU, self.onPerfil, self.user_perfil)
        self.Bind(wx.EVT_MENU, self.onClose, self.user_close)
        self.Bind(wx.EVT_MENU, self.onExit, self.user_exit)
        self.Bind(wx.EVT_MENU, self.onHist, self.arch_hist)
        self.Bind(wx.EVT_MENU, self.onSaveDB, self.ar_res)
        self.Bind(wx.EVT_MENU, self.onImport, self.ar_import)
        self.Bind(wx.EVT_MENU, self.onAbout, self.help_about)
        self.Bind(wx.EVT_MENU, self.onHelp, self.help_help)
        self.Bind(wx.EVT_BUTTON, self.onHistASearch, self.bitmap_button_H_search)
        self.Bind(wx.EVT_BUTTON, self.onHistClose, self.bitmap_button_H_close)
        self.Bind(wx.EVT_CHOICE, self.onChoicePersona, self.choice_persona)
        self.Bind(wx.EVT_BUTTON, self.onFactCliente, self.bitmap_button_3)
        self.Bind(wx.EVT_BUTTON, self.onModClient, self.bitmap_button_9)
        self.Bind(wx.EVT_BUTTON, self.onFactItem, self.bitmap_button_4)
        self.Bind(wx.EVT_BUTTON, self.onFactAdd, self.bitmap_button_5)
        self.Bind(wx.EVT_BUTTON, self.onModItem, self.bitmap_button_11)
        self.Bind(wx.EVT_BUTTON, self.onDeleteItem, self.bitmap_button_12)
        self.grid_Fact.GetGridWindow().Bind(wx.EVT_LEFT_DOWN, self.onModRow)
        self.grid_client.GetGridWindow().Bind(wx.EVT_LEFT_DOWN, self.onShowClient)
        self.grid_invent.GetGridWindow().Bind(wx.EVT_LEFT_DOWN, self.onModItem)
        self.grid_requis.GetGridWindow().Bind(wx.EVT_LEFT_DOWN, self.onAjust)
        self.Bind(wx.EVT_BUTTON, self.onFactPrint, self.bitmap_button_6)
        self.Bind(wx.EVT_BUTTON, self.onFactClose, self.bitmap_button_7)
        self.Bind(wx.EVT_BUTTON, self.onInventSearch, self.bitmap_button_1_copy)
        self.Bind(wx.grid.EVT_GRID_CMD_CELL_LEFT_DCLICK, self.onModItem, self.grid_invent)
        self.Bind(wx.EVT_BUTTON, self.onInventPrint, self.bitmap_button_61)
        self.Bind(wx.EVT_BUTTON, self.onInventClose, self.bitmap_button_71)
        self.Bind(wx.grid.EVT_GRID_CMD_CELL_LEFT_DCLICK, self.onAjust, self.grid_requis)
        self.Bind(wx.EVT_BUTTON, self.onRequisPrint, self.bitmap_button_60)
        self.Bind(wx.EVT_BUTTON, self.onRequisSave, self.bitmap_button_8)
        self.Bind(wx.EVT_BUTTON, self.onRequisClose, self.bitmap_button_70)
        self.Bind(wx.EVT_BUTTON, self.onReportSearch, self.bitmap_button_R_search)
        self.Bind(wx.grid.EVT_GRID_CMD_CELL_RIGHT_DCLICK, self.onShowFact, self.grid_report)
        self.Bind(wx.EVT_BUTTON, self.onReporPrint, self.bitmap_button_62)
        self.Bind(wx.EVT_BUTTON, self.onReportClose, self.bitmap_button_71_copy)
        self.Bind(wx.EVT_BUTTON, self.onClientSearch, self.bitmap_button_1)

        self.Bind(wx.EVT_BUTTON, self.onClientClose, self.bitmap_button_2)
        self.Bind(wx.EVT_CLOSE, self.onExit)
        # end wxGlade

    def __set_properties(self):
        # begin wxGlade: Menu.__set_properties
        self.SetTitle(_("AUTOMOTRIZ FULL FRIO 2013 C.A."))
        favicon = os.path.abspath('../View/img/logotipo_tini.png')
        _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap(favicon, wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.SetSize((720, 688))
        self.Menu_statusbar.SetStatusWidths([-1])
        # statusbar fields
        Menu_statusbar_fields = ["Recuerda Cerrar las pestañas al finalizar"]
        for i in range(len(Menu_statusbar_fields)):
            self.Menu_statusbar.SetStatusText(Menu_statusbar_fields[i], i)
        self.label_7.SetFont(wx.Font(15, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.label_6.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.combo_box_H_mes.SetMinSize((100, 29))
        self.combo_box_H_mes.SetToolTipString(_("Mes que se desea consultar"))
        self.combo_box_H_mes.SetSelection(0)
        self.spin_ctrl_H_ano.SetMinSize((60, 27))
        self.spin_ctrl_H_ano.SetToolTipString(_(u"A\xf1o que se de sea consultar"))
        self.combo_box_H_cat.SetMinSize((80, 29))
        self.combo_box_H_cat.SetToolTipString(_(u"Categor\xeda a consultar"))
        self.combo_box_H_cat.SetSelection(-1)
        self.bitmap_button_H_search.SetToolTipString(_(u"B\xfascar"))
        self.bitmap_button_H_search.SetSize(self.bitmap_button_H_search.GetBestSize())
        self.static_line_1.SetMinSize((712, 15))
        self.grid_Hist.CreateGrid(1, 3)
        self.grid_Hist.SetRowLabelSize(20)
        self.grid_Hist.EnableEditing(0)
        self.grid_Hist.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.grid_Hist.SetColLabelValue(0, _("Fecha"))
        self.grid_Hist.SetColSize(0, 180)
        self.grid_Hist.SetColLabelValue(1, _(u"Categor\xeda"))
        self.grid_Hist.SetColSize(1, 300)
        self.grid_Hist.SetColLabelValue(2, _("Movimiento"))
        self.grid_Hist.SetColSize(2, 200)
        self.grid_Hist.SetMinSize((712, 450))
        self.static_line_2.SetMinSize((712, 20))
        self.bitmap_button_H_close.SetToolTipString(_("Cerrar Historial "))
        self.bitmap_button_H_close.SetSize(self.bitmap_button_H_close.GetBestSize())
        self.notebook_hist.Hide()
        self.label_1.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.static_line_3.SetMinSize((700, 10))
        self.label_2.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.choice_persona.SetToolTipString(_("Escoja el tipo de persona"))
        self.choice_persona.SetSelection(0)
        self.text_ctrl_AF_ci.SetToolTipString(_("Ingrese la C.I. o el R.I.F. del cliente para iniciar la factura"))
        self.text_ctrl_AF_ci.SetFocus()
        self.bitmap_button_3.SetToolTipString(_("Agregar cliente a la factura"))
        self.bitmap_button_3.SetSize(self.bitmap_button_3.GetBestSize())
        self.bitmap_button_9.SetToolTipString(_("Editar Cliente"))
        self.bitmap_button_9.Hide()
        self.bitmap_button_9.SetSize(self.bitmap_button_9.GetBestSize())
        self.text_ctrl_AF_name.SetMinSize((150, 27))
        self.text_ctrl_AF_name.SetToolTipString(_(u"Nombre o Raz\xf3n del cliente"))
        self.text_ctrl_AF_name.Enable(False)
        self.text_ctrl_AF_tlf.SetMinSize((100, 27))
        self.text_ctrl_AF_tlf.SetToolTipString(_(u"T\xe9lefono de contacto"))
        self.text_ctrl_AF_tlf.Enable(False)
        self.static_line_4.SetMinSize((700, 10))
        self.label_11.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.text_ctrl_AF_Sitem.SetMinSize((100, 27))
        self.text_ctrl_AF_Sitem.SetToolTipString(_(u"Inserte el c\xf3digo o modelo para buscar el \xedtem"))
        self.bitmap_button_4.SetToolTipString(_(u"B\xfascar \xedtem por marca, modelo o descripci\xf3n"))
        self.bitmap_button_4.SetSize(self.bitmap_button_4.GetBestSize())
        self.text_ctrl_AF_cod.SetMinSize((150, 27))
        self.text_ctrl_AF_cod.SetToolTipString(_(u"C\xf3digo del \xedtem"))
        self.text_ctrl_AF_brand.SetMinSize((120, 27))
        self.text_ctrl_AF_brand.SetToolTipString(_(u"Marca del \xedtem"))
        self.text_ctrl_AF_descrip.SetMinSize((150, 27))
        self.text_ctrl_AF_descrip.SetToolTipString(_(u"Descripci\xf3n del \xedtem"))
        self.text_ctrl_AF_model.SetMinSize((120, 27))
        self.text_ctrl_AF_model.SetToolTipString(_(u"Modelo del \xedtem"))
        self.text_ctrl_AF_exist.SetToolTipString(_(u"Existencia del \xedtem en almac\xe9n"))
        self.text_ctrl_AF_exist.Enable(False)
        self.choice_cant.SetToolTipString(_(u"Cantidad de \xedtem a facturar, con límite correspondiente a la existencia "))
        self.bitmap_button_5.SetToolTipString(_("Agregar producto"))
        self.bitmap_button_5.SetSize(self.bitmap_button_5.GetBestSize())
        self.bitmap_button_5.Enable(False)
        self.bitmap_button_11.SetToolTipString(_(u"Editar \xcdtem"))
        self.bitmap_button_11.Enable(False)
        self.bitmap_button_11.SetSize(self.bitmap_button_11.GetBestSize())
        self.bitmap_button_12.SetToolTipString(_(u"Eliminar \xcdtem"))
        self.bitmap_button_12.Enable(False)
        self.bitmap_button_12.SetSize(self.bitmap_button_12.GetBestSize())
        self.grid_Fact.CreateGrid(103, 5)
        self.grid_Fact.SetRowLabelSize(30)
        self.grid_Fact.SetColLabelValue(0, _(u"C\xf3digo"))
        self.grid_Fact.SetColSize(0, 100)
        self.grid_Fact.SetColLabelValue(1, _(u"Descripci\xf3n"))
        self.grid_Fact.SetColSize(1, 230)
        self.grid_Fact.SetColLabelValue(2, _("Cantidad"))
        self.grid_Fact.SetColSize(2, 90)
        self.grid_Fact.SetColLabelValue(3, _("Precio Unitario (Bs.F)"))
        self.grid_Fact.SetColSize(3, 130)
        self.grid_Fact.SetColLabelValue(4, _("Monto (Bs.F)"))
        self.grid_Fact.SetColSize(4, 100)
        self.grid_Fact.SetMinSize((700, 225))
        self.grid_Fact.SetToolTipString(_(u"\xcdtems a facturar"))
        self.text_ctrl_AF_subt.SetMinSize((100, 27))
        self.text_ctrl_AF_subt.SetToolTipString(_("Sub- Total de la Factura "))
        self.text_ctrl_AF_subt.Enable(False)
        self.text_ctrl_AF_iva.Enable(False)
        self.text_ctrl_AF_addiva.SetMinSize((100, 27))
        self.text_ctrl_AF_addiva.SetToolTipString(_("I.V.A. agregado"))
        self.text_ctrl_AF_addiva.Enable(False)
        self.text_ctrl_AF_item.SetMinSize((100, 27))
        self.text_ctrl_AF_item.SetToolTipString(_("Total de la factura"))
        self.text_ctrl_AF_item.Enable(False)
        self.bitmap_button_6.SetToolTipString(_("Guardar e Imprimir"))
        self.bitmap_button_6.SetSize(self.bitmap_button_6.GetBestSize())
        self.bitmap_button_7.SetToolTipString(_("Cancelar Factura"))
        self.bitmap_button_7.SetSize(self.bitmap_button_7.GetBestSize())
        self.notebook_addFact.Hide()
        self.label_40.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.label_6_copy_copy_copy.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.text_ctrl_I_dato.SetMinSize((120, 27))
        self.text_ctrl_I_dato.SetToolTipString(_("Busqueda de cliente por CI, Nombre o Apellido"))
        self.bitmap_button_1_copy.SetSize(self.bitmap_button_1_copy.GetBestSize())
        self.static_line_9.SetMinSize((700, 10))
        self.grid_invent.CreateGrid(100, 7)
        self.grid_invent.SetRowLabelSize(30)
        self.grid_invent.EnableEditing(0)
        self.grid_invent.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.grid_invent.SetColLabelValue(0, _(u"C\xf3digo"))
        self.grid_invent.SetColSize(0, 80)
        self.grid_invent.SetColLabelValue(1, _("Marca"))
        self.grid_invent.SetColSize(1, 100)
        self.grid_invent.SetColLabelValue(2, _("Modelo"))
        self.grid_invent.SetColSize(2, 100)
        self.grid_invent.SetColLabelValue(3, _(u"Descripci\xf3n"))
        self.grid_invent.SetColSize(3, 100)
        self.grid_invent.SetColLabelValue(4, _("Precio Unitario"))
        self.grid_invent.SetColSize(4, 100)
        self.grid_invent.SetColLabelValue(5, _("Existencia"))
        self.grid_invent.SetColSize(5, 80)
        self.grid_invent.SetColLabelValue(6, _("Valor"))
        self.grid_invent.SetColSize(6, 80)
        self.grid_invent.SetMinSize((700, 450))
        self.grid_invent.SetToolTipString(_("Inventario"))
        self.static_line_10.SetMinSize((700, 10))
        self.bitmap_button_61.SetToolTipString(_("Imprimir"))
        self.bitmap_button_61.SetSize(self.bitmap_button_61.GetBestSize())
        self.bitmap_button_71.SetToolTipString(_("Cerrar Reporte Mensual"))
        self.bitmap_button_71.SetSize(self.bitmap_button_71.GetBestSize())
        self.notebook_invet.Hide()
        self.label_40_copy.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.static_line_11.SetMinSize((700,15))
        self.grid_requis.CreateGrid(100, 7)
        self.grid_requis.SetRowLabelSize(30)
        self.grid_requis.EnableEditing(0)
        self.grid_requis.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.grid_requis.SetColLabelValue(0, _(u"C\xf3digo"))
        self.grid_requis.SetColSize(0, 50)
        self.grid_requis.SetColLabelValue(1, _("Marca "))
        self.grid_requis.SetColSize(1, 120)
        self.grid_requis.SetColLabelValue(2, _("Modelo"))
        self.grid_requis.SetColSize(2, 120)
        self.grid_requis.SetColLabelValue(3, _(u"Descripci\xf3n"))
        self.grid_requis.SetColSize(3, 120)
        self.grid_requis.SetColLabelValue(4, _("Existencia "))
        self.grid_requis.SetColSize(4, 70)
        self.grid_requis.SetColLabelValue(5, _(u"Stock M\xe1ximo"))
        self.grid_requis.SetColSize(5, 89)
        self.grid_requis.SetColLabelValue(6, _(u"Stock M\xednimo"))
        self.grid_requis.SetColSize(6, 89)
        self.grid_requis.SetMinSize((700, 500))
        self.grid_requis.SetToolTipString(_(u"Productos por debajo del m\xednimo"))
        self.static_line_12.SetMinSize((700, 15))
        self.bitmap_button_60.SetToolTipString(_("Imprimir"))
        self.bitmap_button_60.SetSize(self.bitmap_button_60.GetBestSize())
        self.bitmap_button_8.SetToolTipString(_(u"Guardar las modificaciones de \xcdtems"))
        self.bitmap_button_8.SetSize(self.bitmap_button_8.GetBestSize())
        self.bitmap_button_70.SetToolTipString(_("Cerrar Reporte Mensual"))
        self.bitmap_button_70.SetSize(self.bitmap_button_70.GetBestSize())
        self.notebook_requis.Hide()
        self.label_30.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.label_6_copy.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.combo_box_R_mes.SetMinSize((100, 29))
        self.combo_box_R_mes.SetToolTipString(_("Mes a consultar"))
        self.combo_box_R_mes.SetSelection(0)
        self.spin_ctrl_R_ano.SetMinSize((60, 27))
        self.spin_ctrl_R_ano.SetToolTipString(_(u"A\xf1o a consultar"))
        self.bitmap_button_R_search.SetToolTipString(_(u"B\xfascar"))
        self.bitmap_button_R_search.SetSize(self.bitmap_button_R_search.GetBestSize())
        self.static_line_7.SetMinSize((700, 10))
        self.grid_report.CreateGrid(100, 5)
        self.grid_report.SetRowLabelSize(30)
        self.grid_report.EnableEditing(0)
        self.grid_report.SetColLabelValue(0, _("Fecha"))
        self.grid_report.SetColSize(0, 130)
        self.grid_report.SetColLabelValue(1, _("Factura"))
        self.grid_report.SetColSize(1, 130)
        self.grid_report.SetColLabelValue(2, _(u"C\xe9dula"))
        self.grid_report.SetColSize(2, 130)
        self.grid_report.SetColLabelValue(3, _("Cliente"))
        self.grid_report.SetColSize(3, 140)
        self.grid_report.SetColLabelValue(4, _("Monto"))
        self.grid_report.SetColSize(4, 130)
        self.grid_report.SetMinSize((700,420))
        self.grid_report.SetToolTipString(_("Reporte mensual"))
        self.text_ctrl_R_total.SetMinSize((100, 27))
        self.static_line_8.SetMinSize((700, 10))
        self.bitmap_button_62.SetToolTipString(_("Imprimir"))
        self.bitmap_button_62.SetSize(self.bitmap_button_62.GetBestSize())
        self.bitmap_button_71_copy.SetToolTipString(_("Cerrar Reporte Mensual"))
        self.bitmap_button_71_copy.SetSize(self.bitmap_button_71_copy.GetBestSize())
        self.notebook_report.Hide()
        self.label_30_copy.SetFont(wx.Font(14, wx.SWISS, wx.ITALIC, wx.BOLD, 0, ""))
        self.label_6_copy_copy.SetFont(wx.Font(11, wx.SWISS, wx.NORMAL, wx.BOLD, 0, ""))
        self.text_ctrl_C_Dato.SetMinSize((120, 27))
        self.text_ctrl_C_Dato.SetToolTipString(_("Busqueda de cliente por CI, Nombre o Apellido"))
        self.bitmap_button_1.SetSize(self.bitmap_button_1.GetBestSize())
        self.static_line_13.SetMinSize((700,15))
        self.grid_client.CreateGrid(100, 4)
        self.grid_client.SetRowLabelSize(30)
        self.grid_client.EnableEditing(0)
        self.grid_client.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.grid_client.SetColLabelValue(0, _(u"C\xe9dula"))
        self.grid_client.SetColSize(0, 160)
        self.grid_client.SetColLabelValue(1, _("Nombre"))
        self.grid_client.SetColSize(1, 164)
        self.grid_client.SetColLabelValue(2, _(u"T\xe9lefono"))
        self.grid_client.SetColSize(2, 164)
        self.grid_client.SetColLabelValue(3, _("E- mail"))
        self.grid_client.SetColSize(3, 164)
        self.grid_client.SetMinSize((700, 420))
        self.grid_client.SetToolTipString(_(u"Cliente de Automotriz Full Fr\xedo"))
        self.static_line_14.SetMinSize((700, 15))
        self.bitmap_button_2.SetSize(self.bitmap_button_2.GetBestSize())
        self.notebook_client.SetMinSize((714, 3023))
        self.notebook_client.Hide()
        self.notebook_1.SetMinSize((720, 420))
        self.notebook_1.SetToolTipString(_("Actividades ejecutadas en el sistema"))
        # end wxGlade

    def __do_layout(self):
        # begin wxGlade: Menu.__do_layout
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        grid_sizer_20 = wx.FlexGridSizer(7, 1, 0, 0)
        grid_sizer_21 = wx.FlexGridSizer(1, 4, 0, 0)
        grid_sizer_3_copy_copy = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_6_copy_copy_1 = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_17 = wx.FlexGridSizer(8, 1, 0, 0)
        grid_sizer_80 = wx.FlexGridSizer(1, 3, 0, 0)
        grid_sizer_14_copy = wx.FlexGridSizer(3, 3, 0, 0)
        grid_sizer_5_copy = wx.FlexGridSizer(1, 11, 0, 0)
        grid_sizer_3_copy = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_6_copy = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_19 = wx.FlexGridSizer(5, 1, 0, 0)
        grid_sizer_40 = wx.FlexGridSizer(1, 3, 0, 0)
        grid_sizer_6_copy_copy_copy = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_18 = wx.FlexGridSizer(8, 1, 0, 0)
        grid_sizer_50 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_21_copy = wx.FlexGridSizer(1, 4, 0, 0)
        grid_sizer_3_copy_copy_copy = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_6_copy_copy = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_2 = wx.FlexGridSizer(15, 1, 0, 0)
        grid_sizer_16 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_14 = wx.FlexGridSizer(3, 3, 0, 0)
        grid_sizer_15 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_13 = wx.FlexGridSizer(1, 14, 0, 0)
        grid_sizer_38 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_12 = wx.FlexGridSizer(2, 6, 0, 0)
        grid_sizer_11 = wx.FlexGridSizer(1, 8, 0, 0)
        grid_sizer_10 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_9 = wx.FlexGridSizer(1, 6, 0, 0)
        grid_sizer_8 = wx.FlexGridSizer(1, 7, 0, 0)
        grid_sizer_7 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_6 = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_1 = wx.FlexGridSizer(7, 1, 0, 0)
        grid_sizer_5 = wx.FlexGridSizer(1, 11, 0, 0)
        grid_sizer_3 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_4 = wx.FlexGridSizer(2, 1, 0, 0)
        grid_sizer_4.Add((20, 5), 0, 0, 0)
        grid_sizer_4.Add(self.label_7, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_1.Add(grid_sizer_4, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_3.Add((20, 20), 0, 0, 0)
        grid_sizer_3.Add(self.label_6, 0, 0, 0)
        grid_sizer_1.Add(grid_sizer_3, 1, wx.EXPAND, 0)
        grid_sizer_5.Add((20, 20), 0, 0, 0)
        grid_sizer_5.Add(self.label_8, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5.Add(self.combo_box_H_mes, 0, 0, 0)
        grid_sizer_5.Add((20, 20), 0, 0, 0)
        grid_sizer_5.Add(self.label_9, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5.Add(self.spin_ctrl_H_ano, 0, 0, 0)
        grid_sizer_5.Add((20, 20), 0, 0, 0)
        grid_sizer_5.Add(self.label_10, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5.Add(self.combo_box_H_cat, 0, 0, 0)
        grid_sizer_5.Add((20, 20), 0, 0, 0)
        grid_sizer_5.Add(self.bitmap_button_H_search, 0, 0, 0)
        grid_sizer_1.Add(grid_sizer_5, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_1.Add(self.static_line_1, 0, wx.EXPAND, 0)
        grid_sizer_1.Add(self.grid_Hist, 1, wx.EXPAND, 0)
        grid_sizer_1.Add(self.static_line_2, 0, wx.EXPAND, 0)
        grid_sizer_1.Add(self.bitmap_button_H_close, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_hist.SetSizer(grid_sizer_1)
        grid_sizer_6.Add((11, 5), 0, 0, 0)
        grid_sizer_6.Add(self.label_1, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_6, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_2.Add(self.static_line_3, 0, wx.EXPAND, 0)
        grid_sizer_7.Add((20, 20), 0, 0, 0)
        grid_sizer_7.Add(self.label_2, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_7, 1, wx.EXPAND, 0)
        grid_sizer_8.Add((50, 20), 0, 0, 0)
        grid_sizer_8.Add(self.label_3, 0, 0, 0)
        grid_sizer_8.Add((67, 20), 0, 0, 0)
        grid_sizer_8.Add(self.choice_persona, 0, 0, 0)
        grid_sizer_8.Add(self.text_ctrl_AF_ci, 0, 0, 0)
        grid_sizer_8.Add(self.bitmap_button_3, 0, 0, 0)
        grid_sizer_8.Add(self.bitmap_button_9, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_8, 1, wx.EXPAND, 0)
        grid_sizer_9.Add((50, 20), 0, 0, 0)
        grid_sizer_9.Add(self.label_4, 0, 0, 0)
        grid_sizer_9.Add(self.text_ctrl_AF_name, 0, 0, 0)
        grid_sizer_9.Add((40, 20), 0, 0, 0)
        grid_sizer_9.Add(self.label_5, 0, 0, 0)
        grid_sizer_9.Add(self.text_ctrl_AF_tlf, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_9, 1, wx.EXPAND, 0)
        grid_sizer_2.Add(self.static_line_4, 0, wx.EXPAND, 0)
        grid_sizer_10.Add((20, 20), 0, 0, 0)
        grid_sizer_10.Add(self.label_11, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_10, 1, wx.EXPAND, 0)
        grid_sizer_11.Add((50, 20), 0, 0, 0)
        grid_sizer_11.Add(self.label_12, 0, 0, 0)
        grid_sizer_11.Add((70, 20), 0, 0, 0)
        grid_sizer_11.Add(self.text_ctrl_AF_Sitem, 0, 0, 0)
        grid_sizer_11.Add(self.bitmap_button_4, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_11, 1, wx.EXPAND, 0)
        grid_sizer_12.Add((50, 20), 0, 0, 0)
        grid_sizer_12.Add(self.label_13, 0, 0, 0)
        grid_sizer_12.Add(self.text_ctrl_AF_cod, 0, 0, 0)
        grid_sizer_12.Add((40, 20), 0, 0, 0)
        grid_sizer_12.Add(self.label_15, 0, 0, 0)
        grid_sizer_12.Add(self.text_ctrl_AF_brand, 0, 0, 0)
        grid_sizer_12.Add((50, 20), 0, 0, 0)
        grid_sizer_12.Add(self.label_14, 0, 0, 0)
        grid_sizer_12.Add(self.text_ctrl_AF_descrip, 0, 0, 0)
        grid_sizer_12.Add((40, 20), 0, 0, 0)
        grid_sizer_12.Add(self.label_16, 0, 0, 0)
        grid_sizer_12.Add(self.text_ctrl_AF_model, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_12, 1, wx.EXPAND, 0)
        grid_sizer_13.Add((50, 20), 0, 0, 0)
        grid_sizer_13.Add(self.label_18, 0, 0, 0)
        grid_sizer_13.Add((54, 20), 0, 0, 0)
        grid_sizer_13.Add(self.text_ctrl_AF_exist, 0, 0, 0)
        grid_sizer_13.Add((100, 20), 0, 0, 0)
        grid_sizer_13.Add(self.label_17, 0, 0, 0)
        grid_sizer_13.Add(self.choice_cant, 0, 0, 0)
        grid_sizer_13.Add(self.bitmap_button_5, 0, 0, 0)
        grid_sizer_38.Add(self.bitmap_button_11, 0, 0, 0)
        grid_sizer_38.Add(self.bitmap_button_12, 0, 0, 0)
        grid_sizer_13.Add(grid_sizer_38, 1, wx.EXPAND, 0)
        grid_sizer_2.Add(grid_sizer_13, 1, 0, 0)
        grid_sizer_2.Add(self.static_line_5, 0, wx.EXPAND, 0)
        grid_sizer_2.Add(self.grid_Fact, 1, wx.EXPAND, 4)
        grid_sizer_14.Add(self.label_19, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_14.Add(self.text_ctrl_AF_subt, 0, 0, 0)
        grid_sizer_14.Add((20, 20), 0, 0, 0)
        grid_sizer_15.Add(self.label_20, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_15.Add(self.text_ctrl_AF_iva, 0, 0, 0)
        grid_sizer_14.Add(grid_sizer_15, 1, wx.EXPAND, 0)
        grid_sizer_14.Add(self.text_ctrl_AF_addiva, 0, 0, 0)
        grid_sizer_14.Add((20, 20), 0, 0, 0)
        grid_sizer_14.Add(self.label_21, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_14.Add(self.text_ctrl_AF_item, 0, 0, 0)
        grid_sizer_14.Add((20, 20), 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_14, 1, wx.ALIGN_RIGHT, 0)
        grid_sizer_2.Add(self.static_line_6, 0, wx.EXPAND, 0)
        grid_sizer_16.Add(self.bitmap_button_6, 0, 0, 0)
        grid_sizer_16.Add(self.bitmap_button_7, 0, 0, 0)
        grid_sizer_2.Add(grid_sizer_16, 1, wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_addFact.SetSizer(grid_sizer_2)
        grid_sizer_6_copy_copy.Add((11, 5), 0, 0, 0)
        grid_sizer_6_copy_copy.Add(self.label_40, 0, 0, 0)
        grid_sizer_18.Add(grid_sizer_6_copy_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_3_copy_copy_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_3_copy_copy_copy.Add(self.label_6_copy_copy_copy, 0, 0, 0)
        grid_sizer_18.Add(grid_sizer_3_copy_copy_copy, 1, wx.EXPAND, 0)
        grid_sizer_21_copy.Add(self.label_22_copy, 0, 0, 0)
        grid_sizer_21_copy.Add(self.text_ctrl_I_dato, 0, 0, 0)
        grid_sizer_21_copy.Add(self.bitmap_button_1_copy, 0, 0, 0)
        grid_sizer_18.Add(grid_sizer_21_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_18.Add(self.static_line_9, 0, wx.EXPAND, 0)
        grid_sizer_18.Add(self.grid_invent, 1, wx.EXPAND, 0)
        grid_sizer_18.Add(self.static_line_10, 0, wx.EXPAND, 0)
        grid_sizer_50.Add(self.bitmap_button_61, 0, 0, 0)
        grid_sizer_50.Add(self.bitmap_button_71, 0, 0, 0)
        grid_sizer_18.Add(grid_sizer_50, 1, wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_invet.SetSizer(grid_sizer_18)
        grid_sizer_6_copy_copy_copy.Add((11, 5), 0, 0, 0)
        grid_sizer_6_copy_copy_copy.Add(self.label_40_copy, 0, 0, 0)
        grid_sizer_19.Add(grid_sizer_6_copy_copy_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_19.Add(self.static_line_11, 0, wx.EXPAND, 0)
        grid_sizer_19.Add(self.grid_requis, 1, wx.EXPAND, 0)
        grid_sizer_19.Add(self.static_line_12, 0, wx.EXPAND, 0)
        grid_sizer_40.Add(self.bitmap_button_60, 0, 0, 0)
        grid_sizer_40.Add(self.bitmap_button_8, 0, 0, 0)
        grid_sizer_40.Add(self.bitmap_button_70, 0, 0, 0)
        grid_sizer_19.Add(grid_sizer_40, 1, wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_requis.SetSizer(grid_sizer_19)
        grid_sizer_6_copy.Add((11, 5), 0, 0, 0)
        grid_sizer_6_copy.Add(self.label_30, 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_6_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_3_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_3_copy.Add(self.label_6_copy, 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_3_copy, 1, wx.EXPAND, 0)
        grid_sizer_5_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_5_copy.Add(self.label_8_copy, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5_copy.Add(self.combo_box_R_mes, 0, 0, 0)
        grid_sizer_5_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_5_copy.Add(self.label_9_copy, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_5_copy.Add(self.spin_ctrl_R_ano, 0, 0, 0)
        grid_sizer_5_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_5_copy.Add(self.bitmap_button_R_search, 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_5_copy, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_17.Add(self.static_line_7, 0, wx.EXPAND, 0)
        grid_sizer_17.Add(self.grid_report, 1, wx.EXPAND, 0)
        grid_sizer_14_copy.Add(self.label_21_copy, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_14_copy.Add(self.text_ctrl_R_total, 0, 0, 0)
        grid_sizer_14_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_14_copy, 1, wx.ALIGN_RIGHT, 0)
        grid_sizer_17.Add(self.static_line_8, 0, wx.EXPAND, 0)
        grid_sizer_80.Add(self.bitmap_button_62, 0, 0, 0)
        grid_sizer_80.Add(self.bitmap_button_71_copy, 0, 0, 0)
        grid_sizer_17.Add(grid_sizer_80, 1, wx.RIGHT | wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.notebook_report.SetSizer(grid_sizer_17)
        grid_sizer_6_copy_copy_1.Add((11, 5), 0, 0, 0)
        grid_sizer_6_copy_copy_1.Add(self.label_30_copy, 0, 0, 0)
        grid_sizer_20.Add(grid_sizer_6_copy_copy_1, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_3_copy_copy.Add((20, 20), 0, 0, 0)
        grid_sizer_3_copy_copy.Add(self.label_6_copy_copy, 0, 0, 0)
        grid_sizer_20.Add(grid_sizer_3_copy_copy, 1, wx.EXPAND, 0)
        grid_sizer_21.Add(self.label_22, 0, 0, 0)
        grid_sizer_21.Add(self.text_ctrl_C_Dato, 0, 0, 0)
        grid_sizer_21.Add(self.bitmap_button_1, 0, 0, 0)
        grid_sizer_20.Add(grid_sizer_21, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_20.Add(self.static_line_13, 0, wx.EXPAND, 0)
        grid_sizer_20.Add(self.grid_client, 1, wx.EXPAND, 0)
        grid_sizer_20.Add(self.static_line_14, 0, wx.EXPAND, 0)
        grid_sizer_20.Add(self.bitmap_button_2, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        self.notebook_client.SetSizer(grid_sizer_20)
        self.notebook_1.AddPage(self.notebook_hist, _("Historial"))
        self.notebook_1.AddPage(self.notebook_addFact, _("Nueva Factura"))
        self.notebook_1.AddPage(self.notebook_invet, _("Inventario"))
        self.notebook_1.AddPage(self.notebook_requis, _(u"Productos por debajo del M\xednimo"))
        self.notebook_1.AddPage(self.notebook_report, _("Reporte Mensual "))
        self.notebook_1.AddPage(self.notebook_client, _("Clientes "))
        sizer_1.Add(self.notebook_1, 1, wx.EXPAND, 0)
        self.SetSizer(sizer_1)
        self.Layout()
        # end wxGlade

    def onHist(self, event):  # wxGlade: Menu.<event_handler>
        privil =user.Ctrl_user()
        num = privil.privilegios()

        if num[0] == "0":
            self.notebook_hist.Show()
            datos = chist.Ctrl_hist()
            ar =datos.mostrar_historial()
            ext =len(ar)
            self.grid_Hist.AppendRows(ext)
            for t in range(ext):
                for r in range(3):
                    self.grid_Hist.SetCellValue(t, r, str(ar[t][r]))
        else:
            dlg = wx.MessageDialog(self,
                               "Usted no tiene permisos de Administrador",
                               "Privilegios", wx.OK|wx.ICON_WARNING)
            dlg.ShowModal()
        event.Skip()

    def onExit(self, event):  # wxGlade: Menu.<event_handler>
        dlg = wx.MessageDialog(self,
                               "¿Realmente quiere cerrar la Aplicación?",
                               "Confirmar Sálida", wx.OK|wx.CANCEL|wx.ICON_QUESTION)
        result = dlg.ShowModal()

        dlg.Destroy()
        if result == wx.ID_OK:
            self.Destroy()

    def onSearch_factura(self, event):  # wxGlade: Menu.<event_handler>
        dlg = DsFact.Dialog_search_fact()
        dlg.Show()
        event.Skip()

    def onAddFact(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_addFact.Show()

    def onReport(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        year = time.strftime("%Y")
        mon = time.strftime("%m")
        self.notebook_report.Show()
        self.notebook_report.AcceptsFocus()
        res = cFact.Ctrl_Fact()
        ar = res.report(year,mon)
        self.rep =len(ar)
        if self.rep == 0:
            dlg = wx.MessageDialog(self,"Aun no se ha facturado nada este mes","Notificación", wx.OK|wx.ICON_INFORMATION)
            dlg.ShowModal()
            dlg.Destroy()

        else:
            for t in range(self.rep):
                for r in range(5):
                    self.grid_report.SetCellValue(t, r, str(ar[t][r]))
                    if ar[t][r] == ar[t][4]:
                            new = val.monetario(float(ar[t][r]))
                            self.grid_report.SetCellValue(t, r, str(new))
                            self.sub = self.sub + float(ar[t][4])
                            self.text_ctrl_R_total.SetValue(str(val.monetario(self.sub)))

            event.Skip()

    def onSearchFact(self, event):  # wxGlade: Menu.<event_handler>
        dlg = DsFact.Dialog_search_fact()
        dlg.Show()
        event.Skip()

    def onIva(self, event):  # wxGlade: Menu.<event_handler>
        dlg = Diva.Dialog_iva()
        dlg.Show()

    def onInvent(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        self.notebook_invet.Show()
        res = citem.Ctrl_item()
        ar = res.inventario()
        self.inv =len(ar)
        for t in range(self.inv):
            for r in range(7):
                self.grid_invent.SetCellValue(t, r, str(ar[t][r]))
                if ar[t][r] == ar[t][4] or ar[t][r] == ar[t][6]:
                    new = val.monetario(float(ar[t][r]))
                    self.grid_invent.SetCellValue(t, r, str(new))
        event.Skip()

    def onRequis(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_requis.Show()
        res = citem.Ctrl_item()
        ar = res.requisiciones()
        self.req =len(ar)
        for t in range(self.req):
            for r in range(7):
                self.grid_requis.SetCellValue(t, r, str(ar[t][r]))
        event.Skip()

    def onAddItem(self, event):  # wxGlade: Menu.<event_handler>
        dlg = Ditem.Dialog_item()
        dlg.Show()
        event.Skip()

    def onSearchItem(self, event):  # wxGlade: Menu.<event_handler>
        dlg = DsItem.Dialog_search_item()
        dlg.Show()

    def onClients(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_client.Show()
        res =ccli.Ctrl_Cliente()
        ar = res.list_cli()
        ext =len(ar)
        for t in range(ext):
            for r in range(4):
                self.grid_client.SetCellValue(t, r, str(ar[t][r]))
        event.Skip()

    def onSearchClient(self, event):  # wxGlade: Menu.<event_handler>
        dlg = DsClie.Dialog_search_client()
        dlg.Show()
        event.Skip()

    def onAddClient(self, event):  # wxGlade: Menu.<event_handler>
        dlg = Dcli.Dialog_client()
        dlg.Show()
        event.Skip()

    def onPerfil(self, event):  # wxGlade: Menu.<event_handler>
        dlg =duser.Dialog_User()
        dlg.Mostrar()

    def onClose(self, event):  # wxGlade: Menu.<event_handler>
        self.Refresh()
        dlg = login.Dialog_Login()
        dlg.Show()
        log = user.Ctrl_user()
        log.loguot()
        event.Skip()

    def onSaveDB(self, event):  # wxGlade: Menu.<event_handler>
        backup = cmenu.Formulas()
        backup.backup_db()
        dlg = wx.MessageDialog(self, "Se ha realizado el respaldo satisfactoriamente\nDir: Documentos/Respaldo_FF2013 ", "Notificación", wx.OK)
        dlg.ShowModal()
        dlg.Destroy()
        event.Skip()

    def onImport(self, event):  # wxGlade: Menu.<event_handler>

        dlg = wx.MessageDialog(self, "Se recomienda hacer una repaldo antes de proceder "
                                     "\n¿Ésta seguro de que desea proceder?",
                               "Advertencia", wx.OK | wx.CANCEL|wx.ICON_WARNING)
        result = dlg.ShowModal()

        dlg.Destroy()
        if result == wx.ID_OK:
            restore = cmenu.Formulas()
            restore.onBrowse(event)
            dlg = wx.MessageDialog(self, "¡Se ha importado con éxito!",
                               "Notificación", wx.OK |wx.ICON_INFORMATION)
            dlg.ShowModal()
            dlg.Destroy()

    def onAbout(self, event):  # wxGlade: Menu.<event_handler>
        dlg = wx.MessageDialog(self, "Jhosnoirlit Hernández\njhosnoirlit@gmail.com\n\nPython2.7 - WxGlade2.8 \n\n           2015", "Acerca de",wx.CLOSE_BOX) # wx.OK)
        dlg.ShowModal()
        #dlg.Destroy()
        event.Skip()

    def onHelp(self, event):  # wxGlade: Menu.<event_handler>
        if sys.platform == 'linux2':
            os.system('xdg-open "manual_ff2013.pdf"')
        else:
            os.startfile(file)
        event.Skip()

    def onHistASearch(self, event):  # wxGlade: Menu.<event_handler>
        self.grid_Hist.ClearGrid()
        mon = self.combo_box_H_mes.GetCurrentSelection()
        val = validar.Validacion()
        mes = val.meses(mon)
        ano = self.spin_ctrl_H_ano.GetValue()
        cat = self.combo_box_H_cat.GetValue()
        res = chist.Ctrl_hist()
        bus = res.busqueda(ano, mes, cat)
        ext =len(bus)
        for t in range(ext):
            for r in range(3):
                self.grid_Hist.SetCellValue(t, r, str(bus[t][r]))

        event.Skip()

    def onHistClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_hist.Hide()
        event.Skip()

    def onChoicePersona(self, event):  # wxGlade: Menu.<event_handler>
        choise = self.choice_persona.GetCurrentSelection()
        event.Skip()

    def onFactCliente(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        ci = val.tra_per(self.choice_persona.GetCurrentSelection()) + val.cedula(self.text_ctrl_AF_ci.GetValue(), "Cédula")


        if ci == "" or ci == None:
            dlg = wx.MessageDialog(self, "Para continuar debe ingresar una cédula de cliente", "Notificación", wx.ICON_WARNING| wx.OK)
            dlg.ShowModal()
            dlg.Destroy()
        else:
            cliente = cFact.Ctrl_Fact()
            res = cliente.search_client(ci)

            if res == None:
                dlg = wx.MessageDialog(self, "No se ha encontrado ese cliente, pero puede registrarlo", "Notificación", wx.OK)
                dlg.ShowModal()
                dlg.Destroy()
                razon = 1
                nuevocli = Dcli.Dialog_client(razon)
                nuevocli.nuevo_cliente(self.text_ctrl_AF_ci.GetValue(), self.choice_persona.GetCurrentSelection())
            else:
                self.bitmap_button_3.Hide()
                self.bitmap_button_9.Show()
                self.text_ctrl_AF_name.SetValue(res[0])
                self.text_ctrl_AF_tlf.SetValue(res[1])
                self.text_ctrl_AF_ci.Enable(False)
                self.choice_persona.Enable(False)
        event.Skip()

    def onModClient(self, event):  # wxGlade: Menu.<event_handler>
        self.bitmap_button_3.Show()
        self.bitmap_button_9.Hide()
        self.text_ctrl_AF_ci.Enable(True)
        self.choice_persona.Enable(True)
        event.Skip()

    def onModItem(self, event):  # wxGlade: Menu.<event_handler>
        x, y = self.grid_Fact.CalcUnscrolledPosition(event.GetX(),event.GetY())
        self.coords = self.grid_Fact.XYToCell(x, y)

        res =[]
        for t in range(7):
            dato= self.grid_invent.GetCellValue(self.coords[0], t)
            res.append(dato)

        item = moditem.Dialog_modItem(res )
        item.Show()


        event.Skip()

    def onDeleteItem(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        ########
        self.sub = self.sub - float(val.monedadb(self.grid_Fact.GetCellValue(self.coords[0],4)))
        self.grid_Fact.DeleteRows(self.coords[0],self.coords[1])
        self.fila = self.fila - 1
        #######
        calculo = cmenu.Formulas()
        totales = calculo.total(self.sub, self.iva[0])
        self.text_ctrl_AF_subt.SetValue(val.monetario(self.sub))
        self.text_ctrl_AF_addiva.SetValue(val.monetario(totales[0]))
        self.text_ctrl_AF_iva.SetValue(str(totales[1]))
        self.text_ctrl_AF_item.SetValue(val.monetario(totales[2]))
        ############
        self.coords = ()
        self.text_ctrl_AF_Sitem.Clear()
        self.text_ctrl_AF_model.Clear()
        self.text_ctrl_AF_exist.Clear()
        self.text_ctrl_AF_descrip.Clear()
        self.text_ctrl_AF_brand.Clear()
        self.text_ctrl_AF_cod.Clear()
        self.choice_cant.SetValue(1)
        self.bitmap_button_5.Enable(False)
        self.bitmap_button_11.Enable(False)
        self.bitmap_button_12.Enable(False)
        self.text_ctrl_AF_Sitem.Enable(True)
        self.bitmap_button_4.Enable(True)

    def onModRow(self, event):  # wxGlade: Menu.<event_handler>
        self.text_ctrl_AF_Sitem.Enable(False)
        self.bitmap_button_4.Enable(False)
        self.bitmap_button_5.Enable(False)
        self.bitmap_button_11.Enable(True)
        self.bitmap_button_12.Enable(True)
        x, y = self.grid_Fact.CalcUnscrolledPosition(event.GetX(),event.GetY())
        self.coords = self.grid_Fact.XYToCell(x, y)
        col = self.coords[0]
        cod = self.grid_Fact.GetCellValue(col, 0)
        busc= cFact.Ctrl_Fact()
        res =busc.search_item(cod)
        self.choice_cant.SetRange(1, int(res[5]))
        self.text_ctrl_AF_cod.SetValue(str(res[0]))
        self.text_ctrl_AF_model.SetValue(res[1])
        self.text_ctrl_AF_brand.SetValue(res[2])
        self.text_ctrl_AF_descrip.SetValue(res[3])
        self.text_ctrl_AF_exist.SetValue(str(res[5]))

    def onFactItem(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()

        dato = self.text_ctrl_AF_Sitem.GetValue()
        item = cFact.Ctrl_Fact()
        res = item.search_item(val.vacio(dato,"Búscar"))
        for row in range(int(self.fila)):
            if dato == self.grid_Fact.GetCellValue(row,0):
                dlg = wx.MessageDialog(self, "Ya has ingresado este producto, intente modificarlo", "Notificación", wx.OK)
                self.text_ctrl_AF_Sitem.Clear()
                dlg.ShowModal()
                dlg.Destroy()


        if res == None:
            dlg = wx.MessageDialog(self, u"Este ítem no esta en existencia", "Notificación", wx.OK)
            dlg.ShowModal()
            dlg.Destroy()
            self.text_ctrl_AF_Sitem.Clear()

        else:
            self.bitmap_button_5.Enable(True)
            self.choice_cant.SetRange(1, int(res[5]))
            self.text_ctrl_AF_cod.SetValue(str(res[0]))
            self.text_ctrl_AF_model.SetValue(res[1])
            self.text_ctrl_AF_brand.SetValue(res[2])
            self.text_ctrl_AF_descrip.SetValue(res[3])
            self.text_ctrl_AF_exist.SetValue(str(res[5]))

    def onFactAdd(self, event):  # wxGlade: Menu.<event_handler>
        self.bitmap_button_5.Enable(False)
        iditem = self.text_ctrl_AF_cod.GetValue()
        cant = self.choice_cant.GetValue()
        con= cFact.Ctrl_Fact()
        res = con.cant_item(iditem)
        val = validar.Validacion()
        punit = float(res[2])
        monto = punit * float(cant)
        self.sub = self.sub + monto
        self.grid_Fact.SetCellValue(self.fila, 0, str(res[0]))
        self.grid_Fact.SetCellValue(self.fila, 1, res[1])
        self.grid_Fact.SetCellValue(self.fila, 2, str(cant))
        self.grid_Fact.SetCellValue(self.fila, 3, str(val.monetario(punit)))
        self.grid_Fact.SetCellValue(self.fila, 4, str(val.monetario(monto)))
        self.text_ctrl_AF_subt.SetValue(str(val.monetario(self.sub)))
        self.text_ctrl_AF_Sitem.Clear()
        self.text_ctrl_AF_model.Clear()
        self.text_ctrl_AF_exist.Clear()
        self.text_ctrl_AF_descrip.Clear()
        self.text_ctrl_AF_brand.Clear()
        self.text_ctrl_AF_cod.Clear()
        self.choice_cant.SetValue(1)
        self.fila += 1
        self.iva = con.iva()
        monto = cmenu.Formulas()
        totales = monto.total(self.sub, self.iva[0])
        self.text_ctrl_AF_addiva.SetValue(val.monetario(totales[0]))
        self.text_ctrl_AF_iva.SetValue(str(totales[1]))
        self.text_ctrl_AF_item.SetValue(val.monetario(totales[2]))

    def onFactPrint(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        tpl_print = []
        dato= val.tra_per(self.choice_persona.GetCurrentSelection()) + val.cedula(self.text_ctrl_AF_ci.GetValue(), "Cédula")

        confir = self.grid_Fact.GetCellValue(0,0)
        ## valida que existan campos
        if confir == "":
            dlg = wx.MessageDialog(self, "Debe haber algún ítem para procesar la facturación", "Notificación", wx.OK)
            dlg.ShowModal()
            dlg.Destroy()

        if dato =="":
            dlg = wx.MessageDialog(self, "No has ingresado ningún cliente", "Notificación", wx.OK)
            dlg.ShowModal()
            dlg.Destroy()
        ##busca el cliente
        con = cFact.Ctrl_Fact()
        res = con.search_client(dato)
        print res
        idcli=res[2]
        print idcli
        iva = con.iva()
        valor = iva [0]
        ##crea la factura con los datos de iva y cliente
        con.add_fact(valor, idcli)
        fid = cFact.Ctrl_Fact()
        facid=fid.facid()
        val = validar.Validacion()
        ## llena factura_has_item and print_PDF
        for fil in range(int(self.fila)):
            row = []
            row_print = []
            row.append(facid[0])
            for cell in [0,2,3]:
                if cell == 3:
                    celda = val.monedadb(self.grid_Fact.GetCellValue(fil, cell))
                    row.append(celda)
                else:
                    celda = self.grid_Fact.GetCellValue(fil, cell)
                    row.append(celda)
            for cel in range(5):
                algo = self.grid_Fact.GetCellValue(fil, cel)
                row_print.append(algo)
            tpl_print.append(row_print)
        tpl = tuple(row)
        newite = cFact.Ctrl_Fact()
        newite.add_item(tpl)
        ##llama a la funsion para imprimir
        total = val.monedadb(self.text_ctrl_AF_item.GetValue())
        sub = val.monedadb(self.text_ctrl_AF_subt.GetValue())
        iva = val.monedadb(self.text_ctrl_AF_addiva.GetValue())
        prifa = con.showFact1(facid[0])
        ttl=self.text_ctrl_AF_item.GetValue()
        subt=self.text_ctrl_AF_subt.GetValue()
        ivap=self.text_ctrl_AF_addiva.GetValue()
        verivap=str(self.text_ctrl_AF_iva.GetValue())
        pdf = cPdf.PDF()
        pdf.print_fact(prifa,tpl_print,subt,iva,verivap,ttl)
        ##se limpia la pestaña
        self.notebook_addFact.Hide()
        self.grid_Fact.ClearGrid()
        self.text_ctrl_AF_descrip.Clear()
        self.text_ctrl_AF_ci.Enable(True)
        self.text_ctrl_AF_ci.Clear()
        self.text_ctrl_AF_addiva.Clear()
        self.text_ctrl_AF_brand.Clear()
        self.text_ctrl_AF_cod.Clear()
        self.text_ctrl_AF_exist.Clear()
        self.text_ctrl_AF_item.Clear()
        self.text_ctrl_AF_iva.Clear()
        self.text_ctrl_AF_model.Clear()
        self.text_ctrl_AF_name.Clear()
        self.text_ctrl_AF_Sitem.Clear()
        self.text_ctrl_AF_subt.Clear()
        self.text_ctrl_AF_tlf.Clear()
        self.fila =0
        self.sub =0

    def onFactClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_addFact.Hide()
        self.grid_Fact.ClearGrid()
        self.text_ctrl_AF_descrip.Clear()
        self.text_ctrl_AF_ci.Enable(True)
        self.text_ctrl_AF_ci.Clear()
        self.text_ctrl_AF_addiva.Clear()
        self.text_ctrl_AF_brand.Clear()
        self.text_ctrl_AF_cod.Clear()
        self.text_ctrl_AF_exist.Clear()
        self.text_ctrl_AF_item.Clear()
        self.text_ctrl_AF_iva.Clear()
        self.text_ctrl_AF_model.Clear()
        self.text_ctrl_AF_name.Clear()
        self.text_ctrl_AF_Sitem.Clear()
        self.text_ctrl_AF_subt.Clear()
        self.text_ctrl_AF_tlf.Clear()
        self.bitmap_button_5.Enable(False)
        self.bitmap_button_11.Enable(False)
        self.bitmap_button_12.Enable(False)
        self.fila =0
        self.sub =0

        event.Skip()

    def onInventSearch(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        self.grid_invent.ClearGrid()
        dato = self.text_ctrl_I_dato.GetValue()
        invet = citem.Ctrl_item()
        ar = invet.busqueda_requis(dato)

        t =len(ar)
        for t in range(t):
            for r in range(7):
                self.grid_invent.SetCellValue(t, r, str(ar[t][r]))
                if ar[t][r] == ar[t][4] or ar[t][r] == ar[t][6]:
                        self.grid_invent.SetCellAlignment(0, 0,0, 4)
                        new = val.monetario(float(ar[t][r]))
                        self.grid_invent.SetCellValue(t, r, str(new))


        event.Skip()

    def onModInt(self, event):  # wxGlade: Menu.<event_handler>

        event.Skip()

    def onAjust(self, event):  # wxGlade: Menu.<event_handler>
        x, y = self.grid_Fact.CalcUnscrolledPosition(event.GetX(),event.GetY())
        self.coords = self.grid_requis.XYToCell(x, y)

        res =[]
        for t in range(8):
            dato= self.grid_requis.GetCellValue(self.coords[0], t)
            res.append(dato)


        ajust = Dajust.Dialog_ajuste(res)
        ajust.Show()
        event.Skip()

    def onInventPrint(self, event):  # wxGlade: Menu.<event_handler>
        tlp=[]
        for t in range(self.inv):
            row = []
            for r in range(7):
                row.append(self.grid_invent.GetCellValue(t, r))

            tlp.append(row)
        event.Skip()
        pdf = cPdf.PDF()
        pdf.print_invent(tlp)
        self.grid_invent.ClearGrid()
        self.inv=0
        self.notebook_invet.Hide()
        event.Skip()

    def onInventClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_invet.Hide()
        self.notebook_invet.Refresh()
        event.Skip()

    def onRequisPrint(self, event):  # wxGlade: Menu.<event_handler>
        tlp=[]
        for fil in range(self.req):
            row = []
            for cell in range(5):
                row.append(self.grid_requis.GetCellValue(fil, cell))
            tlp.append(row)
        pdf = cPdf.PDF()
        pdf.print_requis(tlp)

    def onRequisSave(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        for fil in range(self.req):
            row = []
            for cell in [0,1,2,3,5]:
                if cell ==0 or cell == 1:
                    val.vacio(self.grid_requis.GetCellValue(fil, cell), "Marca o Modelo")

                if cell == 2:
                    val.alfabetico(self.grid_requis.GetCellValue(fil, cell), "Descripción")

                if cell == 3:
                   val.numerico(self.grid_requis.GetCellValue(fil, cell), "Existencia ")

                row.append(self.grid_requis.GetCellValue(fil, cell))

            tpl = tuple(row)
            newreq = citem.Ctrl_item()
            newreq.actualizar_requis(tpl)
        self.grid_requis.ClearGrid()
        self.fila =0

    def onRequisClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_requis.Hide()
        self.notebook_requis.Refresh()
        event.Skip()

    def onReportSearch(self, event):  # wxGlade: Menu.<event_handler>
        val = validar.Validacion()
        year = self.spin_ctrl_R_ano.GetValue()
        mon = self.combo_box_R_mes.GetCurrentSelection()
        res = cFact.Ctrl_Fact()
        ar = res.report(year,mon)
        self.rep =len(ar)
        if self.rep == 0:
            dlg = wx.MessageDialog(self,"No hay Facturaciones para esa fecha","Notificación", wx.OK|wx.ICON_INFORMATION)
            dlg.ShowModal()
            dlg.Destroy()

        else:
            for t in range(self.rep):
                for r in range(5):
                    self.grid_report.SetCellValue(t, r, str(ar[t][r]))
                    if ar[t][r] == ar[t][4]:
                            new = val.monetario(float(ar[t][r]))
                            self.grid_report.SetCellValue(t, r, str(new))
                            self.sub = self.sub + float(ar[t][4])
                            self.text_ctrl_R_total.SetValue(str(val.monetario(self.sub)))

    def onShowClient(self, event):  # wxGlade: Menu.<event_handler>
        x, y = self.grid_Fact.CalcUnscrolledPosition(event.GetX(),event.GetY())
        self.coords = self.grid_Fact.XYToCell(x, y)
        res = str(self.grid_client.GetCellValue(self.coords[0], 0))

        client =modcli.Dialog_modClient(res)
        client.Show()

        event.Skip()

    def onShowFact(self, event):  # wxGlade: Menu.<event_handler>
        print "Event handler 'onShowFact' not implemented!"
        event.Skip()

    def onReporPrint(self, event):  # wxGlade: Menu.<event_handler>
        year = self.spin_ctrl_R_ano.GetValue()
        mon = self.combo_box_R_mes.GetCurrentSelection()

        tlp=[]
        for t in range(self.rep):
            row = []
            for r in range(5):
                row.append(self.grid_report.GetCellValue(t, r))
            tlp.append(row)
        ttl = self.text_ctrl_R_total.GetValue()
        pdf = cPdf.PDF()
        pdf.print_report(tlp, ttl)

    def onReportClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_report.Hide()
        self.notebook_report.Refresh()
        self.grid_report.ClearGrid()
        self.combo_box_R_mes.SetValue("")
        self.sub = 0
        self.rep = 0
        self.text_ctrl_R_total.Clear()
        event.Skip()

    def onClientSearch(self, event):  # wxGlade: Menu.<event_handler>
        val =validar.Validacion()
        dato = val.vacio(self.text_ctrl_C_Dato.GetValue(),"Búsqueda de cliente")
        bus = ccli.Ctrl_Cliente()
        ar = bus.buscar_client(dato)
        self.grid_client.ClearGrid()
        ext =len(ar)
        for t in range(ext):
            for r in range(4):
                self.grid_client.SetCellValue(t, r, str(ar[t][r]))

    def onClientClose(self, event):  # wxGlade: Menu.<event_handler>
        self.notebook_client.Hide()
        self.notebook_client.Refresh()
        event.Skip()

