#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import wx, os
import Model.model_validar as val
import Controller.ctrl_cliente as cCli
# begin wxGlade: dependencies
# end wxGlade

# begin wxGlade: extracode
# end wxGlade


class Dialog_modClient(wx.Dialog):
	def __init__(self,ci,  *args, **kwds ):
		cli = cCli.Ctrl_Cliente()
		res = cli.devuelve_busqueda(ci)
		print "Mod cliente: ", res, ci
		# begin wxGlade: Dialog_modClient.__init__
		kwds["style"] = wx.DEFAULT_DIALOG_STYLE
		wx.Dialog.__init__(self, None, **kwds)
		self.label_ttl = wx.StaticText(self, wx.ID_ANY, _("Modificar Cliente"))
		self.static_line_13 = wx.StaticLine(self, wx.ID_ANY)
		self.label_72 = wx.StaticText(self, wx.ID_ANY, _(u"C\xe9dula: "))
		self.text_ctrl_52 = wx.TextCtrl(self, wx.ID_ANY, res[1])
		self.label_73 = wx.StaticText(self, wx.ID_ANY, _("Nombre y Apellido: "))
		self.text_ctrl_51 = wx.TextCtrl(self, wx.ID_ANY, res[2])
		self.label_74 = wx.StaticText(self, wx.ID_ANY, _(u"T\xe9lefono: "))
		self.text_ctrl_50 = wx.TextCtrl(self, wx.ID_ANY, res[3])
		self.label_75 = wx.StaticText(self, wx.ID_ANY, _("Email: "))
		self.text_ctrl_49 = wx.TextCtrl(self, wx.ID_ANY, res[4])
		self.text_ctrl_48 = wx.TextCtrl(self, wx.ID_ANY, str(res[0]))
		button_15 = os.path.abspath('../View/img/icons/trashcan_full_big.png')
		button_16 = os.path.abspath('../View/img/icons/save_big.png')
		button_17 = os.path.abspath('../View/img/icons/Valid_big.png')
		self.bitmap_button_15 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_15, wx.BITMAP_TYPE_ANY))
		self.bitmap_button_16 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_16, wx.BITMAP_TYPE_ANY))
		self.bitmap_button_17 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap(button_17, wx.BITMAP_TYPE_ANY))

		self.__set_properties()
		self.__do_layout()

		self.Bind(wx.EVT_BUTTON, self.onDelete, self.bitmap_button_15)
		self.Bind(wx.EVT_BUTTON, self.onSave, self.bitmap_button_16)
		self.Bind(wx.EVT_BUTTON, self.onAcept, self.bitmap_button_17)
		# end wxGlade

	def __set_properties(self):
		# begin wxGlade: Dialog_modClient.__set_properties
		self.SetTitle(_("Modificar Cliente"))
		favicon = os.path.abspath('../View/img/logotipo_tini.png')
		_icon = wx.EmptyIcon()
		_icon.CopyFromBitmap(wx.Bitmap(favicon, wx.BITMAP_TYPE_ANY))
		self.SetIcon(_icon)
		self.label_ttl.SetMinSize((125, 21))
		self.label_ttl.SetFont(wx.Font(10, wx.DEFAULT, wx.ITALIC, wx.NORMAL, 0, ""))
		self.static_line_13.SetMinSize((240, 15))
		self.text_ctrl_51.SetMinSize((180, 27))
		self.text_ctrl_52.Enable(False)
		self.text_ctrl_49.SetMinSize((180, 27))
		self.text_ctrl_48.Enable(False)
		self.text_ctrl_48.Hide()
		self.bitmap_button_15.SetMinSize((42, 44))
		self.bitmap_button_15.SetToolTipString(_("Eliminar"))
		self.bitmap_button_16.SetMinSize((40, 42))
		self.bitmap_button_16.SetToolTipString(_("Guardar"))
		self.bitmap_button_17.SetToolTipString(_("Aceptar"))
		self.bitmap_button_17.SetSize(self.bitmap_button_17.GetBestSize())
		# end wxGlade

	def __do_layout(self):
		# begin wxGlade: Dialog_modClient.__do_layout
		grid_sizer_50 = wx.FlexGridSizer(5, 1, 0, 0)
		grid_sizer_54 = wx.FlexGridSizer(2, 3, 0, 0)
		grid_sizer_53 = wx.FlexGridSizer(5, 3, 0, 0)
		grid_sizer_50.Add(self.label_ttl, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
		grid_sizer_50.Add(self.static_line_13, 0, wx.EXPAND, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)
		grid_sizer_53.Add(self.label_72, 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_53.Add(self.text_ctrl_52, 0, 0, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)
		grid_sizer_53.Add(self.label_73, 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_53.Add(self.text_ctrl_51, 0, 0, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)
		grid_sizer_53.Add(self.label_74, 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_53.Add(self.text_ctrl_50, 0, 0, 0)
		grid_sizer_53.Add((20, 20), 0, 0, 0)
		grid_sizer_53.Add(self.label_75, 0, wx.ALIGN_RIGHT | wx.ALIGN_CENTER_VERTICAL, 0)
		grid_sizer_53.Add(self.text_ctrl_49, 0, 0, 0)
		grid_sizer_53.Add(self.text_ctrl_48, 0, 0, 0)
		grid_sizer_50.Add(grid_sizer_53, 1, wx.EXPAND, 0)
		grid_sizer_50.Add((20, 20), 0, 0, 0)
		grid_sizer_54.Add(self.bitmap_button_15, 0, 0, 0)
		grid_sizer_54.Add(self.bitmap_button_16, 0, 0, 0)
		grid_sizer_54.Add(self.bitmap_button_17, 0, 0, 0)
		grid_sizer_54.Add((20, 20), 0, 0, 0)
		grid_sizer_50.Add(grid_sizer_54, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
		self.SetSizer(grid_sizer_50)
		grid_sizer_50.Fit(self)
		self.Layout()
		# end wxGlade

	def onDelete(self, event):  # wxGlade: Dialog_modClient.<event_handler>
		dlg = wx.MessageDialog(self,"¿Realmente quiere eliminar este cliente?", "Advertencia",wx.YES_NO | wx.ICON_QUESTION)
		res = dlg.ShowModal() == wx.ID_YES
		if res == True:
			idcli = self.text_ctrl_48.GetValue()
			delete = cCli.Ctrl_Cliente()
			delete.delete_cli(idcli)
			dlg = wx.MessageDialog(self,"El cliente ha sido eliminado", "Notificación",wx.OK | wx.ICON_INFORMATION)
			dlg.ShowModal()
		print res
		self.Destroy()

	def onSave(self, event):  # wxGlade: Dialog_modClient.<event_handler>
		validar = val.Validacion()
		ci = validar.numerico(self.text_ctrl_52.GetValue(), "Cédula")
		nombre = validar.vacio(self.text_ctrl_51.GetValue(), "Nombre")
		email = validar.email(self.text_ctrl_49.GetValue())
		tlf = validar.numerico(self.text_ctrl_50.GetValue(), "Teléfono")
		idcli = self.text_ctrl_48.GetValue()
		cliente = cCli.Ctrl_Cliente()
		cliente.save_mod(ci, nombre, email, tlf, idcli)
		dlg = wx.MessageDialog(self,"El cliente ha sido modificado éxitosamente", "Notificación",wx.ICON_INFORMATION|  wx.CLOSE_BOX)
		dlg.ShowModal()
		self.Destroy()

	def onAcept(self, event):  # wxGlade: Dialog_modClient.<event_handler>
		self.Destroy()
		event.Skip()



# end of class Dialog_modClient
