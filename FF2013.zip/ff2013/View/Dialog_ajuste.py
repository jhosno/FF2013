#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'


import wx
import wx.grid, os
import Controller.ctrl_historial as cHist
import Controller.ctrl_item as cItem
import Model.model_validar as validar

# begin wxGlade: extracode
# end wxGlade


class Dialog_ajuste(wx.Dialog):
    def __init__(self, res, *args, **kwds):
        # begin wxGlade: Dialog_ajuste.__init__
        hist = cHist.Ctrl_hist()
        mov = hist.mov_item(res[0])
        self.exist = res[4]

        kwds["style"] = wx.DEFAULT_DIALOG_STYLE
        wx.Dialog.__init__(self, None, **kwds)
        self.label_38 = wx.StaticText(self, wx.ID_ANY, _("Ajuste de Inventario"))
        self.static_line_19 = wx.StaticLine(self, wx.ID_ANY)
        self.label_53 = wx.StaticText(self, wx.ID_ANY, _(u"\xcdtem"))
        self.label_39 = wx.StaticText(self, wx.ID_ANY, _(u"C\xf3digo: "))
        self.text_ctrl_5 = wx.TextCtrl(self, wx.ID_ANY, res[0], style=wx.TE_READONLY)
        self.label_44 = wx.StaticText(self, wx.ID_ANY, _("Marca: "))
        self.text_ctrl_9 = wx.TextCtrl(self, wx.ID_ANY, res[1], style=wx.TE_READONLY)
        self.label_41 = wx.StaticText(self, wx.ID_ANY, _("Modelo: "))
        self.text_ctrl_6 = wx.TextCtrl(self, wx.ID_ANY, res[2], style=wx.TE_READONLY)
        self.label_45 = wx.StaticText(self, wx.ID_ANY, _(u"Descripci\xf3n: "))
        self.text_ctrl_10 = wx.TextCtrl(self, wx.ID_ANY, res[3], style=wx.TE_READONLY)
        self.label_42 = wx.StaticText(self, wx.ID_ANY, _(u"Stock M\xe1ximo: "))
        self.text_ctrl_7 = wx.TextCtrl(self, wx.ID_ANY, res[5], style=wx.TE_READONLY)
        self.label_46 = wx.StaticText(self, wx.ID_ANY, _(u"Stock M\xednimo: "))
        self.text_ctrl_11 = wx.TextCtrl(self, wx.ID_ANY, res[6])
        self.label_43 = wx.StaticText(self, wx.ID_ANY, _("Existencia: "))
        self.text_ctrl_8 = wx.TextCtrl(self, wx.ID_ANY, res[4])
        self.label_47 = wx.StaticText(self, wx.ID_ANY, _(u"Actualizaci\xf3n: "))
        self.choice_1 = wx.Choice(self, wx.ID_ANY, choices=[_("Entrada"), _("Salida")])
        self.static_line_20 = wx.StaticLine(self, wx.ID_ANY)
        self.label_52 = wx.StaticText(self, wx.ID_ANY, _("Historial"))
        self.label_50 = wx.StaticText(self, wx.ID_ANY, _("Mes: "))
        self.combo_box_H_mes = wx.ComboBox(self, wx.ID_ANY, choices=["", _("Enero"), _("Febrero"), _("Marzo"), _("Abril"), _("Mayo"), _("Junio"), _("Julio"), _("Agosto"), _("Septiembre"), _("Octubre"), _("Noviembre"), _("Diciembre")], style=wx.CB_DROPDOWN)
        self.label_51 = wx.StaticText(self, wx.ID_ANY, _(u"A\xf1o: "))
        self.spin_ctrl_H_ano = wx.SpinCtrl(self, wx.ID_ANY, "", min=2015, max=3000)
        self.label_48 = wx.StaticText(self, wx.ID_ANY, _("Movimiento: "))
        self.combo_box_1 = wx.ComboBox(self, wx.ID_ANY, choices=[_("Todos"), _("Entrada"), _("Salida")], style=wx.CB_DROPDOWN)
        self.bitmap_button_18 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/search_small.png", wx.BITMAP_TYPE_ANY))
        self.static_line_22 = wx.StaticLine(self, wx.ID_ANY)
        self.grid_1 = wx.grid.Grid(self, wx.ID_ANY, size=(1, 1))
        self.static_line_21 = wx.StaticLine(self, wx.ID_ANY)
        self.bitmap_button_16 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/close_circle_big.png", wx.BITMAP_TYPE_ANY))
        self.bitmap_button_17 = wx.BitmapButton(self, wx.ID_ANY, wx.Bitmap("/home/saint/Documentos/FF2013/View/img/icons/save_big.png", wx.BITMAP_TYPE_ANY))

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_BUTTON, self.onSearch, self.bitmap_button_18)
        self.Bind(wx.EVT_BUTTON, self.onCancel, self.bitmap_button_16)
        self.Bind(wx.EVT_BUTTON, self.onSave, self.bitmap_button_17)
        # end wxGlade

        #########################################################
        ext =len(mov)
        self.grid_1.AppendRows(ext)
        for t in range(ext):
            for r in range(3):
                self.grid_1.SetCellValue(t, r, str(mov[t][r]))
        #################################################################

    def __set_properties(self):

        # begin wxGlade: Dialog_ajuste.__set_properties
        self.SetTitle(_("Ajuste de Inventario"))
        favicon = os.path.abspath('../View/img/logotipo_tini.png')
        _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap(favicon, wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.SetSize((510, 616))
        self.label_38.SetFont(wx.Font(11, wx.DEFAULT, wx.ITALIC, wx.BOLD, 0, ""))
        self.static_line_19.SetMinSize((510, 10))
        self.label_53.SetFont(wx.Font(9, wx.DEFAULT, wx.ITALIC, wx.BOLD, 0, ""))
        self.text_ctrl_5.SetMinSize((100, 27))
        self.text_ctrl_5.SetToolTipString(_(u"C\xf3digo del \xedtem"))
        self.text_ctrl_5.Enable(False)
        self.text_ctrl_9.SetMinSize((100, 27))
        self.text_ctrl_9.SetToolTipString(_(u"Marca del \xedtem"))
        self.text_ctrl_9.Enable(False)
        self.text_ctrl_6.SetMinSize((100, 27))
        self.text_ctrl_6.SetToolTipString(_(u"Modelo del \xedtem"))
        self.text_ctrl_6.Enable(False)
        self.text_ctrl_10.SetMinSize((100, 27))
        self.text_ctrl_10.Enable(False)
        self.text_ctrl_7.SetMinSize((100, 27))
        self.text_ctrl_7.SetToolTipString(_(u"Cantidad m\xe1xima en almac\xe9n"))

        self.text_ctrl_11.SetMinSize((100, 27))
        self.text_ctrl_11.SetToolTipString(_(u"Cantidad m\xednima en almac\xe9n"))
        self.text_ctrl_11.SetFocus()
        self.text_ctrl_8.SetMinSize((100, 27))
        self.text_ctrl_8.SetToolTipString(_(u"Existencia de \xedtem"))
        self.choice_1.SetSelection(0)
        self.static_line_20.SetMinSize((500, 10))
        self.label_52.SetFont(wx.Font(9, wx.DEFAULT, wx.ITALIC, wx.BOLD, 0, ""))
        self.combo_box_H_mes.SetMinSize((100, 29))
        self.combo_box_H_mes.SetToolTipString(_("Mes que se desea consultar"))
        self.combo_box_H_mes.SetSelection(0)
        self.spin_ctrl_H_ano.SetMinSize((60, 27))
        self.spin_ctrl_H_ano.SetToolTipString(_(u"A\xf1o que se de sea consultar"))
        self.combo_box_1.SetMinSize((80, 29))
        self.combo_box_1.SetToolTipString(_("Tipo de movimiento que desea consultar"))
        self.combo_box_1.SetSelection(0)
        self.bitmap_button_18.SetToolTipString(_(u"B\xfasqueda"))
        self.bitmap_button_18.SetSize(self.bitmap_button_18.GetBestSize())
        self.static_line_22.SetMinSize((510, 10))
        self.grid_1.CreateGrid(100, 3)
        self.grid_1.SetRowLabelSize(30)
        self.grid_1.EnableEditing(0)
        self.grid_1.EnableDragGridSize(0)
        self.grid_1.SetColLabelValue(0, _("Fecha"))
        self.grid_1.SetColSize(0, 150)
        self.grid_1.SetColLabelValue(1, _("Movimiento"))
        self.grid_1.SetColSize(1, 150)
        self.grid_1.SetColLabelValue(2, _("Cantidad"))
        self.grid_1.SetColSize(2, 160)
        self.grid_1.SetMinSize((510, 300))
        self.static_line_21.SetMinSize((500, 10))
        self.bitmap_button_16.SetMinSize((40, 42))
        self.bitmap_button_16.SetToolTipString(_("Cancelar"))
        self.bitmap_button_17.SetMinSize((40, 42))
        self.bitmap_button_17.SetToolTipString(_("Guardar"))
        # end wxGlade

    def __do_layout(self):
        # begin wxGlade: Dialog_ajuste.__do_layout
        grid_sizer_32 = wx.FlexGridSizer(12, 1, 0, 0)
        grid_sizer_33 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_35 = wx.FlexGridSizer(1, 10, 0, 0)
        grid_sizer_37 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_34 = wx.FlexGridSizer(4, 5, 0, 0)
        grid_sizer_36 = wx.FlexGridSizer(1, 2, 0, 0)
        grid_sizer_32.Add((20, 20), 0, 0, 0)
        grid_sizer_32.Add(self.label_38, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_32.Add(self.static_line_19, 0, wx.EXPAND, 0)
        grid_sizer_36.Add((20, 20), 0, 0, 0)
        grid_sizer_36.Add(self.label_53, 0, 0, 0)
        grid_sizer_32.Add(grid_sizer_36, 1, wx.EXPAND, 0)
        grid_sizer_34.Add(self.label_39, 0, 0, 0)
        grid_sizer_34.Add(self.text_ctrl_5, 0, 0, 0)
        grid_sizer_34.Add((20, 20), 0, 0, 0)
        grid_sizer_34.Add(self.label_44, 0, 0, 0)
        grid_sizer_34.Add(self.text_ctrl_9, 0, 0, 0)
        grid_sizer_34.Add(self.label_41, 0, 0, 0)
        grid_sizer_34.Add(self.text_ctrl_6, 0, 0, 0)
        grid_sizer_34.Add((20, 20), 0, 0, 0)
        grid_sizer_34.Add(self.label_45, 0, 0, 0)
        grid_sizer_34.Add(self.text_ctrl_10, 0, 0, 0)
        grid_sizer_34.Add(self.label_42, 0, 0, 0)
        grid_sizer_34.Add(self.text_ctrl_7, 0, 0, 0)
        grid_sizer_34.Add((20, 20), 0, 0, 0)
        grid_sizer_34.Add(self.label_46, 0, 0, 0)
        grid_sizer_34.Add(self.text_ctrl_11, 0, 0, 0)
        grid_sizer_34.Add(self.label_43, 0, 0, 0)
        grid_sizer_34.Add(self.text_ctrl_8, 0, 0, 0)
        grid_sizer_34.Add((20, 20), 0, 0, 0)
        grid_sizer_34.Add(self.label_47, 0, 0, 0)
        grid_sizer_34.Add(self.choice_1, 0, 0, 0)
        grid_sizer_32.Add(grid_sizer_34, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_32.Add(self.static_line_20, 0, wx.EXPAND, 0)
        grid_sizer_37.Add((20, 20), 0, 0, 0)
        grid_sizer_37.Add(self.label_52, 0, 0, 0)
        grid_sizer_32.Add(grid_sizer_37, 1, wx.EXPAND, 0)
        grid_sizer_35.Add(self.label_50, 0, 0, 0)
        grid_sizer_35.Add(self.combo_box_H_mes, 0, 0, 0)
        grid_sizer_35.Add((20, 20), 0, 0, 0)
        grid_sizer_35.Add(self.label_51, 0, 0, 0)
        grid_sizer_35.Add(self.spin_ctrl_H_ano, 0, 0, 0)
        grid_sizer_35.Add((20, 20), 0, 0, 0)
        grid_sizer_35.Add(self.label_48, 0, 0, 0)
        grid_sizer_35.Add(self.combo_box_1, 0, 0, 0)
        grid_sizer_35.Add((20, 20), 0, 0, 0)
        grid_sizer_35.Add(self.bitmap_button_18, 0, 0, 0)
        grid_sizer_32.Add(grid_sizer_35, 0, wx.ALIGN_CENTER_HORIZONTAL, 0)
        grid_sizer_32.Add(self.static_line_22, 0, wx.EXPAND, 0)
        grid_sizer_32.Add(self.grid_1, 1, wx.EXPAND, 0)
        grid_sizer_32.Add(self.static_line_21, 0, wx.EXPAND, 0)
        grid_sizer_33.Add(self.bitmap_button_16, 0, 0, 0)
        grid_sizer_33.Add(self.bitmap_button_17, 0, 0, 0)
        grid_sizer_32.Add(grid_sizer_33, 1, wx.ALIGN_CENTER_HORIZONTAL, 0)
        self.SetSizer(grid_sizer_32)
        self.Layout()
        # end wxGlade

    def onSearch(self, event):  # wxGlade: Dialog_ajuste.<event_handler>
        mes = self.combo_box_H_mes.GetValue()
        ano= self.spin_ctrl_H_ano.GetValue()
        mov = self.combo_box_1.GetValue()
        hist= cHist.Ctrl_hist()
        hist.busqueda_item(mes, ano, mov)
        event.Skip()

    def onCancel(self, event):  # wxGlade: Dialog_ajuste.<event_handler>
        self.Destroy()

    def onSave(self, event):  # wxGlade: Dialog_ajuste.<event_handler>
        val = validar.Validacion()
        cod = self.text_ctrl_5.GetValue()
        s_min = val.numerico(self.text_ctrl_11.GetValue())
        s_max = val.numerico(self.text_ctrl_7.GetValue())
        exist = val.numerico(self.text_ctrl_8.GetValue())
        if exist < 0:
            dlg = wx.MessageDialog(self,
                               "No es posible tener existencia negativa",
                               "Advertencia", wx.OK|wx.ICON_WARNING)
            dlg.ShowModal()
            self.text_ctrl_8.SetValue(self.exist)
        else:
            save = cItem.Ctrl_item()
            save.ajust(cod, s_max,s_min,exist, self.exist)


# end of class Dialog_ajuste
