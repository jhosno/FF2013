# -*- coding: UTF-8 -*-
__author__ = 'Jhosnoirllit Hernández'

import os

class DB:
    def return_dir(self):
        dbdir= os.path.abspath('../DB/ff2013.db')
        return dbdir

