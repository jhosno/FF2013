#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import sqlite3 as lite
import DB.db as dir


class Usuario:

    def __init__(self):
        setdir= dir.DB()
        self.file= setdir.return_dir()
        self.db = lite.connect(self.file)
        self.cur = self.db.cursor()
        self.cur = lite.connect('cache.db', timeout=10)
        self.cur = self.db.cursor()

    def validar_usuario(self, user, pwd):
        self.cur.execute('''SELECT nick, pass FROM usuario WHERE nick= ? and pass=? ''', (user,pwd))
        resultado = self.cur.fetchone()
        self.db.commit()
        return resultado


