#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import sqlite3 as lite
import DB.db as dir



class Cliente:
    def __init__(self):
        setdir= dir.DB()
        self.file= setdir.return_dir()
        self.db = lite.connect(self.file)
        self.cur = self.db.cursor()
        self.cur = lite.connect('cache.db', timeout=10)
        self.cur = self.db.cursor()

    def nuevo_cliente(self, ci, nombre, email, tlf):
        self.cur.execute('''INSERT INTO cliente (id, ci, nombre, email, tlf)
                    VALUES (null, ?, ?, ?, ?)''', (ci, nombre, email, tlf))


        self.db.commit()

    def eliminar_cliente(self, id):
        self.cur.execute('''DELETE FROM cliente WHERE id = ?''', (id))
        self.db.commit()

    def actualizar_cliente(self, ci, nombre, email, tlf, id):
        self.cur.execute('''UPDATE cliente SET ci = ?, nombre = ?, email = ?, tlf = ?  WHERE  id= ? ''',
                    (ci, nombre, email, tlf,  id,))
        self.db.execute("""INSERT INTO historial (id, fecha, tabla, tabla_id, movimiento) VALUES (null,date('now'),'cliente',?, 'actualizar Cliente')""", (id,))
        self.db.execute("PRAGMA busy_timeout = 30000") #permite consultas simultanes y despeja el bloqueo de DB
        self.db.commit()

    def listar_cliente(self): #muestra todas las entradas
        self.cur.execute("SELECT ci, nombre, tlf, email FROM cliente")
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado

    def buscar_cliente(self, ci): # busqueda basada en  cedula UNICA del cliente
        self.cur.execute('''SELECT nombre, tlf, id FROM cliente WHERE ci=? ''', (ci,))
        resultado = self.cur.fetchone()
        self.db.commit()
        return resultado

    def buscar_cliente_fhi(self, ci):
        self.cur.execute('''SELECT id FROM cliente WHERE ci=? ''', (ci,))
        resultado = self.cur.fetchone()
        self.db.commit()
        return resultado

    def resultado_cliente(self, ci):
        self.cur.execute('''SELECT id, ci, nombre, tlf, email FROM cliente WHERE ci = ?  ''', (ci, ))
        resultado = self.cur.fetchone()
        self.db.commit()
        return  resultado

    def bus_cli_list(self,dato):
        self.cur.execute('''SELECT ci,nombre,tlf,email FROM cliente WHERE ci=? OR id = ? OR nombre LIKE ? ''', (dato,dato, '%'+dato+'%'))
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado



