#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import sqlite3 as lite
import DB.db as dir

class Factura:
    def __init__(self):
        setdir= dir.DB()
        self.file= setdir.return_dir()
        self.db = lite.connect(self.file)
        self.cur = self.db.cursor()
        self.cur = lite.connect('cache.db', timeout=10)
        self.cur = self.db.cursor()

    def nueva_factura(self, id_cliente, estado, iva):
        self.cur.execute('''INSERT INTO factura (id,  fecha, estado, cliente_id, iva) VALUES (null,date('now'), ?, ?, ?)''', ( estado, id_cliente, iva))
        self.db.commit()

    def devuelve_id(self):
        self.cur.execute('''SELECT id from factura ORDER BY id desC LIMIT 1 ''')
        valor = self.cur.fetchone()
        self.db.commit()
        return valor

    def subir_item(self, arreglo):
        self.cur.execute('''INSERT INTO factura_has_item (factura_id, item_id, cant, precio) VALUES (?,?,?,?)''', (arreglo[0], arreglo[1], arreglo[2], arreglo[3]))
        self.db.commit()
        self.db.execute("PRAGMA busy_timeout = 30000")
        iditem= arreglo[1]
        self.cur.execute('''SELECT id, existencia FROM item WHERE id = ?''', (iditem,))
        res=  self.cur.fetchone()
        existencia = int(res[1])
        cant=int(arreglo[2])
        actexist = existencia - cant
        self.db.execute("PRAGMA busy_timeout = 30000")
        self.cur.execute('''UPDATE item SET existencia = ? WHERE id = ?''', ( actexist, arreglo[1]))
        self.db.execute("PRAGMA busy_timeout = 30000")
        self.db.execute("""INSERT INTO historial (id, fecha, tabla, tabla_id, movimiento, cantidad) VALUES (null,date('now'),'item',?, 'Salida: venta del producto',?)""", (res[0],cant,))
        self.db.execute("PRAGMA busy_timeout = 30000")
        self.db.commit()

    def eliminar_factura(self, id):
        self.cur.execute('''DELETE FROM factura WHERE id = ?''', (id))
        self.db.commit()

    def modificar_factura(self, estado, id): #hasta que punto es modificable mi factra
        self.cur.execute('''UPDATE cliente SET estado = ?  WHERE id = ? ''',
                    (estado,  id))
        self.db.execute("PRAGMA busy_timeout = 30000")
        self.db.execute("""INSERT INTO historial (id, fecha, tabla, tabla_id, movimiento) VALUES (null,date('now'),'Factura',?, 'actualizar Estado de Factura')""", (id,))
        self.db.commit()

    def buscar_factura(self, factura_id):
        self.cur.execute('''SELECT * FROM factura WHERE id=? ''', (factura_id,))
        resultado = self.cur.fetchone()
        self.db.commit()
        return resultado

    def buscar_factura_fhi(self,factura_id):
        self.cur.execute('''SELECT id FROM factura WHERE id=? ''', (factura_id,))
        resultado = self.cur.fetchone()
        self.db.commit()
        return resultado

    def reporte(self, ano, mes ):
        date_init = str(ano) + "-" + str(mes) + "-" + "01"
        date_end =  str(ano) + "-" + str(mes) + "-" + "31"
        self.cur.execute("""SELECT factura.fecha, factura.id,  cliente.ci,cliente.nombre,
                        SUM((factura_has_item.cant * factura_has_item.precio)+((factura_has_item.cant * factura_has_item.precio)*(factura.iva)/100)) as monto
                        FROM cliente CROSS JOIN factura
                        ON factura.cliente_id = cliente.id
                        CROSS JOIN factura_has_item ON factura_has_item.factura_id = factura.id
			            WHERE fecha >= ?
                            AND fecha <= ?
			            GROUP BY factura.fecha, factura.id, cliente.nombre, cliente.ci
			            """, (date_init, date_end,))
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado

    def showFact1(self, idfact):
        self.cur.execute('''SELECT factura.id, factura.fecha, factura.estado,
                        cliente.nombre,cliente.ci, cliente.tlf, factura.iva
                        FROM factura CROSS JOIN cliente
                        ON cliente.id = factura.cliente_id
                        WHERE factura.id=? ''', (idfact,))
        self.db.execute("PRAGMA busy_timeout = 30000")
        resultado = self.cur.fetchone()
        self.db.commit()
        return resultado

    def showFact2(self, idfact):
        self.cur.execute('''SELECT factura_has_item.item_id, item.marca, item.modelo, item.descrip, factura_has_item.cant,
                        factura_has_item.precio,
                        factura_has_item.cant * factura_has_item.precio as monto
                        FROM factura CROSS JOIN factura_has_item
                        ON factura_has_item.factura_id = factura.id
                        CROSS JOIN item ON factura_has_item.item_id = item.id
                        WHERE factura.id=?''', (idfact,))
        self.db.execute("PRAGMA busy_timeout = 30000")
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado
