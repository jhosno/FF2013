#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import sqlite3 as lite
import DB.db as dir

class Iva:
    def __init__(self):
        setdir= dir.DB()
        self.file= setdir.return_dir()
        self.db = lite.connect(self.file)
        self.cur = self.db.cursor()
        self.cur = lite.connect('cache.db', timeout=10)
        self.cur = self.db.cursor()

    def nuevo_iva(self, monto):
            self.cur.execute('''INSERT INTO iva (id, fecha, valor) VALUES (null, date('now'), ?)''', (monto,))
            self.db.commit()

    def buscar_iva(self): #muentra el ultimo valor del iva y lo devuelve
        self.cur.execute('''SELECT valor FROM iva ORDER BY id DESC LIMIT 1''')
        valor = self.cur.fetchone()
        self.db.commit()
        return valor

    def mostrar_last(self):
        self.cur.execute('''SELECT valor, fecha FROM iva ORDER BY id DESC LIMIT 1''')
        valor = self.cur.fetchone()
        return valor

