#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'


import sqlite3 as lite
import DB.db as dir


class Item:
    def __init__(self):
        setdir= dir.DB()
        self.file= setdir.return_dir()
        self.db = lite.connect(self.file)
        self.cur = self.db.cursor()
        self.cur = lite.connect('cache.db', timeout=10)
        self.cur = self.db.cursor()

    def nuevo_item(self, descrip, marca, modelo, p_unit, s_min, s_max, existencia ):

        self.cur.execute('''INSERT INTO item (id, descrip, marca, modelo, p_unit, s_min, s_max, existencia)
                                VALUES (null, ?, ?, ?, ?, ?, ?, ?)''', (descrip, marca, modelo, p_unit, s_min, s_max, existencia,))
        self.db.execute("PRAGMA busy_timeout = 30000")
        self.db.execute('''INSERT INTO historial (id, fecha, tabla, tabla_id, movimiento, cantidad)
                            VALUES (null, date('now'), 'item',last_insert_rowid(), 'Entrada: Nuevo Registro', ?)''', (existencia,))
        self.db.commit()

    def validar_item(self, descrip, marca, modelo, p_unit, s_min, s_max, existencia):
        self.cur.execute('''SELECT descrip, marca, modelo, p_unit, s_min, s_max, existencia
                            FROM item
                        WHERE modelo LIKE ? AND marca LIKE ? AND descrip LIKE ?''', ('%'+modelo+'%','%'+marca+'%','%'+descrip+'%'))
        res =self.cur.fetchone()
        self.db.commit()
        return res

    def eliminar_item(self, id):
        self.cur.execute('''DELETE FROM item WHERE id = ?''', (id))
        self.db.commit()

    def actualizar_item(self, descripcion, marca, modelo, p_unit,  existencia , id):
        self.cur.execute('''UPDATE item SET descrip=?, marca=?, modelo=?, p_unit=? , existencia=?   WHERE id = ? ''',
                    (descripcion, marca, modelo, p_unit, existencia,  id,))
        self.db.execute("PRAGMA busy_timeout = 30000")
        self.db.execute("""INSERT INTO historial (id, fecha, tabla, tabla_id, movimiento) VALUES (null,date('now'),'item',?, 'actualizar item')""", (id,))
        self.db.commit()

    def listar_item(self): # acomodar
        self.cur.execute("SELECT * FROM item")
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado

    def buscar_item(self, dato):
        self.cur.execute('''SELECT id, marca, modelo, descrip, p_unit,
                        existencia, s_max, s_min
                        FROM item
                        WHERE id=? OR modelo = ? ''',
                         (dato,dato,))

        resultado = self.cur.fetchone()
        self.db.commit()
        return resultado

    def cant_item(self,dato):
        self.cur.execute('''SELECT id, marca, modelo, descrip, p_unit FROM item WHERE id =? ''', (dato,))
        resultado = self.cur.fetchone()
        self.db.commit()
        return resultado

    def inventario_requis(self):
        self.cur.execute("SELECT id, marca, modelo, descrip, existencia,s_max, s_min FROM item WHERE existencia <= s_min")
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado

    def inventario_valorizado(self):
        self.cur.execute("SELECT id,marca, modelo,descrip, p_unit,existencia, p_unit * existencia as valor  FROM item")
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado

    def mov(self):
        self.cur.execute('''SELECT item.id, item.marca, item.modelo, historial.movimiento
                        from item cross join historial
                        on historial.tabla = "item" ''')
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado

    def movid(self, dato):
        res =self.cur.execute('''SELECT item.id, item.marca, item.modelo, historial.movimiento
                        from item cross join historial
                        on historial.tabla = "item" and item.modelo = ?) ''', dato,)
        if res == None:
            dat = int(dato)
            car =self.cur.execute('''SELECT item.id, item.marca, item.modelo, historial.movimiento
                        from item cross join historial
                        on historial.tabla = "item" and item.id = ?) ''', dato,)
            return car
        self.db.commit()
        return res

    def consulta_date(self, ano, mes):
        date_init = str(ano) + "-" + str(mes) + "-" + "01"
        date_end =  str(ano) + "-" + str(mes) + "-" + "31"
        self.cur.execute(''' SELECT item.id, item.marca, item.modelo, historial.movimiento
                             FROM item CROSS JOIN historial
                    where historial.fecha >= ?
                    and historial.fecha <= ?''',(date_init, date_end))
        res = self.cur.fetchall()
        self.db.commit()
        return res

    def busqueda_requis(self, dato):
        self.cur.execute('''SELECT id, marca, modelo, descrip, p_unit,
                        existencia,sum(p_unit*existencia) as valor
                        FROM item
                        WHERE id=? OR modelo LIKE ? OR marca LIKE ? or descrip LIKE ?
                         GROUP BY id, marca, modelo, descrip, p_unit, existencia''', (dato,'%'+dato+'%','%'+dato+'%','%'+dato+'%'))
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado

    def actualizar_requis(self, ar):
        self.cur.execute('''UPDATE item SET descrip=?, marca=?, modelo=?, existencia=?   WHERE id = ? ''',
                    (ar[0],ar[1],ar[2],ar[3],ar[4],))
        self.db.execute("PRAGMA busy_timeout = 30000")
        self.db.execute("""INSERT INTO historial (id, fecha, tabla, tabla_id, movimiento) VALUES (null,date('now'),'item',?, 'actualizar existencia de item')""", (ar[4],))
        self.db.commit()


    def ajust(self, cod, s_max,s_min,exist,movimiento, suma):
        self.cur.execute('''UPDATE item SET s_max=?, s_min=?,exist=? WHERE id = ? ''',
                    (s_max, s_min,exist,cod, ))
        self.db.execute("PRAGMA busy_timeout = 30000")
        self.db.execute("""INSERT INTO historial (id, fecha, tabla, tabla_id, movimiento, cantidad) VALUES (null,date('now'),'item',?, ?, ?)""", (cod,movimiento,suma))
        self.db.commit()