#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'


import sqlite3 as lite
import DB.db as dir

class User:
    def __init__(self):
        setdir= dir.DB()
        self.file= setdir.return_dir()
        self.db = lite.connect(self.file)
        self.cur = self.db.cursor()
        self.cur = lite.connect('cache.db', timeout=10)
        self.cur = self.db.cursor()

    def sesion(self, user, pwd):
        self.cur.execute('''SELECT id FROM usuario WHERE nick=? AND pass =? ''', (user,pwd, ))
        resultado = self.cur.fetchone()
        if resultado == None:
            return resultado
        else:
            id_user = resultado[0]
            self.db.execute("PRAGMA busy_timeout = 30000")
            self.cur.execute('''INSERT INTO sesion(id, user_id, login) VALUES(null,?,datetime('now')) ''', (id_user,))
            self.db.commit()
            return resultado


    def cerrarsesion(self):
        self.cur.execute('''UPDATE sesion SET logout= datetime('now') WHERE id ORDER BY id DESC LIMIT 1''')
        self.db.commit()

    def mostrar_user(self):
        self.cur.execute('''SELECT usuario.id, usuario.nick, usuario.pass,
                        usuario.nombre, usuario.privilegio
                        FROM usuario
                        CROSS JOIN sesion ON sesion.user_id = usuario.id
                        WHERE usuario.id ORDER BY sesion.id DESC LIMIT 1''')
        self.db.commit()
        resultado = self.cur.fetchone()
        return resultado


    def modificar_user(self,nick, pwd, nombre, email, iduser ):
        self.cur.execute('''UPDATE usuario SET  nick= ?, pass= ?, nombre = ?, email = ? WHERE id = ? ''',
                    (nick, pwd, nombre, email,  iduser))
        self.db.commit()

    def privilegios(self):
        self.cur.execute('''SELECT usuario.privilegio
                        FROM usuario
                        CROSS JOIN sesion ON sesion.user_id = usuario.id
                        WHERE usuario.id ORDER BY sesion.id DESC LIMIT 1''')
        self.db.commit()
        resultado = self.cur.fetchone()
        return resultado