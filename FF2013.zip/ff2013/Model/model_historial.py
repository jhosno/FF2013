#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import sqlite3 as lite
import DB.db as dir

class Model_historial:
    def __init__(self):
        setdir= dir.DB()
        self.file= setdir.return_dir()
        self.db = lite.connect(self.file)
        self.cur = self.db.cursor()
        self.cur = lite.connect('cache.db', timeout=10)
        self.cur = self.db.cursor()

    def mostrar_historial(self):
        self.cur.execute("SELECT fecha, tabla, movimiento, fecha FROM historial")
        resultado = self.cur.fetchall()
        self.db.commit()
        return resultado

    def consulta(self, ano, mes, cat):
        date_init = str(ano) + "-" + str(mes) + "-" + "01"
        date_end =  str(ano) + "-" + str(mes) + "-" + "31"
        self.cur.execute(''' SELECT tabla, movimiento, fecha FROM historial
                            WHERE fecha >= ?
                            AND fecha <= ?
                            AND tabla=? OR tabla=?''',(date_init, date_end, cat, cat.lower() ))
        res = self.cur.fetchall()
        self.db.commit()
        return res

    def export_db(self):
        self.cur.execute('''INSERT INTO historial (id, fecha, tabla, movimiento) VALUES (null,date('now'),'historial', 'respaldo de DB')''')

        self.db.commit()

    def import_db(self):
        self.cur.execute('''INSERT INTO historial (id, fecha, tabla, tabla_id, movimiento) VALUES (null,date('now'),'historial',null, 'Importar DB')''')
        self.db.commit()

    def mov_item(self, id, tabla):
        self.cur.execute("SELECT fecha, movimiento,cantidad FROM historial WHERE tabla_id= ? AND tabla = ? ", (id, tabla,))
        resultado = self.cur.fetchall()
        self.db.commit()

        return resultado


    def consulta_item(self, ano, mes, mov):
        date_init = str(ano) + "-" + str(mes) + "-" + "01"
        date_end =  str(ano) + "-" + str(mes) + "-" + "31"
        if mov == "Todos":
            self.cur.execute(''' SELECT fecha, movimiento, cant FROM historial
                                WHERE fecha >= ?
                                AND fecha <= ?
                                AND tabla='item' ''',(date_init, date_end,))
            res = self.cur.fetchall()
        else:
            self.cur.execute(''' SELECT fecha, movimiento, cant FROM historial
                                WHERE fecha >= ?
                                AND fecha <= ?
                                AND tabla='item' AND movimiento LIKE ?''',(date_init, date_end, '%'+mov+'%',))
            res = self.cur.fetchall()
        self.db.commit()
        return res