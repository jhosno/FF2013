#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Jhosnoirlit Hernández'

import wx, time, datetime

class Validacion(wx.MessageDialog):
    def __init__(self, *args, **kwds):
        # begin wxGlade: Dialog_client.__init__
        kwds["style"] = wx.DEFAULT_DIALOG_STYLE
        wx.Dialog.__init__(self, None, **kwds)
        self.Destroy()

    def numerico(self, text, campo):
        if text.isnumeric():
            return text
        else:
            dlg = wx.MessageDialog(self, "%s debe ser contener solo números" % campo, "Alerta", wx.OK| wx.ICON_WARNING)
            dlg.ShowModal()

    def alfabetico(self, text, campo):
        if text.isalpha():
            return text
        else:
            dlg = wx.MessageDialog(self, "%s debe ser un alfanbetico" % campo, "Alerta", wx.OK| wx.ICON_WARNING)
            dlg.ShowModal()

    def alnumerico(self, text,campo):
        if text.isalnum():
            return text
        else:
            dlg = wx.MessageDialog(self, "%s debe ser contener letras o números" % campo, "Alerta", wx.OK| wx.ICON_WARNING)
            dlg.ShowModal()

    def decimal(self, text, campo):
        if text.isdigit():
            return text
        else:
            dlg = wx.MessageDialog(self, "%s debe ser un valor decimal" % campo, "Alerta", wx.OK| wx.ICON_WARNING)
            dlg.ShowModal()

    def vacio(self, text, campo):
        if text != "":
            return text
        else:
            dlg = wx.MessageDialog(self, "Debe ingresar en %s un dato para continuar" % campo, "Alerta",wx.OK| wx.ICON_WARNING)
            dlg.ShowModal()

    def privilegios(self, pri):
        self.provilegio = {
            "0" : "Administrador",
            "1" : "Gerente",
            "2" : "Operador"
        }
        action = self.provilegio[str(pri)]
        return action

    def meses(self, mes):
        self.calendario = {	"1" : "01",
							   "2" : "02",
							   "3" : "03",
							   "4" : "04",
							   "5" : "05",
							   "6": "06",
							   "7": "07",
							   "8": "08",
							   "9": "09",
							   "10": "10",
							   "11": "11",
							   "12": 12}
        action = self.calendario[str(mes)]
        return action

    def monetario(self,valor):
        num = '{:,.2f}'.format(valor)
        return num

    def email(self, valor):
        if valor.find("@") == -1:
            dlg = wx.MessageDialog(self, "Ingrese una dirección de Email válida ", "Alerta", wx.OK| wx.ICON_WARNING)
            dlg.ShowModal()
        else:
            return valor

    def monedadb(self, valor):
        b = ","
        c = "."
        for i in range(0,len(b)):
            valor =valor.replace(b[i],"")

        valor = valor.replace(c, ".")
        return float(valor)

    def tra_mes(self, mes):
        self.mon = {"Jan" : "Enero",
					"Feb" : "Febrero",
					"Mar" : "Marzo",
					"Apr" : "Abril",
					"May" : "Mayo",
					"Jun": "Junio",
					"Jul": "Julio",
					"Aug": "Agosto",
					"Sep": "Septiembre",
					"Oct": "Octubre",
					"Nov": "Noviembre",
					"Dec": "Diciembre"}
        action = self.mon[str(mes)]
        return action

    def tra_dia(self,dia):
        self.day = {"Sun" : "Domingo",
					"Mon" : "Lunes",
					"Tue" : "Martes",
					"Wed" : "Miércoles",
					"Thu" : "Jueves",
					"Fri": "Viernes",
					"Sat": "Sábado"}
        action = self.day[str(dia)]
        return action

    def tra_per(self, per):
        self.persona = {"0" : "V-",
                        "1" : "E-",
                        "2" : "J-",}
        action = self.persona[str(per)]
        return action

    def fecha_print(self):
        date = time.ctime()
        dia = self.tra_dia(date[0:3])
        mes = self.tra_mes(date[4:7])
        fecha = "Emitido el "+ dia +" " +date[8:11] +" de "+ mes + ", año " +date[20:24]+". Hora:"+ date[10:19]

        return fecha

    def cedula(self, text, campo):
        if text.isnumeric() and len(text)<= 8 and len(text) >= 6:
            return str(text)
        else:
            dlg = wx.MessageDialog(self, "%s debe ser contener solo números y tener de 8 a 6 dígitos" % campo, "Alerta", wx.OK| wx.ICON_WARNING)
            dlg.ShowModal()


    def wxdate2pydate(self, date):
         assert isinstance(date, wx.DateTime)
         if date.IsValid():
              ymd = map(int, date.FormatISODate().split('-'))
              return datetime.date(*ymd)
         else:
              return None